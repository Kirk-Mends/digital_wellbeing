from PySide6.QtWidgets import QWidget
from PySide6.QtCore import QSize
from ui.pages.shared.fluent_card import FluentCard
from ui.core.card_registry import CardRegistry

DEFAULT_CARD_WIDTH = 320
LAPTOP_FULL_WIDTH = 680


class ReasonCard(FluentCard):
    def __init__(self, height: int | None = None, fullWidthOnLaptop: bool = False, parent: QWidget | None = None):
        super().__init__(
            title="Why this matters",
            accent_color="#BF5AF2",
            has_spark=False,
        )

        # ✅ FIXED
        CardRegistry.register(self)

        self.fullWidthOnLaptop = fullWidthOnLaptop

        if height is not None:
            self.setMinimumHeight(height)

        self.setFixedWidth(DEFAULT_CARD_WIDTH)
        self.setParent(parent)
        self.setProperty("fullWidthOnLaptop", fullWidthOnLaptop)

        self.update_value(
            "AI will explain the ‘why’ behind your patterns—what’s driving fatigue, focus, and recovery."
        )

        self.last_reason = None

    def sizeHint(self) -> QSize:
        if self.fullWidthOnLaptop:
            return QSize(LAPTOP_FULL_WIDTH, self.minimumHeight())
        return QSize(DEFAULT_CARD_WIDTH, self.minimumHeight())

    def closeEvent(self, event):
        CardRegistry.unregister(self)
        super().closeEvent(event)

    def update_from_engine(self, behavior, fatigue, reason, trigger, next_break_seconds, session_start, monitoring):
        if reason and reason != self.last_reason:
            self.update_value(reason)
            self.last_reason = reason
