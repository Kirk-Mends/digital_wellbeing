from PySide6.QtWidgets import QWidget, QLabel, QVBoxLayout
from PySide6.QtCore import Qt, QTimer
from PySide6.QtGui import QFont
import time


class LiveTimer(QWidget):
    def __init__(self, engine, main_window):
        super().__init__()

        self.engine = engine
        self.main = main_window

        layout = QVBoxLayout(self)
        layout.setAlignment(Qt.AlignCenter)

        self.label = QLabel("00:00")
        self.label.setFont(QFont("Segoe UI", 32, QFont.Bold))
        layout.addWidget(self.label)

        # Update every second
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_timer)
        self.timer.start(1000)

    def update_timer(self):
        real_time = getattr(self.engine, "real_time", 0)
        minutes = int(real_time // 60)
        seconds = int(real_time % 60)
        self.label.setText(f"{minutes:02d}:{seconds:02d}")
