# ai_reminder_messages.py

# class AIMessageGenerator:
#     """
#     Generates context-aware reminder messages based on:
#     - behavior (deep_work, meeting, reading, watching, idle, etc.)
#     - fatigue score (0–100)
#     - break reason (interval_reached, fatigue_early, etc.)
#     """

#     def generate(self, behavior: str, fatigue: float, reason: str) -> str:
#         # 1. Meeting mode → gentle, non-intrusive
#         if behavior == "meeting":
#             return "You've been in a meeting for a while — take a moment to relax your eyes when you can."

#         # 2. Deep work → respectful, minimal interruption
#         if behavior == "deep_work":
#             if fatigue > 70:
#                 return "You're working intensely — a short break could help you stay sharp."
#             return "Great focus — take 20 seconds to reset your eyes."

#         # 3. Reading mode
#         if behavior == "reading":
#             return "You've been reading for a while — look 20 feet away to relax your eyes."

#         # 4. Watching mode
#         if behavior == "watching":
#             return "You've been watching for a bit — blink a few times and stretch your eyes."

#         # 5. Multitasking / context switching
#         if behavior == "multitasking":
#             return "You've been switching windows rapidly — a quick pause might help you reset."

#         # 6. Fatigued activity
#         if behavior == "fatigued_activity":
#             return "Your activity suggests fatigue — take a short break to recharge."

#         # 7. Idle (natural break)
#         if behavior == "idle":
#             return "Welcome back — take a moment to ease into your next task."

#         # 8. Fatigue-based early break
#         if reason == "fatigue_early":
#             return "You're showing signs of fatigue — a short break will help you recover."

#         # 9. Default fallback
#         return "Time for a quick break — relax your eyes and stretch."


















# import random

# class AIMessageGenerator:
#     """
#     Generates varied, fun, human-like reminder messages based on:
#     - behavior (deep_work, meeting, reading, watching, idle, multitasking, fatigued_activity)
#     - fatigue score (0–100)
#     - break reason (interval_reached, fatigue_early, etc.)
#     - tone (gentle, motivational, playful)
#     """

#     def __init__(self, tone="gentle"):
#         self.tone = tone  # "gentle", "motivational", "playful"

#     # ---------------------------------------------------------
#     # Helper: pick a random message from a list
#     # ---------------------------------------------------------
#     def _pick(self, messages):
#         return random.choice(messages)

#     # ---------------------------------------------------------
#     # Main generator
#     # ---------------------------------------------------------
#     def generate(self, behavior: str, fatigue: float, reason: str) -> str:

#         # ---------------------------
#         # MEETING MODE
#         # ---------------------------
#         if behavior == "meeting":
#             options = [
#                 "You're in a meeting — take a moment to relax your eyes when you get a chance.",
#                 "Long meeting? Give your eyes a tiny breather when possible.",
#                 "You've been focused in this meeting — a quick eye reset will help.",
#             ]
#             return self._pick(options)

#         # ---------------------------
#         # DEEP WORK
#         # ---------------------------
#         if behavior == "deep_work":
#             if fatigue > 70:
#                 options = [
#                     "You're pushing hard — a short break will help you stay sharp.",
#                     "Deep focus detected. A tiny pause now boosts your next burst of productivity.",
#                     "Your brain is working overtime — give it a quick reset.",
#                 ]
#             else:
#                 options = [
#                     "Great focus — take 20 seconds to reset your eyes.",
#                     "You're in the zone. A quick eye break keeps you going.",
#                     "Strong momentum — pause briefly to stay fresh.",
#                 ]
#             return self._pick(options)

#         # ---------------------------
#         # READING MODE
#         # ---------------------------
#         if behavior == "reading":
#             options = [
#                 "You've been reading for a while — look 20 feet away to relax your eyes.",
#                 "Give your eyes a moment — blink slowly and stretch.",
#                 "Reading streak detected — a tiny pause helps prevent strain.",
#             ]
#             return self._pick(options)

#         # ---------------------------
#         # WATCHING MODE
#         # ---------------------------
#         if behavior == "watching":
#             options = [
#                 "You've been watching for a bit — blink a few times and stretch your eyes.",
#                 "Screen time building up — give your eyes a quick breather.",
#                 "A short pause helps your eyes reset — just a few seconds.",
#             ]
#             return self._pick(options)

#         # ---------------------------
#         # MULTITASKING / CONTEXT SWITCHING
#         # ---------------------------
#         if behavior == "multitasking":
#             options = [
#                 "You've been switching windows rapidly — take a moment to reset.",
#                 "Busy workflow detected — a tiny pause can help you refocus.",
#                 "Lots of context switching — breathe and reset for a second.",
#             ]
#             return self._pick(options)

#         # ---------------------------
#         # FATIGUED ACTIVITY
#         # ---------------------------
#         if behavior == "fatigued_activity":
#             options = [
#                 "Your activity suggests fatigue — take a short break to recharge.",
#                 "You're running low on energy — a quick pause will help.",
#                 "Fatigue detected — give yourself a moment to recover.",
#             ]
#             return self._pick(options)

#         # ---------------------------
#         # IDLE (natural break)
#         # ---------------------------
#         if behavior == "idle":
#             options = [
#                 "Welcome back — ease into your next task with a quick eye reset.",
#                 "You paused for a bit — take a moment to stretch your eyes.",
#                 "Nice little break — give your eyes one more gentle reset.",
#             ]
#             return self._pick(options)

#         # ---------------------------
#         # FATIGUE-BASED EARLY BREAK
#         # ---------------------------
#         if reason == "fatigue_early":
#             options = [
#                 "You're showing signs of fatigue — a short break will help you recover.",
#                 "Your eyes need a breather — take a moment to reset.",
#                 "Fatigue detected — pause briefly to recharge.",
#             ]
#             return self._pick(options)

#         # ---------------------------
#         # DEFAULT FALLBACK
#         # ---------------------------
#         default_options = [
#             "Time for a quick break — relax your eyes and stretch.",
#             "A tiny pause helps keep you fresh — take a moment.",
#             "Quick reminder to reset your eyes — just a few seconds.",
#         ]
#         return self._pick(default_options)

















# import random


# class AIMessageGenerator:
#     """
#     Advanced, research-backed break suggestion generator.
#     Produces warm, human, contextual messages based on:
#     - behavior category (deep work, reading, coding, meeting, eye strain risk, posture risk, etc.)
#     - fatigue score (0–100)
#     - break reason (fatigue_early, interval_reached, etc.)
#     - wellbeing dimensions (eyes, posture, stress, movement)
#     """

#     def __init__(self, tone="gentle"):
#         self.tone = tone  # "gentle", "motivational", "playful"

#     # ---------------------------------------------------------
#     # Helper: pick a random message
#     # ---------------------------------------------------------
#     def _pick(self, messages):
#         return random.choice(messages)

#     # ---------------------------------------------------------
#     # Helper: clean behavior label
#     # ---------------------------------------------------------
#     def _clean(self, behavior):
#         if not isinstance(behavior, str):
#             return "your activity"
#         return behavior.replace("_", " ").title()

#     # ---------------------------------------------------------
#     # Helper: classify fatigue level
#     # ---------------------------------------------------------
#     def _fatigue_level(self, score):
#         try:
#             score = float(score)
#         except:
#             return "Low"

#         if score < 25:
#             return "Low"
#         elif score < 50:
#             return "Medium"
#         elif score < 75:
#             return "High"
#         else:
#             return "Critical"

#     # ---------------------------------------------------------
#     # Main generator
#     # ---------------------------------------------------------
#     def generate(self, behavior: str, fatigue: float, reason: str) -> str:
#         behavior_label = self._clean(behavior)
#         fatigue_level = self._fatigue_level(fatigue)

#         # -----------------------------------------------------
#         # MEETING MODE
#         # -----------------------------------------------------
#         if behavior == "Meeting":
#             return self._pick([
#                 "You've been in meeting mode for a while. When you get a moment, relax your eyes by looking away from the screen.",
#                 "Lots of listening and talking — stretch your neck gently and take a slow breath.",
#                 "Meeting marathon detected. Roll your shoulders back and soften your gaze for a moment."
#             ])

#         # -----------------------------------------------------
#         # DEEP WORK
#         # -----------------------------------------------------
#         if behavior == "Deep Work":
#             if fatigue_level in ["High", "Critical"]:
#                 return self._pick([
#                     "Your focus is powerful, but your body needs a reset. Stand up, stretch your back, and take a slow breath.",
#                     "Deep work is intense. Give your eyes a 20‑second break and relax your shoulders.",
#                     "Strong focus, but rising fatigue. Look at something far away and breathe deeply."
#                 ])
#             else:
#                 return self._pick([
#                     "Great momentum. Blink slowly 10 times and let your eyes soften.",
#                     "You're in the zone. Take a 20‑second eye reset to stay sharp.",
#                     "Nice focus. Stretch your neck gently and breathe in slowly."
#                 ])

#         # -----------------------------------------------------
#         # READING
#         # -----------------------------------------------------
#         if behavior == "Reading":
#             return self._pick([
#                 "You've been reading for a while. Look at something far away to relax your eye muscles.",
#                 "Give your eyes a moment — blink slowly and stretch your neck.",
#                 "Reading streak detected. Let your eyes rest for a few seconds."
#             ])

#         # -----------------------------------------------------
#         # WATCHING
#         # -----------------------------------------------------
#         if behavior == "Watching":
#             return self._pick([
#                 "Your eyes have been fixed on the screen. Blink slowly and soften your gaze.",
#                 "Screen brightness can strain your eyes. Look away for 20 seconds.",
#                 "Give your eyes a soft break — let them rest for a moment."
#             ])

#         # -----------------------------------------------------
#         # CODING / WRITING
#         # -----------------------------------------------------
#         if behavior in ["Coding", "Writing"]:
#             return self._pick([
#                 "You've been typing intensely. Roll your shoulders and stretch your wrists.",
#                 "Posture check — sit tall, relax your jaw, and take a slow breath.",
#                 "Your hands and back could use a reset. Stretch gently for a moment."
#             ])

#         # -----------------------------------------------------
#         # MULTITASKING
#         # -----------------------------------------------------
#         if behavior == "Multitasking":
#             return self._pick([
#                 "Lots of switching detected. Pause for a moment and take a slow breath.",
#                 "Busy workflow. Relax your shoulders and reset your focus.",
#                 "You're juggling tasks. A tiny pause helps your brain recalibrate."
#             ])

#         # -----------------------------------------------------
#         # EYE STRAIN RISK
#         # -----------------------------------------------------
#         if behavior == "Eye Strain Risk":
#             return self._pick([
#                 "Your eyes need a breather. Look at something far away for 20 seconds.",
#                 "Screen intensity detected. Blink slowly and soften your gaze.",
#                 "Give your eyes a moment to recover — close them gently for 10 seconds."
#             ])

#         # -----------------------------------------------------
#         # POSTURE RISK
#         # -----------------------------------------------------
#         if behavior == "Posture Risk":
#             return self._pick([
#                 "You've been sitting still for a while. Stand up and stretch your back.",
#                 "Posture reset time — roll your shoulders and open your chest.",
#                 "Your back needs a moment. Stand tall and stretch gently."
#             ])

#         # -----------------------------------------------------
#         # FATIGUED ACTIVITY
#         # -----------------------------------------------------
#         if behavior == "Fatigued Activity":
#             return self._pick([
#                 "Your energy is dipping. Stand up, stretch your back, and take a slow breath.",
#                 "Fatigue creeping in — give your eyes and posture a gentle reset.",
#                 "You're running low. A tiny break now will recharge your next burst."
#             ])

#         # -----------------------------------------------------
#         # IDLE / RETURNING
#         # -----------------------------------------------------
#         if behavior == "Idle":
#             return self._pick([
#                 "Welcome back. Ease into your next task with a soft eye reset.",
#                 "Nice little pause — stretch your arms and relax your shoulders.",
#                 "Good to see you again. Blink slowly and let your eyes warm up."
#             ])

#         # -----------------------------------------------------
#         # EARLY FATIGUE BREAK
#         # -----------------------------------------------------
#         if reason == "fatigue_early":
#             return self._pick([
#                 "Your body needs a breather. Stand up, stretch, and take a slow breath.",
#                 "Fatigue rising — look away from the screen and relax your posture.",
#                 "You're pushing hard. Give yourself a moment to recover."
#             ])

#         # -----------------------------------------------------
#         # DEFAULT FALLBACK
#         # -----------------------------------------------------
#         return self._pick([
#             "Take a short break — relax your eyes and stretch your body.",
#             "A tiny pause helps keep you fresh. Look away from the screen for a moment.",
#             "Quick reminder to reset your eyes and posture."
#         ])
















# Cleaned to make UI labels more human-friendly (no underscores, proper capitalization):
# import random


# class AIMessageGenerator:
#     """
#     Research-backed, human-centered break suggestion generator.

#     Accepts internal system labels like:
#     - deep_work
#     - eye_strain_risk
#     - posture_risk

#     Converts them into warm, user-friendly messages.
#     """

#     def __init__(self, tone="gentle"):
#         self.tone = tone

#         # Map internal behavior codes to readable names
#         self.behavior_display = {
#             "meeting": "Meeting",
#             "deep_work": "Deep Work",
#             "reading": "Reading",
#             "watching": "Watching",
#             "coding": "Coding",
#             "writing": "Writing",
#             "multitasking": "Multitasking",
#             "eye_strain_risk": "Eye Strain Risk",
#             "posture_risk": "Posture Risk",
#             "fatigued_activity": "Fatigued Activity",
#             "idle": "Idle"
#         }

#     # ---------------------------------------------------------
#     # Helper: pick random message
#     # ---------------------------------------------------------
#     def _pick(self, messages):
#         return random.choice(messages)

#     # ---------------------------------------------------------
#     # Helper: clean internal behavior safely
#     # ---------------------------------------------------------
#     def _normalize_behavior(self, behavior):
#         if not isinstance(behavior, str):
#             return "General"

#         return behavior.strip().lower().replace(" ", "_")

#     # ---------------------------------------------------------
#     # Helper: fatigue level
#     # ---------------------------------------------------------
#     def _fatigue_level(self, score):
#         try:
#             score = float(score)
#         except Exception:
#             return "low"

#         if score < 25:
#             return "low"
#         elif score < 50:
#             return "medium"
#         elif score < 75:
#             return "high"
#         else:
#             return "critical"

#     # ---------------------------------------------------------
#     # Main generator
#     # ---------------------------------------------------------
#     def generate(self, behavior: str, fatigue: float, reason: str = None) -> str:

#         behavior_key = self._normalize_behavior(behavior)
#         fatigue_level = self._fatigue_level(fatigue)

#         # ------------------ Meeting ------------------
#         if behavior_key == "meeting":
#             return self._pick([
#                 "You've been in meetings for a while. When you can, relax your eyes and take a slow breath.",
#                 "That was a lot of listening and talking. Gently stretch your neck and roll your shoulders.",
#                 "Meeting streak detected. Soften your gaze and reset your posture for a moment."
#             ])

#         # ------------------ Deep Work ------------------
#         if behavior_key == "deep_work":
#             if fatigue_level in ["high", "critical"]:
#                 return self._pick([
#                     "You're deeply focused, but your body needs a reset. Stand up and stretch gently.",
#                     "Strong concentration detected. Look away from the screen for 20 seconds.",
#                     "Your focus is powerful. Let your eyes and shoulders relax for a moment."
#                 ])
#             else:
#                 return self._pick([
#                     "Great momentum. Blink slowly and let your eyes soften.",
#                     "Nice focus. Stretch your neck gently and breathe deeply.",
#                     "You're in the zone. A quick eye reset will keep you sharp."
#                 ])

#         # ------------------ Reading ------------------
#         if behavior_key == "reading":
#             return self._pick([
#                 "You've been reading for a while. Look at something far away to relax your eyes.",
#                 "Give your eyes a short reset. Blink slowly and stretch your neck.",
#                 "Reading streak noticed. Let your eyes rest for a few seconds."
#             ])

#         # ------------------ Watching ------------------
#         if behavior_key == "watching":
#             return self._pick([
#                 "Your eyes have been fixed on the screen. Soften your gaze and blink slowly.",
#                 "Screen brightness can strain your eyes. Look away for 20 seconds.",
#                 "Give your eyes a gentle break before continuing."
#             ])

#         # ------------------ Coding / Writing ------------------
#         if behavior_key in ["coding", "writing"]:
#             return self._pick([
#                 "You've been typing intensely. Roll your shoulders and stretch your wrists.",
#                 "Posture check. Sit tall, relax your jaw, and take a slow breath.",
#                 "Your hands and back could use a short reset. Stretch gently."
#             ])

#         # ------------------ Multitasking ------------------
#         if behavior_key == "multitasking":
#             return self._pick([
#                 "Lots of task switching detected. Pause and take a slow breath.",
#                 "Busy workflow. Relax your shoulders and reset your focus.",
#                 "You're juggling tasks. A brief pause helps your brain recalibrate."
#             ])

#         # ------------------ Eye Strain Risk ------------------
#         if behavior_key == "eye_strain_risk":
#             return self._pick([
#                 "Your eyes need a breather. Look at something far away for 20 seconds.",
#                 "High screen intensity detected. Blink slowly and soften your gaze.",
#                 "Close your eyes gently for 10 seconds to help them recover."
#             ])

#         # ------------------ Posture Risk ------------------
#         if behavior_key == "posture_risk":
#             return self._pick([
#                 "You've been sitting still for a while. Stand up and stretch your back.",
#                 "Time for a posture reset. Roll your shoulders and open your chest.",
#                 "Stand tall for a moment and let your back decompress."
#             ])

#         # ------------------ Fatigued Activity ------------------
#         if behavior_key == "fatigued_activity" or reason == "fatigue_early":
#             return self._pick([
#                 "Your energy seems to be dipping. Stand up and take a slow breath.",
#                 "Fatigue rising. Look away from the screen and relax your posture.",
#                 "You're pushing hard. A short break now will recharge you."
#             ])

#         # ------------------ Idle ------------------
#         if behavior_key == "idle":
#             return self._pick([
#                 "Welcome back. Ease into your next task with a soft eye reset.",
#                 "Nice little pause. Stretch your arms and relax your shoulders.",
#                 "Good to see you again. Blink slowly and warm up your focus."
#             ])

#         # ------------------ Default ------------------
#         return self._pick([
#             "Take a short break. Relax your eyes and stretch your body.",
#             "A tiny pause helps you stay fresh. Look away from the screen for a moment.",
#             "Quick reminder to reset your eyes and posture."
#         ])






# Even better Cleaned

# import random


# class AIMessageGenerator:
#     """
#     Enterprise-grade, research-informed wellbeing message engine.

#     Architecture principles:
#     - Data-driven message registry
#     - Graceful behavior normalization
#     - Fatigue-aware routing
#     - Elegant fallbacks
#     - No technical artifacts exposed
#     - Easy to scale and maintain
#     """

#     def __init__(self, tone="gentle"):
#         self.tone = tone
#         self._build_message_registry()

#     # ---------------------------------------------------------
#     # Core Utilities
#     # ---------------------------------------------------------
#     def _pick(self, messages):
#         return random.choice(messages)

#     def _normalize(self, value):
#         if isinstance(value, str):
#             return value.strip().lower().replace(" ", "_")
#         return None

#     def _fatigue_level(self, score):
#         try:
#             score = float(score)
#         except Exception:
#             return "low"

#         if score < 25:
#             return "low"
#         elif score < 50:
#             return "medium"
#         elif score < 75:
#             return "high"
#         else:
#             return "critical"

#     # ---------------------------------------------------------
#     # Message Registry (Fully Data-Driven)
#     # ---------------------------------------------------------
#     def _build_message_registry(self):

#         self.messages = {

#             "meeting": {
#                 "default": [
#                     "You've been in meetings for a while. Relax your shoulders and take a slow breath.",
#                     "That was a lot of listening and talking. Gently stretch your neck and soften your gaze.",
#                     "Let your posture reset before your next conversation."
#                 ]
#             },

#             "deep_work": {
#                 "low": [
#                     "Great momentum. Blink slowly and soften your gaze.",
#                     "You're in the zone. A short reset will keep you sharp."
#                 ],
#                 "high": [
#                     "You're deeply focused. Stand up and stretch gently.",
#                     "Strong concentration detected. Let your eyes rest for a moment."
#                 ],
#                 "critical": [
#                     "Your focus is impressive, but your body needs recovery. Step away briefly.",
#                     "Pause now. A short reset will protect your energy."
#                 ]
#             },

#             "reading": {
#                 "default": [
#                     "You've been reading for a while. Look at something far away to relax your eyes.",
#                     "Blink slowly and allow your eyes to recover."
#                 ]
#             },

#             "watching": {
#                 "default": [
#                     "Your eyes have been fixed on the screen. Soften your gaze for a moment.",
#                     "Look away for 20 seconds to reduce strain."
#                 ]
#             },

#             "coding": {
#                 "default": [
#                     "You've been typing intensely. Roll your shoulders and stretch your wrists.",
#                     "Posture check. Sit tall and take a slow breath."
#                 ]
#             },

#             "writing": {
#                 "default": [
#                     "You've been writing with focus. Relax your shoulders and stretch gently.",
#                     "Pause briefly to reset your posture."
#                 ]
#             },

#             "multitasking": {
#                 "default": [
#                     "Lots of task switching detected. Pause and take a slow breath.",
#                     "Give your mind a moment to recalibrate."
#                 ]
#             },

#             "eye_strain_risk": {
#                 "default": [
#                     "Your eyes could use a short reset. Look at something far away for 20 seconds.",
#                     "Close your eyes gently for 10 seconds."
#                 ]
#             },

#             "posture_risk": {
#                 "default": [
#                     "You've been sitting still for a while. Stand up and stretch your back.",
#                     "Roll your shoulders gently and open your chest."
#                 ]
#             },

#             "fatigued_activity": {
#                 "default": [
#                     "Your energy seems to be dipping. A short break will help you recharge.",
#                     "Pause for a moment. Breathe deeply and reset."
#                 ]
#             },

#             "idle": {
#                 "default": [
#                     "Welcome back. Ease into your next task calmly.",
#                     "Take a gentle breath before continuing."
#                 ]
#             },

#             "fallback": [
#                 "Take a brief pause. Relax your eyes and stretch gently.",
#                 "A short reset will help you stay fresh and focused.",
#                 "Step away for a moment and give your body a quick refresh."
#             ]
#         }

#     # ---------------------------------------------------------
#     # Main Engine
#     # ---------------------------------------------------------
#     def generate(self, behavior=None, fatigue=0, reason=None):

#         behavior_key = self._normalize(behavior)
#         fatigue_level = self._fatigue_level(fatigue)

#         # Early fatigue trigger override
#         if self._normalize(reason) == "fatigue_early":
#             return self._pick(self.messages["fatigued_activity"]["default"])

#         # Behavior-based routing
#         if behavior_key in self.messages:

#             behavior_block = self.messages[behavior_key]

#             # Fatigue-aware routing if defined
#             if fatigue_level in behavior_block:
#                 return self._pick(behavior_block[fatigue_level])

#             # Default behavior routing
#             if "default" in behavior_block:
#                 return self._pick(behavior_block["default"])

#         # Elegant fallback
#         return self._pick(self.messages["fallback"])













# 5

# Upgraded with light and heavy browsing
# ai_reminder_messages.py
# Premium, warm-tone, behavior-aware AI message generator

class AIMessageGenerator:
    """
    Generates warm, human-friendly messages for AI Mode.
    These messages are behavior-aware and fatigue-aware,
    and designed to match the premium reminder popup.
    """

    def __init__(self):
        pass

    # ---------------------------------------------------------
    # MAIN ENTRY
    # ---------------------------------------------------------
    def generate(self, behavior: str, reason: str, fatigue: float) -> str:
        """
        Returns a warm, human-friendly message body.
        The reminder popup will handle the headline and timing.
        """
        behavior_key = behavior.lower().replace(" ", "_")

        # Fatigue overrides (AI Mode is more adaptive)
        if fatigue >= 85:
            return "You’ve been pushing yourself hard. Take a moment to reset."
        if fatigue >= 70:
            return "Your focus has been strong. A short pause will help you stay sharp."

        # Behavior-specific messages
        if behavior_key in ["reading"]:
            return "Your eyes have been working steadily. A short pause could help them recover."

        if behavior_key in ["coding", "deep_work", "writing"]:
            return "You’ve been deeply focused. A brief stretch can help you keep your flow."

        if behavior_key in ["browsing", "light_browsing", "heavy_browsing"]:
            return "You’ve been scrolling for a while. Take a moment to relax your eyes."

        if behavior_key in ["watching", "video"]:
            return "Enjoy your video. Breaks will resume afterward."

        if behavior_key in ["gaming"]:
            return "You’re in the middle of a game. Breaks will wait for you."

        if behavior_key in ["meeting", "call"]:
            return "You’re in a call right now. Breaks will resume when you’re done."

        if behavior_key in ["eye_strain_risk"]:
            return "Your eyes could use a moment of rest."

        if behavior_key in ["posture_risk"]:
            return "A quick stretch may help you feel more comfortable."

        if behavior_key in ["idle", "away"]:
            return "Welcome back. Take a moment to settle in."

        # Fallback (rare)
        return "You’ve been going for a while. A short pause could feel good."
