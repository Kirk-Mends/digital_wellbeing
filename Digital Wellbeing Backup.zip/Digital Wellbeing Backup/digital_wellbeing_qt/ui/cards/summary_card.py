from PySide6.QtWidgets import QWidget
from PySide6.QtCore import QSize
from ui.pages.shared.fluent_card import FluentCard
from ui.animations import SparklineAnimator
from ui.core.card_registry import CardRegistry

DEFAULT_CARD_WIDTH = 320
LAPTOP_FULL_WIDTH = 680


class SummaryCard(FluentCard):
    def __init__(self, height: int | None = None, fullWidthOnLaptop: bool = False, parent: QWidget | None = None):
        super().__init__(
            title="Daily summary",
            accent_color="#0FB5A9",
            has_spark=True,
        )

        # ✅ FIXED: register instead of unregister
        CardRegistry.register(self)

        self.fullWidthOnLaptop = fullWidthOnLaptop

        if height is not None:
            self.setMinimumHeight(height)

        self.setFixedWidth(DEFAULT_CARD_WIDTH)
        self.setParent(parent)
        self.setProperty("fullWidthOnLaptop", fullWidthOnLaptop)

        self.update_value(
            "A concise wrap‑up of today’s behavior, fatigue, and breaks will be generated here."
        )

        self.summary_trend = []
        self.last_summary = None

    def sizeHint(self) -> QSize:
        if self.fullWidthOnLaptop:
            return QSize(LAPTOP_FULL_WIDTH, self.minimumHeight())
        return QSize(DEFAULT_CARD_WIDTH, self.minimumHeight())

    def closeEvent(self, event):
        CardRegistry.unregister(self)
        super().closeEvent(event)

    def update_from_engine(self, behavior, fatigue, reason, trigger, next_break_seconds, session_start, monitoring):

        if not monitoring or not session_start:
            return

        summary = f"Behavior: {behavior} • Fatigue: {fatigue}%"

        if trigger:
            summary += " • Break recommended now"
        else:
            summary += f" • Next break in {next_break_seconds}s"

        if reason:
            summary += f"\nWhy: {reason}"

        if summary != self.last_summary:
            self.update_value(summary)
            self.last_summary = summary

        numeric = min(max(int(fatigue), 0), 100)
        self.summary_trend.append(numeric)
        self.summary_trend = self.summary_trend[-30:]

        if self.spark:
            SparklineAnimator(self.spark, "#0FB5A9").animate(self.summary_trend)
