# ui/pages/ai_mode_page.py

from PySide6.QtWidgets import QWidget, QVBoxLayout, QScrollArea, QFrame
from PySide6.QtCore import Qt
from ui.core.flow_layout import FlowLayout
from ui.core.bottom_bar import BottomBar
from ui.core.card_registry import CardRegistry

from ui.cards.behavior_card import BehaviorCard
from ui.cards.fatigue_card import FatigueCard
from ui.cards.reason_card import ReasonCard
from ui.cards.next_break_card import NextBreakCard
from ui.cards.suppression_card import SuppressionCard
from ui.cards.message_card import MessageCard
from ui.cards.summary_card import SummaryCard


class AIModePage(QWidget):
    def __init__(self, theme):
        super().__init__()
        self.theme = theme

        self.monitoring = False
        self.session_start = None

        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.setSpacing(0)

        contentWidget = QWidget()
        flow = FlowLayout(contentWidget, spacing=16)

        flow.addWidget(BehaviorCard(height=260))
        flow.addWidget(FatigueCard(height=260))
        flow.addWidget(ReasonCard(height=300, fullWidthOnLaptop=True))
        flow.addWidget(NextBreakCard(height=150))
        flow.addWidget(SuppressionCard(height=150))
        flow.addWidget(MessageCard(height=150))
        flow.addWidget(SummaryCard(height=300, fullWidthOnLaptop=True))

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setWidget(contentWidget)

        root.addWidget(scroll)

        self.bottomBar = BottomBar(self.theme)
        root.addWidget(self.bottomBar)

    def update_ai_status(self, behavior, fatigue, reason, trigger, next_break_seconds):
        CardRegistry.update_all(
            behavior=behavior,
            fatigue=fatigue,
            reason=reason,
            trigger=trigger,
            next_break_seconds=next_break_seconds,
            session_start=self.session_start,
            monitoring=self.monitoring,
        )
