from PySide6.QtWidgets import QWidget
from PySide6.QtCore import QSize
from ui.pages.shared.fluent_card import FluentCard
from ui.animations import SparklineAnimator
from ui.core.card_registry import CardRegistry

DEFAULT_CARD_WIDTH = 320
LAPTOP_FULL_WIDTH = 680


class SuppressionCard(FluentCard):
    def __init__(self, height: int | None = None, fullWidthOnLaptop: bool = False, parent: QWidget | None = None):
        super().__init__(
            title="Suppression risk",
            accent_color="#FF453A",
            has_spark=True,
        )

        # ✅ FIXED
        CardRegistry.register(self)

        self.fullWidthOnLaptop = fullWidthOnLaptop

        if height is not None:
            self.setMinimumHeight(height)

        self.setFixedWidth(DEFAULT_CARD_WIDTH)
        self.setParent(parent)
        self.setProperty("fullWidthOnLaptop", fullWidthOnLaptop)

        self.update_value(
            "Signals that you might be pushing through fatigue or ignoring break cues will show here."
        )

        self.suppression_trend = []
        self.last_risk = None

    def sizeHint(self) -> QSize:
        if self.fullWidthOnLaptop:
            return QSize(LAPTOP_FULL_WIDTH, self.minimumHeight())
        return QSize(DEFAULT_CARD_WIDTH, self.minimumHeight())

    def closeEvent(self, event):
        CardRegistry.unregister(self)
        super().closeEvent(event)

    def update_from_engine(self, behavior, fatigue, reason, trigger, next_break_seconds, session_start, monitoring):

        if not monitoring or not session_start:
            return

        risk = int(fatigue)

        if trigger:
            risk += 25

        risk = max(0, min(risk, 100))

        if risk != self.last_risk:
            self.update_value(f"{risk}% risk")
            self.last_risk = risk

        self.suppression_trend.append(risk)
        self.suppression_trend = self.suppression_trend[-30:]

        if self.spark:
            SparklineAnimator(self.spark, "#FF453A").animate(self.suppression_trend)
