# from PySide6.QtWidgets import QWidget
# from PySide6.QtGui import QPainter, QPen, QColor, QFont
# from PySide6.QtCore import Qt, QRectF


# class FatigueGauge(QWidget):
#     def __init__(self):
#         super().__init__()
#         self.setMinimumSize(140, 140)
#         self.value = 0

#     def set_value(self, v):
#         self.value = max(0, min(100, v))
#         self.update()

#     def paintEvent(self, event):
#         painter = QPainter(self)
#         painter.setRenderHint(QPainter.Antialiasing)

#         rect = QRectF(10, 10, self.width() - 20, self.height() - 20)

#         # Background arc
#         pen = QPen(QColor("#DDDDDD"), 10)
#         painter.setPen(pen)
#         painter.drawArc(rect, 0, 360 * 16)

#         # Value arc
#         pen = QPen(self.color(), 10)
#         painter.setPen(pen)
#         painter.drawArc(rect, 90 * 16, -int(360 * 16 * (self.value / 100)))

#         # Text
#         painter.setPen(Qt.black)
#         painter.setFont(QFont("Segoe UI", 14, QFont.Bold))
#         painter.drawText(self.rect(), Qt.AlignCenter, f"{self.value}%")

#     def color(self):
#         if self.value < 30:
#             return QColor("#4CAF50")
#         if self.value < 60:
#             return QColor("#FFC107")
#         if self.value < 85:
#             return QColor("#FF9800")
#         return QColor("#F44336")
















# Cleaned up version without underscores in UI labels:
from PySide6.QtWidgets import QWidget
from PySide6.QtGui import QPainter, QPen, QColor, QFont
from PySide6.QtCore import Qt, QRectF, QTimer


class AIRing(QWidget):
    def __init__(self):
        super().__init__()
        self.setMinimumSize(160, 160)

        self.fatigue = 0
        self.ai_active = False
        self.pulse = 0
        self.behavior = "Idle"

        self.timer = QTimer()
        self.timer.timeout.connect(self.update_pulse)
        self.timer.start(40)

    # ---------------------------------------------------------
    # UI CLEANING HELPERS
    # ---------------------------------------------------------
    @staticmethod
    def clean_label(text: str) -> str:
        """Convert internal identifiers into readable UI text."""
        if not isinstance(text, str):
            return str(text)

        words = text.replace("_", " ").split()
        return " ".join(w.capitalize() if not w.isupper() else w for w in words)

    # ---------------------------------------------------------
    # STATE UPDATES
    # ---------------------------------------------------------
    def update_pulse(self):
        if self.ai_active:
            self.pulse = (self.pulse + 2) % 360
        else:
            self.pulse = 0
        self.update()

    def set_fatigue(self, value):
        self.fatigue = max(0, min(100, value))
        self.update()

    def set_behavior(self, text):
        # Clean UI text before displaying
        self.behavior = self.clean_label(text)
        self.update()

    def set_ai_active(self, active):
        self.ai_active = active
        self.update()

    # ---------------------------------------------------------
    # PAINT EVENT
    # ---------------------------------------------------------
    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        rect = QRectF(10, 10, self.width() - 20, self.height() - 20)

        # Outer AI activity ring
        pen = QPen(QColor(0, 120, 215, 180), 8)
        painter.setPen(pen)
        painter.drawArc(rect, self.pulse * 16, 120 * 16)

        # Inner fatigue ring
        pen = QPen(self.fatigue_color(self.fatigue), 10)
        painter.setPen(pen)
        painter.drawArc(
            rect.adjusted(12, 12, -12, -12),
            0,
            int(360 * 16 * (self.fatigue / 100))
        )

        # Center text
        painter.setPen(Qt.black)
        painter.setFont(QFont("Segoe UI", 14, QFont.Bold))
        painter.drawText(self.rect(), Qt.AlignCenter, self.behavior)

    # ---------------------------------------------------------
    # FATIGUE COLOR LOGIC
    # ---------------------------------------------------------
    def fatigue_color(self, value):
        if value < 30:
            return QColor("#4CAF50")   # Green
        if value < 60:
            return QColor("#FFC107")   # Yellow
        if value < 85:
            return QColor("#FF9800")   # Orange
        return QColor("#F44336")       # Red
