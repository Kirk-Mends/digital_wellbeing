from PySide6.QtWidgets import QWidget
from PySide6.QtCore import QSize
from ui.pages.shared.fluent_card import FluentCard
from ui.animations import ValueAnimator, SparklineAnimator
from ui.core.card_registry import CardRegistry

DEFAULT_CARD_WIDTH = 320
LAPTOP_FULL_WIDTH = 680


class FatigueCard(FluentCard):
    def __init__(self, height: int | None = None, fullWidthOnLaptop: bool = False, parent: QWidget | None = None):
        super().__init__(
            title="Fatigue signals",
            accent_color="#FF9F0A",  # orange
            has_spark=True,
        )

        # ✅ Correct: register the card
        CardRegistry.register(self)

        self.fullWidthOnLaptop = fullWidthOnLaptop

        if height is not None:
            self.setMinimumHeight(height)

        self.setFixedWidth(DEFAULT_CARD_WIDTH)

        self.setParent(parent)
        self.setProperty("fullWidthOnLaptop", fullWidthOnLaptop)

        self.update_value(
            "Micro‑breaks, late sessions, and cognitive load trends will be summarized here."
        )

        # Internal trend buffer
        self.fatigue_trend = []

    def sizeHint(self) -> QSize:
        if self.fullWidthOnLaptop:
            return QSize(LAPTOP_FULL_WIDTH, self.minimumHeight())
        return QSize(DEFAULT_CARD_WIDTH, self.minimumHeight())

    def closeEvent(self, event):
        # ✅ Proper unregister on close
        CardRegistry.unregister(self)
        super().closeEvent(event)

    # ============================================================
    # ENGINE UPDATE HOOK
    # ============================================================
    def update_from_engine(self, behavior, fatigue, reason, trigger, next_break_seconds, session_start, monitoring):
        """
        Called every second by SmartModePage and AIModePage.
        """

        # Smoothly animate fatigue %
        try:
            current = int(self.value_label.text().replace("%", "").strip())
        except:
            current = 0

        ValueAnimator(
            start_value=current,
            end_value=int(fatigue),
            duration=400,
            callback=lambda v: self.update_value(f"{int(v)}%")
        ).start()

        # Update sparkline trend
        self.fatigue_trend.append(int(fatigue))
        self.fatigue_trend = self.fatigue_trend[-30:]  # keep last 30 points

        if self.spark:
            SparklineAnimator(self.spark, "#FF9F0A").animate(self.fatigue_trend)

        # Optional: update heat bar if FluentCard supports it
        if hasattr(self, "set_heat_level"):
            self.set_heat_level(fatigue)
