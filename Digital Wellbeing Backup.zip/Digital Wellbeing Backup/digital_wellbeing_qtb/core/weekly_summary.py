import csv
from datetime import datetime, timedelta
from statistics import mean


class WeeklySummaryEngine:
    def __init__(self, csv_path="usage_log.csv"):
        self.csv_path = csv_path

    def load_week(self):
        today = datetime.now().date()
        week_start = today - timedelta(days=6)

        entries = []

        try:
            with open(self.csv_path, "r") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    date = datetime.fromisoformat(row["date"]).date()
                    if week_start <= date <= today:
                        entries.append({
                            "date": date,
                            "active": float(row["active_minutes"])
                        })
        except FileNotFoundError:
            return []

        return entries

    def summarize(self):
        data = self.load_week()
        if not data:
            return None

        # Aggregate by day
        daily = {}
        for e in data:
            daily.setdefault(e["date"], 0)
            daily[e["date"]] += e["active"]

        days = sorted(daily.keys())
        values = [daily[d] for d in days]

        avg = mean(values)
        total = sum(values)
        best_day = days[values.index(max(values))].strftime("%A")
        worst_day = days[values.index(min(values))].strftime("%A")

        trend = "up" if values[-1] > values[0] else "down"

        return {
            "avg": avg,
            "total": total,
            "best_day": best_day,
            "worst_day": worst_day,
            "trend": trend,
            "daily": daily
        }
