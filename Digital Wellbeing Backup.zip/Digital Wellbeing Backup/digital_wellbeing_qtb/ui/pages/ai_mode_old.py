# from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel
# from PySide6.QtCore import Qt

# from ui.widgets.intelligent_panel import IntelligentPanel


# class AIDashboard(QWidget):
#     def __init__(self, main_window):
#         super().__init__()

#         self.main = main_window

#         layout = QVBoxLayout(self)
#         layout.setAlignment(Qt.AlignTop)
#         layout.setContentsMargins(40, 40, 40, 40)
#         layout.setSpacing(20)

#         title = QLabel("AI Mode")
#         title.setStyleSheet("font-size: 24px; font-weight: 600;")
#         layout.addWidget(title)

#         # Intelligent Panel
#         self.panel = IntelligentPanel(self.main.ai_engine, self.main)
#         layout.addWidget(self.panel, alignment=Qt.AlignCenter)











# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton
# )
# from PySide6.QtCore import Qt, QTimer
# from ui.widgets.meeting_badge import MeetingBadge


# class FluentCard(QFrame):
#     def __init__(self, title, value="—"):
#         super().__init__()
#         self.setObjectName("FluentCard")

#         self.meeting_badge = MeetingBadge()
#         layout.addWidget(self.meeting_badge, alignment=Qt.AlignLeft)


#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(14, 14, 14, 14)
#         layout.setSpacing(6)

#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")

#         self.value_label = QLabel(value)
#         self.value_label.setObjectName("CardValue")

#         layout.addWidget(self.title_label)
#         layout.addWidget(self.value_label)
#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)


# class AIModePage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # -------------------------
#         # LARGE AI STATUS CARD
#         # -------------------------
#         self.card_status = FluentCard("AI Status", "Waiting…")
#         self.card_status.setMinimumHeight(150)
#         layout.addWidget(self.card_status)

#         # -------------------------
#         # SECOND ROW (Next Break + Meeting Mode)
#         # -------------------------
#         row = QHBoxLayout()
#         row.setSpacing(20)

#         self.card_next_break = FluentCard("Next Break (AI)", "—")
#         self.card_meeting = FluentCard("Meeting Mode", "Off")

#         row.addWidget(self.card_next_break)
#         row.addWidget(self.card_meeting)

#         layout.addLayout(row)

#         # -------------------------
#         # START / STOP BUTTON
#         # -------------------------
#         self.btn_toggle = QPushButton("Start Monitoring")
#         self.btn_toggle.setObjectName("PrimaryButton")
#         self.btn_toggle.setFixedHeight(44)
#         self.btn_toggle.clicked.connect(self.toggle_monitoring)

#         layout.addWidget(self.btn_toggle)

#         # Timer for updating UI
#         self.ui_timer = QTimer()
#         self.ui_timer.timeout.connect(self.update_ui)
#         self.ui_timer.start(1000)

#     # -------------------------
#     # START / STOP MONITORING
#     # -------------------------
#     def toggle_monitoring(self):
#         self.main.toggle_monitoring()

#         if self.main.monitoring:
#             self.btn_toggle.setText("Stop Monitoring")
#         else:
#             self.btn_toggle.setText("Start Monitoring")

#     # -------------------------
#     # UPDATE UI VALUES
#     # -------------------------
#     def update_ui(self):
#         if not self.main.monitoring:
#             return

#         # AI engine decision
#         decision = self.main.ai_engine.last_decision if hasattr(self.main.ai_engine, "last_decision") else None

#         if decision:
#             behavior = decision.get("behavior", "—")
#             fatigue = decision.get("fatigue_score", "—")
#             reason = decision.get("reason", "—")

#             self.card_status.update_value(
#                 f"Behavior: {behavior}\nFatigue: {fatigue}\nReason: {reason}"
#             )
#         else:
#             self.card_status.update_value("Analyzing…")

#         # Next break (AI estimate)
#         next_break = getattr(self.main.ai_engine, "next_break_estimate", None)
#         if next_break:
#             self.card_next_break.update_value(next_break)
#         else:
#             self.card_next_break.update_value("Calculating…")

#         # Meeting mode
#         meeting = "On" if getattr(self.main.signals, "in_meeting", False) else "Off"
#         self.card_meeting.update_value(meeting)














# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton
# )
# from PySide6.QtCore import Qt
# from ui.widgets.meeting_badge import MeetingBadge
# from ui.widgets.mini_chart import MiniChart


# class FluentCard(QFrame):
#     def __init__(self, title, value="—"):
#         super().__init__()
#         self.setObjectName("FluentCard")

#         # ⭐ Create layout FIRST
#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(14, 14, 14, 14)
#         layout.setSpacing(6)

#         # Meeting badge (hidden by default)
#         self.meeting_badge = MeetingBadge()
#         self.meeting_badge.hide()
#         layout.addWidget(self.meeting_badge, alignment=Qt.AlignLeft)

#         # Title
#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")
#         layout.addWidget(self.title_label)

#         # Value
#         self.value_label = QLabel(value)
#         self.value_label.setObjectName("CardValue")
#         layout.addWidget(self.value_label)

#         # Mini chart
#         self.chart = MiniChart()
#         layout.addWidget(self.chart)

#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)


# class AIModePage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main
#         self.setObjectName("AIModePage")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # -------------------------
#         # TOP ROW (AI Status + Behavior)
#         # -------------------------
#         top_row = QHBoxLayout()
#         top_row.setSpacing(20)

#         self.card_status = FluentCard("AI Status", "Waiting…")
#         self.card_behavior = FluentCard("Behavior", "—")

#         top_row.addWidget(self.card_status)
#         top_row.addWidget(self.card_behavior)

#         layout.addLayout(top_row)

#         # -------------------------
#         # SECOND ROW (Fatigue + Next Break)
#         # -------------------------
#         mid_row = QHBoxLayout()
#         mid_row.setSpacing(20)

#         self.card_fatigue = FluentCard("Fatigue Score", "—")
#         self.card_next_break = FluentCard("Next Break", "—")

#         mid_row.addWidget(self.card_fatigue)
#         mid_row.addWidget(self.card_next_break)

#         layout.addLayout(mid_row)

#         # -------------------------
#         # AI MESSAGE OUTPUT
#         # -------------------------
#         self.ai_message_box = QLabel("AI Assistant Messages Will Appear Here")
#         self.ai_message_box.setObjectName("AIMessageBox")
#         self.ai_message_box.setWordWrap(True)
#         self.ai_message_box.setMinimumHeight(120)

#         layout.addWidget(self.ai_message_box)

#         # -------------------------
#         # MANUAL REFRESH BUTTON
#         # -------------------------
#         self.btn_refresh = QPushButton("Refresh AI Status")
#         self.btn_refresh.clicked.connect(self.refresh_ai_status)
#         layout.addWidget(self.btn_refresh)

#     # -------------------------
#     # UPDATE AI MODE VALUES
#     # -------------------------
#     def refresh_ai_status(self):
#         """Called when the user presses the refresh button."""
#         data = self.main.ai_engine.get_status() if hasattr(self.main.ai_engine, "get_status") else {}

#         self.card_status.update_value(data.get("status", "—"))
#         self.card_behavior.update_value(data.get("behavior", "—"))
#         self.card_fatigue.update_value(data.get("fatigue", "—"))
#         self.card_next_break.update_value(data.get("next_break", "—"))

#         self.ai_message_box.setText(data.get("message", "No AI message available."))



















# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton
# )
# from PySide6.QtCore import Qt

# from ui.widgets.ai_ring import AIRing
# from ui.widgets.fatigue_gauge import FatigueGauge
# from ui.widgets.message_bubble import MessageBubble
# from ui.widgets.mini_chart import MiniChart
# from ui.widgets.meeting_badge import MeetingBadge


# # ---------------------------------------------------------
# # FLUENT CARD (generic)
# # ---------------------------------------------------------
# class FluentCard(QWidget):
#     def __init__(self, title, value="—"):
#         super().__init__()
#         self.setObjectName("FluentCard")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(14, 14, 14, 14)
#         layout.setSpacing(6)

#         self.meeting_badge = MeetingBadge()
#         self.meeting_badge.hide()
#         layout.addWidget(self.meeting_badge, alignment=Qt.AlignLeft)

#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")
#         layout.addWidget(self.title_label)

#         self.value_label = QLabel(value)
#         self.value_label.setObjectName("CardValue")
#         layout.addWidget(self.value_label)

#         self.chart = MiniChart()
#         layout.addWidget(self.chart)

#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)


# # ---------------------------------------------------------
# # AI MODE PAGE (corrected)
# # ---------------------------------------------------------
# class AIModePage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main
#         self.setObjectName("AIModePage")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # -------------------------------------------------
#         # AI RING + FATIGUE GAUGE
#         # -------------------------------------------------
#         self.ai_ring = AIRing()
#         self.fatigue_gauge = FatigueGauge()

#         ring_row = QHBoxLayout()
#         ring_row.setSpacing(20)
#         ring_row.addWidget(self.ai_ring)
#         ring_row.addWidget(self.fatigue_gauge)

#         layout.addLayout(ring_row)

#         # -------------------------------------------------
#         # STATUS CARDS
#         # -------------------------------------------------
#         top_row = QHBoxLayout()
#         top_row.setSpacing(20)

#         self.card_status = FluentCard("AI Status", "Waiting…")
#         self.meeting_badge = self.card_status.meeting_badge
#         self.card_behavior = FluentCard("Behavior", "—")

#         top_row.addWidget(self.card_status)
#         top_row.addWidget(self.card_behavior)

#         layout.addLayout(top_row)

#         mid_row = QHBoxLayout()
#         mid_row.setSpacing(20)

#         self.card_fatigue = FluentCard("Fatigue Score", "—")
#         self.card_next_break = FluentCard("Next Break", "—")

#         mid_row.addWidget(self.card_fatigue)
#         mid_row.addWidget(self.card_next_break)

#         layout.addLayout(mid_row)

#         # -------------------------------------------------
#         # MESSAGE BUBBLES
#         # -------------------------------------------------
#         self.messages_layout = QVBoxLayout()
#         layout.addLayout(self.messages_layout)

#         self.messages_layout.addWidget(
#             MessageBubble("AI is analyzing your behavior...", "ai")
#         )

#         # -------------------------------------------------
#         # START / STOP MONITORING BUTTON
#         # -------------------------------------------------
#         self.btn_monitor = QPushButton("Start Monitoring")
#         self.btn_monitor.setObjectName("PrimaryButton")
#         self.btn_monitor.setMinimumHeight(44)
#         self.btn_monitor.setCursor(Qt.PointingHandCursor)
#         self.btn_monitor.clicked.connect(self.toggle_monitoring)

#         layout.addWidget(self.btn_monitor)

#     # -----------------------------------------------------
#     # MONITORING TOGGLE (same as Smart Mode)
#     # -----------------------------------------------------
#     def toggle_monitoring(self):
#         self.main.toggle_monitoring()

#         if self.main.monitoring:
#             self.btn_monitor.setText("Stop Monitoring")
#         else:
#             self.btn_monitor.setText("Start Monitoring")

#     # -----------------------------------------------------
#     # UPDATE AI MODE VALUES
#     # -----------------------------------------------------
#     def refresh_ai_status(self):
#         data = self.main.ai_engine.get_status() if hasattr(self.main.ai_engine, "get_status") else {}

#         behavior = data.get("behavior", "—")
#         fatigue = data.get("fatigue", 0)

#         self.card_status.update_value(data.get("status", "—"))
#         self.card_behavior.update_value(behavior)
#         self.card_fatigue.update_value(str(fatigue))
#         self.card_next_break.update_value(data.get("next_break", "—"))

#         self.ai_ring.set_behavior(behavior)
#         self.ai_ring.set_fatigue(fatigue)
#         self.ai_ring.set_ai_active(True)

#         self.fatigue_gauge.set_value(fatigue)

#         msg = data.get("message", "No AI message available.")
#         self.messages_layout.addWidget(MessageBubble(msg, "ai"))





























# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton
# )
# from PySide6.QtCore import Qt, QTimer
# from ui.widgets.meeting_badge import MeetingBadge


# class FluentCard(QFrame):
#     def __init__(self, title, value="—"):
#         super().__init__()
#         self.setObjectName("FluentCard")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(14, 14, 14, 14)
#         layout.setSpacing(6)

#         # Meeting badge (hidden by default)
#         self.meeting_badge = MeetingBadge()
#         self.meeting_badge.hide()
#         layout.addWidget(self.meeting_badge, alignment=Qt.AlignLeft)

#         # Title
#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")
#         layout.addWidget(self.title_label)

#         # Value
#         self.value_label = QLabel(value)
#         self.value_label.setObjectName("CardValue")
#         layout.addWidget(self.value_label)

#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)


# class AIModePage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # -------------------------
#         # AI STATUS CARD
#         # -------------------------
#         self.card_status = FluentCard("AI Status", "Waiting…")
#         self.card_status.setMinimumHeight(150)
#         layout.addWidget(self.card_status)

#         # ⭐ Expose meeting badge for main_window
#         self.meeting_badge = self.card_status.meeting_badge

#         # -------------------------
#         # SECOND ROW (Behavior + Fatigue)
#         # -------------------------
#         row1 = QHBoxLayout()
#         row1.setSpacing(20)

#         self.card_behavior = FluentCard("Behavior", "—")
#         self.card_fatigue = FluentCard("Fatigue Score", "—")

#         row1.addWidget(self.card_behavior)
#         row1.addWidget(self.card_fatigue)

#         layout.addLayout(row1)

#         # -------------------------
#         # THIRD ROW (Reason + Trigger)
#         # -------------------------
#         row2 = QHBoxLayout()
#         row2.setSpacing(20)

#         self.card_reason = FluentCard("Reason", "—")
#         self.card_trigger = FluentCard("Break Trigger", "—")

#         row2.addWidget(self.card_reason)
#         row2.addWidget(self.card_trigger)

#         layout.addLayout(row2)

#         # -------------------------
#         # START / STOP BUTTON
#         # -------------------------
#         self.btn_toggle = QPushButton("Start Monitoring")
#         self.btn_toggle.setObjectName("PrimaryButton")
#         self.btn_toggle.setFixedHeight(44)
#         self.btn_toggle.clicked.connect(self.toggle_monitoring)

#         layout.addWidget(self.btn_toggle)

#         # Timer for updating UI
#         self.ui_timer = QTimer()
#         self.ui_timer.timeout.connect(self.update_ui)
#         self.ui_timer.start(1000)

#     # -------------------------
#     # START / STOP MONITORING
#     # -------------------------
#     def toggle_monitoring(self):
#         self.main.toggle_monitoring()

#         if self.main.monitoring:
#             self.btn_toggle.setText("Stop Monitoring")
#         else:
#             self.btn_toggle.setText("Start Monitoring")

#     # -------------------------
#     # UPDATE UI (called every second)
#     # -------------------------
#     def update_ui(self):
#         if not self.main.monitoring:
#             return

#         # AI Mode uses the AI engine's real_time
#         real_seconds = int(self.main.ai_engine.real_time)
#         hrs = real_seconds // 3600
#         mins = (real_seconds % 3600) // 60
#         secs = real_seconds % 60

#         self.card_status.update_value(
#             f"Running • {int(hrs):02d}:{int(mins):02d}:{int(secs):02d}"
#         )

#     # -------------------------
#     # UPDATE FROM MAINWINDOW
#     # -------------------------
#     def update_ai_status(self, behavior, fatigue, reason, trigger):
#         self.card_behavior.update_value(behavior.capitalize())
#         self.card_fatigue.update_value(str(fatigue))
#         self.card_reason.update_value(reason)
#         self.card_trigger.update_value("Break" if trigger else "No Break")










# # New architectural version

# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton
# )
# from PySide6.QtCore import Qt, QTimer
# from ui.widgets.meeting_badge import MeetingBadge
# import time


# class FluentCard(QFrame):
#     def __init__(self, title, value="—"):
#         super().__init__()
#         self.setObjectName("FluentCard")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(14, 14, 14, 14)
#         layout.setSpacing(6)

#         self.meeting_badge = MeetingBadge()
#         self.meeting_badge.hide()
#         layout.addWidget(self.meeting_badge, alignment=Qt.AlignLeft)

#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")
#         layout.addWidget(self.title_label)

#         self.value_label = QLabel(value)
#         self.value_label.setObjectName("CardValue")
#         layout.addWidget(self.value_label)

#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)


# class AIModePage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # STATUS CARD
#         self.card_status = FluentCard("AI Status", "Waiting…")
#         self.card_status.setMinimumHeight(150)
#         layout.addWidget(self.card_status)

#         self.meeting_badge = self.card_status.meeting_badge

#         # BEHAVIOR + FATIGUE
#         row1 = QHBoxLayout()
#         row1.setSpacing(20)

#         self.card_behavior = FluentCard("Behavior", "—")
#         self.card_fatigue = FluentCard("Fatigue Score", "—")

#         row1.addWidget(self.card_behavior)
#         row1.addWidget(self.card_fatigue)
#         layout.addLayout(row1)

#         # REASON + TRIGGER
#         row2 = QHBoxLayout()
#         row2.setSpacing(20)

#         self.card_reason = FluentCard("Reason", "—")
#         self.card_trigger = FluentCard("Break Trigger", "—")

#         row2.addWidget(self.card_reason)
#         row2.addWidget(self.card_trigger)
#         layout.addLayout(row2)

#         # START / STOP
#         self.btn_toggle = QPushButton("Start Monitoring")
#         self.btn_toggle.setObjectName("PrimaryButton")
#         self.btn_toggle.setFixedHeight(44)
#         self.btn_toggle.clicked.connect(self.toggle_monitoring)
#         layout.addWidget(self.btn_toggle)

#         # UI update timer
#         self.ui_timer = QTimer()
#         self.ui_timer.timeout.connect(self.update_ui)
#         self.ui_timer.start(500)

#     def toggle_monitoring(self):
#         self.main.toggle_monitoring()
#         self.btn_toggle.setText("Stop Monitoring" if self.main.monitoring else "Start Monitoring")

#     def update_ui(self):
#         if not self.main.monitoring:
#             return

#         if self.main.pages.currentWidget() != self:
#             return

#         engine = self.main.ai_engine

#         # TIMER
#         real_seconds = int(engine.real_time)
#         self.card_status.update_value(
#             f"Running • {time.strftime('%H:%M:%S', time.gmtime(real_seconds))}"
#         )

#     # Called from main_window
#     def update_ai_status(self, behavior, fatigue, reason, trigger):
#         self.card_behavior.update_value(behavior)
#         self.card_fatigue.update_value(str(fatigue))
#         self.card_reason.update_value(reason)
#         self.card_trigger.update_value("Break" if trigger else "No Break")

















# 5
# Upgraded

# Upgraded AIModePage — Premium, behavior-aware, consistent with reminder system

# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton
# )
# from PySide6.QtCore import Qt, QTimer
# from ui.widgets.meeting_badge import MeetingBadge
# import time


# class FluentCard(QFrame):
#     def __init__(self, title, value="—"):
#         super().__init__()
#         self.setObjectName("FluentCard")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(14, 14, 14, 14)
#         layout.setSpacing(6)

#         self.meeting_badge = MeetingBadge()
#         self.meeting_badge.hide()
#         layout.addWidget(self.meeting_badge, alignment=Qt.AlignLeft)

#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")
#         layout.addWidget(self.title_label)

#         self.value_label = QLabel(value)
#         self.value_label.setObjectName("CardValue")
#         layout.addWidget(self.value_label)

#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)


# class AIModePage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # STATUS CARD
#         self.card_status = FluentCard("AI Mode Status", "Waiting…")
#         self.card_status.setMinimumHeight(150)
#         layout.addWidget(self.card_status)

#         self.meeting_badge = self.card_status.meeting_badge

#         # BEHAVIOR + FATIGUE
#         row1 = QHBoxLayout()
#         row1.setSpacing(20)

#         self.card_behavior = FluentCard("Behavior", "—")
#         self.card_fatigue = FluentCard("Fatigue", "—")

#         row1.addWidget(self.card_behavior)
#         row1.addWidget(self.card_fatigue)
#         layout.addLayout(row1)

#         # REASON + BREAK
#         row2 = QHBoxLayout()
#         row2.setSpacing(20)

#         self.card_reason = FluentCard("Reason", "—")
#         self.card_trigger = FluentCard("Break", "—")

#         row2.addWidget(self.card_reason)
#         row2.addWidget(self.card_trigger)
#         layout.addLayout(row2)

#         # START / STOP
#         self.btn_toggle = QPushButton("Start Monitoring")
#         self.btn_toggle.setObjectName("PrimaryButton")
#         self.btn_toggle.setFixedHeight(44)
#         self.btn_toggle.clicked.connect(self.toggle_monitoring)
#         layout.addWidget(self.btn_toggle)

#         # UI update timer
#         self.ui_timer = QTimer()
#         self.ui_timer.timeout.connect(self.update_ui)
#         self.ui_timer.start(500)

#     def toggle_monitoring(self):
#         self.main.toggle_monitoring()
#         self.btn_toggle.setText("Stop Monitoring" if self.main.monitoring else "Start Monitoring")

#     def update_ui(self):
#         if not self.main.monitoring:
#             return

#         if self.main.pages.currentWidget() != self:
#             return

#         engine = self.main.ai_engine

#         # STATUS TIME
#         real_seconds = int(engine.real_time)
#         minutes = real_seconds // 60
#         self.card_status.update_value(f"Monitoring • {minutes}m")

#     # Called from main_window
#     def update_ai_status(self, behavior, fatigue, reason, trigger):

#         # Clean labels
#         behavior_clean = behavior.replace("_", " ").title()
#         reason_clean = reason.replace("_", " ").title()

#         # Behavior
#         self.card_behavior.update_value(behavior_clean)

#         # Fatigue
#         self.card_fatigue.update_value(f"{int(fatigue)} / 100")

#         # Reason
#         self.card_reason.update_value(reason_clean)

#         # Break Trigger
#         self.card_trigger.update_value("Break Triggered" if trigger else "No Break")

#         # Meeting badge
#         if behavior_clean.lower() == "meeting":
#             self.meeting_badge.show()
#         else:
#             self.meeting_badge.hide()












# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QSizePolicy, QScrollArea
# )
# from PySide6.QtCore import Qt
# import pyqtgraph as pg

# from core.analytics_engine import AnalyticsEngine


# CARD_HEIGHT = 320


# class AIModeCard(QFrame):
#     def __init__(self, title: str, accent_color: str):
#         super().__init__()
#         self.setObjectName("AIModeCard")
#         self.setMinimumHeight(CARD_HEIGHT)
#         self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(14, 14, 14, 14)
#         layout.setSpacing(8)

#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("AIModeCardTitle")
#         layout.addWidget(self.title_label)

#         self.accent = QFrame()
#         self.accent.setFixedHeight(4)
#         self.accent.setStyleSheet(f"background-color: {accent_color}; border-radius: 2px;")
#         layout.addWidget(self.accent)

#         self.body_layout = QVBoxLayout()
#         self.body_layout.setContentsMargins(0, 0, 0, 0)
#         self.body_layout.setSpacing(6)
#         layout.addLayout(self.body_layout)


# class AIModeSparkline(pg.PlotWidget):
#     def __init__(self, color: str):
#         super().__init__()
#         self.setBackground(None)
#         self.setFixedHeight(60)
#         self.setMenuEnabled(False)
#         self.setMouseEnabled(x=False, y=False)
#         self.showGrid(x=False, y=False)
#         self.getAxis("left").setVisible(False)
#         self.getAxis("bottom").setVisible(False)
#         self.setClipToView(True)
#         self.setAntialiasing(True)
#         self.color = color

#     def update_data(self, values):
#         self.clear()
#         if values:
#             self.plot(
#                 list(range(len(values))),
#                 values,
#                 pen=pg.mkPen(self.color, width=2)
#             )


# class AIModePage(QWidget):
#     def __init__(self):
#         super().__init__()
#         self.engine = AnalyticsEngine()

#         root = QVBoxLayout(self)
#         root.setContentsMargins(20, 20, 20, 20)
#         root.setSpacing(20)

#         title = QLabel("AI Mode")
#         title.setObjectName("PageTitle")
#         root.addWidget(title)

#         scroll = QScrollArea()
#         scroll.setWidgetResizable(True)
#         scroll.setFrameShape(QFrame.NoFrame)
#         root.addWidget(scroll)

#         container = QWidget()
#         scroll.setWidget(container)

#         self.layout = QVBoxLayout(container)
#         self.layout.setContentsMargins(10, 10, 10, 10)
#         self.layout.setSpacing(10)

#         self._build_ui()
#         self.refresh()

#     def _build_ui(self):
#         self.cards = {}

#         def add_row(*cards):
#             row = QHBoxLayout()
#             row.setSpacing(10)
#             for c in cards:
#                 row.addWidget(c)
#             self.layout.addLayout(row)

#         self.cards["behavior"] = AIModeCard("Behavior", "#0A84FF")
#         self.cards["behavior_spark"] = AIModeSparkline("#0A84FF")
#         self.cards["behavior"].body_layout.addWidget(self.cards["behavior_spark"])

#         self.cards["fatigue"] = AIModeCard("Fatigue", "#FF9F0A")
#         self.cards["fatigue_spark"] = AIModeSparkline("#FF9F0A")
#         self.cards["fatigue"].body_layout.addWidget(self.cards["fatigue_spark"])

#         add_row(self.cards["behavior"], self.cards["fatigue"])

#         self.cards["reason"] = AIModeCard("Reason", "#BF5AF2")
#         self.cards["reason_label"] = QLabel("")
#         self.cards["reason_label"].setWordWrap(True)
#         self.cards["reason"].body_layout.addWidget(self.cards["reason_label"])

#         self.cards["message"] = AIModeCard("Message", "#30D158")
#         self.cards["message_label"] = QLabel("")
#         self.cards["message_label"].setWordWrap(True)
#         self.cards["message"].body_layout.addWidget(self.cards["message_label"])

#         add_row(self.cards["reason"], self.cards["message"])

#         self.cards["next_break"] = AIModeCard("Next Break", "#30D158")
#         self.cards["next_break_spark"] = AIModeSparkline("#30D158")
#         self.cards["next_break"].body_layout.addWidget(self.cards["next_break_spark"])

#         self.cards["trigger"] = AIModeCard("Trigger", "#FF453A")
#         self.cards["trigger_label"] = QLabel("")
#         self.cards["trigger_label"].setWordWrap(True)
#         self.cards["trigger"].body_layout.addWidget(self.cards["trigger_label"])

#         add_row(self.cards["next_break"], self.cards["trigger"])

#         self.cards["summary"] = AIModeCard("Summary", "#0A84FF")
#         self.cards["summary_label"] = QLabel("")
#         self.cards["summary_label"].setWordWrap(True)
#         self.cards["summary"].body_layout.addWidget(self.cards["summary_label"])

#         self.layout.addWidget(self.cards["summary"])

#     def refresh(self):
#         data = self.engine.ai_mode_snapshot()

#         self.cards["behavior"].title_label.setText(f"Behavior: {data['behavior']}")
#         self.cards["behavior_spark"].update_data(data["behavior_trend"])

#         self.cards["fatigue"].title_label.setText(f"Fatigue: {data['fatigue']}/100")
#         self.cards["fatigue_spark"].update_data(data["fatigue_trend"])

#         self.cards["reason_label"].setText(data["reason"])
#         self.cards["message_label"].setText(data["message"])

#         self.cards["next_break_spark"].update_data(data["next_break_trend"])
#         self.cards["trigger_label"].setText(data["trigger"])

#         summary = (
#             f"Behavior: {data['behavior']}\n"
#             f"Fatigue: {data['fatigue']}/100\n"
#             f"Reason: {data['reason']}\n"
#             f"Message: {data['message']}\n"
#             f"Next Break: {data['next_break']} minutes\n"
#             f"Trigger: {data['trigger']}"
#         )
#         self.cards["summary_label"].setText(summary)
























# # ui/pages/ai_mode.py
# from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton

# from ui.pages.shared.fluent_card import FluentCard
# from ui.theme import AppColors
# from ui.animations import (
#     FadeInAnimator, SlideInAnimator, SparklineAnimator,
#     ValueAnimator, PulseAnimator
# )


# class AIModePage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main
#         self.setObjectName("AIModePage")

#         self.behavior_trend = []
#         self.fatigue_trend = []
#         self.break_trend = []

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # ROW 1
#         row1 = QHBoxLayout()
#         row1.setSpacing(20)
#         self.card_behavior = FluentCard("Behavior", AppColors.BEHAVIOR)
#         self.card_fatigue = FluentCard("Fatigue", AppColors.FATIGUE)
#         row1.addWidget(self.card_behavior)
#         row1.addWidget(self.card_fatigue)
#         layout.addLayout(row1)

#         # ROW 2
#         row2 = QHBoxLayout()
#         row2.setSpacing(20)
#         self.card_reason = FluentCard("Reason", AppColors.INSIGHT, has_spark=False)
#         self.card_next_break = FluentCard("Next Break", AppColors.BREAK)
#         row2.addWidget(self.card_reason)
#         row2.addWidget(self.card_next_break)
#         layout.addLayout(row2)

#         # MESSAGE
#         self.card_message = FluentCard("Message", AppColors.INSIGHT, has_spark=False)
#         layout.addWidget(self.card_message)

#         # SUPPRESSION
#         self.card_suppression = FluentCard("Suppression", AppColors.SUPPRESSION, has_spark=False)
#         layout.addWidget(self.card_suppression)

#         # SUMMARY
#         self.card_summary = FluentCard("Summary", AppColors.INSIGHT, has_spark=False)
#         layout.addWidget(self.card_summary)

#         # BUTTON
#         self.btn_toggle = QPushButton("Start AI Mode")
#         self.btn_toggle.setObjectName("PrimaryButton")
#         self.btn_toggle.setFixedHeight(44)
#         self.btn_toggle.clicked.connect(self.on_toggle_clicked)
#         layout.addWidget(self.btn_toggle)

#     def on_toggle_clicked(self):
#         self.main.show_ai()
#         self.main.toggle_monitoring()
#         self.btn_toggle.setText("Stop AI Mode" if self.main.monitoring else "Start AI Mode")

#     def update_ai_status(self, behavior, fatigue, reason, trigger, next_break_seconds):
#         # BEHAVIOR
#         self.card_behavior.update_value(behavior)
#         self.behavior_trend.append(len(self.behavior_trend) % 5)
#         self.behavior_trend = self.behavior_trend[-30:]
#         SparklineAnimator(self.card_behavior.spark, AppColors.BEHAVIOR).animate(self.behavior_trend)

#         # FATIGUE
#         ValueAnimator(
#             start_value=self._fatigue_value(),
#             end_value=int(fatigue),
#             duration=500,
#             callback=lambda v: self.card_fatigue.update_value(f"{int(v)}%"),
#         ).start()

#         self.fatigue_trend.append(int(fatigue))
#         self.fatigue_trend = self.fatigue_trend[-30:]
#         SparklineAnimator(self.card_fatigue.spark, AppColors.FATIGUE).animate(self.fatigue_trend)

#         # REASON
#         self.card_reason.update_value(reason)

#         # NEXT BREAK
#         nb = max(0, int(next_break_seconds))
#         self.card_next_break.update_value(f"{nb}s" if nb else "—")
#         self.break_trend.append(nb)
#         self.break_trend = self.break_trend[-30:]
#         SparklineAnimator(self.card_next_break.spark, AppColors.BREAK).animate(self.break_trend)

#         # MESSAGE
#         self.card_message.update_value("")

#         # SUPPRESSION
#         if "suppressed" in reason.lower():
#             self.card_suppression.update_value("Active")
#             PulseAnimator(self.card_suppression).start()
#         else:
#             self.card_suppression.update_value("None")

#         # SUMMARY
#         summary = (
#             f"Behavior: {behavior}\n"
#             f"Fatigue: {int(fatigue)}%\n"
#             f"Reason: {reason}\n"
#             f"Next Break: {nb}s\n"
#             f"Trigger: {'Yes' if trigger else 'No'}"
#         )
#         self.card_summary.update_value(summary)

#         # ANIMATIONS
#         for card in [
#             self.card_behavior, self.card_fatigue, self.card_reason,
#             self.card_next_break, self.card_message, self.card_suppression,
#             self.card_summary
#         ]:
#             FadeInAnimator(card).start()
#             SlideInAnimator(card.accent).start()

#     def _fatigue_value(self):
#         text = self.card_fatigue.value_label.text().replace("%", "").strip()
#         return int(text) if text.isdigit() else 0












# ui/pages/ai_mode.py

from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton
from PySide6.QtCore import Qt

from ui.pages.shared.fluent_card import FluentCard
from ui.widgets.fluent_blur import FluentBlur
from ui.core.theme import AppColors
from ui.animations import (
    FadeInAnimator, SlideInAnimator, SparklineAnimator,
    ValueAnimator, PulseAnimator
)


class AIModePage(QWidget):
    def __init__(self, main):
        super().__init__()
        self.main = main
        self.setObjectName("AIModePage")

        self.behavior_trend = []
        self.fatigue_trend = []
        self.break_trend = []

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(10)

        # ROW 1 — Behavior + Fatigue (260px each)
        row1 = QHBoxLayout()
        row1.setSpacing(20)

        self.card_behavior = FluentCard("Behavior", AppColors.BEHAVIOR)
        self.card_fatigue = FluentCard("Fatigue", AppColors.FATIGUE)

        self.card_behavior.setMinimumHeight(260)
        self.card_fatigue.setMinimumHeight(260)

        row1.addWidget(self._wrap_blur(self.card_behavior))
        row1.addWidget(self._wrap_blur(self.card_fatigue))
        layout.addLayout(row1)

        # ROW 2 — Reason (300px) + Next Break (180px)
        row2 = QHBoxLayout()
        row2.setSpacing(20)

        self.card_reason = FluentCard("Reason", AppColors.INSIGHT, has_spark=False)
        self.card_next_break = FluentCard("Next Break", AppColors.BREAK)

        self.card_reason.setMinimumHeight(300)
        self.card_next_break.setMinimumHeight(180)

        row2.addWidget(self._wrap_blur(self.card_reason))
        row2.addWidget(self._wrap_blur(self.card_next_break))
        layout.addLayout(row2)

        # MESSAGE (260px)
        self.card_message = FluentCard("Message", AppColors.INSIGHT, has_spark=False)
        self.card_message.setMinimumHeight(260)
        layout.addWidget(self._wrap_blur(self.card_message))

        # SUPPRESSION (260px)
        self.card_suppression = FluentCard("Suppression", AppColors.SUPPRESSION, has_spark=False)
        self.card_suppression.setMinimumHeight(260)
        layout.addWidget(self._wrap_blur(self.card_suppression))

        # SUMMARY (300px)
        self.card_summary = FluentCard("Summary", AppColors.INSIGHT, has_spark=False)
        self.card_summary.setMinimumHeight(300)
        layout.addWidget(self._wrap_blur(self.card_summary))

        # Stretch ensures Summary can expand without hitting the button
        layout.addStretch()

        # BUTTON — Left aligned, correct PySide6 signature
        self.btn_toggle = QPushButton("Start AI Mode")
        self.btn_toggle.setObjectName("PrimaryButton")
        self.btn_toggle.setFixedHeight(44)
        self.btn_toggle.setContentsMargins(0, 10, 0, 0)
        self.btn_toggle.clicked.connect(self.on_toggle_clicked)
        layout.addWidget(self.btn_toggle, 0, Qt.AlignLeft)

    def _wrap_blur(self, card: FluentCard) -> FluentBlur:
        blur = FluentBlur(radius=25, opacity=0.30)
        blur.layout.addWidget(card)
        return blur

    def on_toggle_clicked(self):
        self.main.show_ai()
        self.main.toggle_monitoring()
        self.btn_toggle.setText("Stop AI Mode" if self.main.monitoring else "Start AI Mode")

    def update_ai_status(self, behavior, fatigue, reason, trigger, next_break_seconds):
        # BEHAVIOR
        self.card_behavior.update_value(behavior)
        self.behavior_trend.append(len(self.behavior_trend) % 5)
        self.behavior_trend = self.behavior_trend[-30:]
        SparklineAnimator(self.card_behavior.spark, AppColors.BEHAVIOR).animate(self.behavior_trend)

        # FATIGUE
        ValueAnimator(
            start_value=self._fatigue_value(),
            end_value=int(fatigue),
            duration=500,
            callback=lambda v: self.card_fatigue.update_value(f"{int(v)}%"),
        ).start()

        self.fatigue_trend.append(int(fatigue))
        self.fatigue_trend = self.fatigue_trend[-30:]
        SparklineAnimator(self.card_fatigue.spark, AppColors.FATIGUE).animate(self.fatigue_trend)

        # REASON
        self.card_reason.update_value(reason)

        # NEXT BREAK
        nb = max(0, int(next_break_seconds))
        self.card_next_break.update_value(f"{nb}s" if nb else "—")
        self.break_trend.append(nb)
        self.break_trend = self.break_trend[-30:]
        SparklineAnimator(self.card_next_break.spark, AppColors.BREAK).animate(self.break_trend)

        # MESSAGE
        self.card_message.update_value("")

        # SUPPRESSION
        if "suppressed" in reason.lower():
            self.card_suppression.update_value("Active")
            PulseAnimator(self.card_suppression).start()
        else:
            self.card_suppression.update_value("None")

        # SUMMARY
        summary = (
            f"Behavior: {behavior}\n"
            f"Fatigue: {int(fatigue)}%\n"
            f"Reason: {reason}\n"
            f"Next Break: {nb}s\n"
            f"Trigger: {'Yes' if trigger else 'No'}"
        )
        self.card_summary.update_value(summary)

        # ANIMATIONS
        for card in [
            self.card_behavior, self.card_fatigue, self.card_reason,
            self.card_next_break, self.card_message, self.card_suppression,
            self.card_summary
        ]:
            FadeInAnimator(card).start()
            SlideInAnimator(card.accent).start()

    def _fatigue_value(self):
        text = self.card_fatigue.value_label.text().replace("%", "").strip()
        return int(text) if text.isdigit() else 0
