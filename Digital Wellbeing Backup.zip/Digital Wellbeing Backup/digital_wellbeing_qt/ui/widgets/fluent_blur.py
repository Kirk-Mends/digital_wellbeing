# ui/widgets/fluent_blur.py

from PySide6.QtWidgets import QWidget, QGraphicsBlurEffect, QVBoxLayout
from PySide6.QtGui import QColor, QPainter
from PySide6.QtCore import Qt

class FluentBlur(QWidget):
    """
    A translucent Fluent-style blurred background panel.
    Use this as a wrapper around any content.
    """

    def __init__(self, radius=20, opacity=0.35):
        super().__init__()

        self.opacity = opacity

        # Blur effect
        blur = QGraphicsBlurEffect()
        blur.setBlurRadius(radius)
        self.setGraphicsEffect(blur)

        # Transparent background
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAutoFillBackground(False)

        # Layout for child widgets
        self.layout = QVBoxLayout(self)
        self.layout.setContentsMargins(0, 0, 0, 0)

    def paintEvent(self, event):
        painter = QPainter(self)
        painter.setRenderHint(QPainter.Antialiasing)

        color = QColor(255, 255, 255, int(self.opacity * 255))
        painter.setBrush(color)
        painter.setPen(Qt.NoPen)

        painter.drawRoundedRect(self.rect(), 16, 16)
