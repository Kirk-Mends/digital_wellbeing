# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QListWidget, QListWidgetItem,
#     QLabel, QFrame, QComboBox, QSpinBox, QPushButton
# )
# from PySide6.QtCore import Qt


# class SettingsPage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main

#         layout = QHBoxLayout(self)
#         layout.setContentsMargins(0, 0, 0, 0)
#         layout.setSpacing(0)

#         # -----------------------------------------
#         # LEFT SIDEBAR (CATEGORY LIST)
#         # -----------------------------------------
#         self.sidebar = QListWidget()
#         self.sidebar.setObjectName("SettingsSidebar")
#         self.sidebar.setFixedWidth(200)

#         categories = [
#             "General",
#             "Theme",
#             "Break Mode",
#             "Break Interval",
#             "Notifications",
#             "Monitoring",
#             "Data & Privacy",
#             "About"
#         ]

#         for c in categories:
#             item = QListWidgetItem(c)
#             self.sidebar.addItem(item)

#         self.sidebar.currentRowChanged.connect(self.switch_panel)

#         layout.addWidget(self.sidebar)

#         # -----------------------------------------
#         # RIGHT PANEL (CONTENT AREA)
#         # -----------------------------------------
#         self.panel = QFrame()
#         self.panel.setObjectName("SettingsPanel")

#         self.panel_layout = QVBoxLayout(self.panel)
#         self.panel_layout.setContentsMargins(20, 20, 20, 20)
#         self.panel_layout.setSpacing(20)

#         layout.addWidget(self.panel, 1)

#         # Load first category
#         self.sidebar.setCurrentRow(0)

#     # -----------------------------------------
#     # SWITCH PANELS
#     # -----------------------------------------
#     def switch_panel(self, index):
#         # Clear old widgets
#         while self.panel_layout.count():
#             item = self.panel_layout.takeAt(0)
#             if item.widget():
#                 item.widget().deleteLater()

#         if index == 0:
#             self.load_general()
#         elif index == 1:
#             self.load_theme()
#         elif index == 2:
#             self.load_break_mode()
#         elif index == 3:
#             self.load_break_interval()
#         elif index == 4:
#             self.load_notifications()
#         elif index == 5:
#             self.load_monitoring()
#         elif index == 6:
#             self.load_privacy()
#         elif index == 7:
#             self.load_about()

#     # -----------------------------------------
#     # PANELS
#     # -----------------------------------------
#     def load_general(self):
#         title = QLabel("General Settings")
#         title.setObjectName("SettingsTitle")
#         self.panel_layout.addWidget(title)

#         desc = QLabel("Basic preferences for your wellbeing assistant.")
#         desc.setObjectName("SettingsDescription")
#         self.panel_layout.addWidget(desc)

#     def load_theme(self):
#         title = QLabel("Theme")
#         title.setObjectName("SettingsTitle")
#         self.panel_layout.addWidget(title)

#         combo = QComboBox()
#         combo.addItems(["light", "dark"])
#         combo.setCurrentText(self.main.settings.get("theme"))
#         combo.currentTextChanged.connect(self.change_theme)

#         self.panel_layout.addWidget(combo)

#     def change_theme(self, theme):
#         self.main.settings.set("theme", theme)
#         self.main.apply_theme()

#     def load_break_mode(self):
#         title = QLabel("Break Mode")
#         title.setObjectName("SettingsTitle")
#         self.panel_layout.addWidget(title)

#         combo = QComboBox()
#         combo.addItems(["strict", "hybrid", "ai"])
#         combo.setCurrentText(self.main.settings.get("break_mode"))
#         combo.currentTextChanged.connect(
#             lambda m: self.main.settings.set("break_mode", m)
#         )

#         self.panel_layout.addWidget(combo)

#     def load_break_interval(self):
#         title = QLabel("Break Interval (Strict Mode)")
#         title.setObjectName("SettingsTitle")
#         self.panel_layout.addWidget(title)

#         spin = QSpinBox()
#         spin.setRange(5, 120)
#         spin.setValue(int(self.main.settings.get("break_interval_minutes")))
#         spin.valueChanged.connect(
#             lambda v: self.main.settings.set("break_interval_minutes", v)
#         )

#         self.panel_layout.addWidget(spin)

#     def load_notifications(self):
#         title = QLabel("Notifications")
#         title.setObjectName("SettingsTitle")
#         self.panel_layout.addWidget(title)

#         desc = QLabel("Notification preferences will appear here.")
#         desc.setObjectName("SettingsDescription")
#         self.panel_layout.addWidget(desc)

#     def load_monitoring(self):
#         title = QLabel("Monitoring")
#         title.setObjectName("SettingsTitle")
#         self.panel_layout.addWidget(title)

#         desc = QLabel("Configure how monitoring behaves.")
#         desc.setObjectName("SettingsDescription")
#         self.panel_layout.addWidget(desc)

#     def load_privacy(self):
#         title = QLabel("Data & Privacy")
#         title.setObjectName("SettingsTitle")
#         self.panel_layout.addWidget(title)

#         desc = QLabel("Your data is processed locally. No cloud storage is used.")
#         desc.setObjectName("SettingsDescription")
#         self.panel_layout.addWidget(desc)

#     def load_about(self):
#         title = QLabel("About")
#         title.setObjectName("SettingsTitle")
#         self.panel_layout.addWidget(title)

#         desc = QLabel("Digital Wellbeing Assistant\nVersion 1.0")
#         desc.setObjectName("SettingsDescription")
#         self.panel_layout.addWidget(desc)



















# New architectural version


# # settings_page.py
# # ui/pages/settings.py

# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QLabel, QComboBox, QCheckBox,
#     QPushButton, QFrame
# )
# from PySide6.QtCore import Qt


# class SettingsPage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main
#         self.settings = main.settings

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(30, 30, 30, 30)
#         layout.setSpacing(20)

#         # -------------------------
#         # PAGE TITLE
#         # -------------------------
#         title = QLabel("Settings")
#         title.setObjectName("PageTitle")
#         layout.addWidget(title)

#         # -------------------------
#         # THEME SELECTOR
#         # -------------------------
#         theme_label = QLabel("Theme")
#         theme_label.setObjectName("SectionLabel")
#         layout.addWidget(theme_label)

#         self.theme_combo = QComboBox()
#         self.theme_combo.addItems(["light", "dark", "system"])
#         self.theme_combo.setCurrentText(self.settings.get("theme"))
#         self.theme_combo.currentTextChanged.connect(self.preview_theme)
#         layout.addWidget(self.theme_combo)

#         # -------------------------
#         # SOUND TOGGLE
#         # -------------------------
#         self.sound_toggle = QCheckBox("Enable Notification Sound")
#         self.sound_toggle.setChecked(self.settings.get("sound_enabled", True))
#         self.sound_toggle.stateChanged.connect(self.toggle_sound)
#         layout.addWidget(self.sound_toggle)

#         # -------------------------
#         # NOTIFICATION TOGGLE
#         # -------------------------
#         self.notify_toggle = QCheckBox("Enable Break Notifications")
#         self.notify_toggle.setChecked(self.settings.get("notifications_enabled", True))
#         self.notify_toggle.stateChanged.connect(self.toggle_notifications)
#         layout.addWidget(self.notify_toggle)

#         # -------------------------
#         # RESET BUTTON
#         # -------------------------
#         reset_btn = QPushButton("Reset to Defaults")
#         reset_btn.setObjectName("DangerButton")
#         reset_btn.clicked.connect(self.reset_settings)
#         layout.addWidget(reset_btn)

#         # -------------------------
#         # SPACER
#         # -------------------------
#         spacer = QFrame()
#         spacer.setMinimumHeight(40)
#         layout.addWidget(spacer)

#         layout.addStretch()

#     # -------------------------
#     # LIVE THEME PREVIEW
#     # -------------------------
#     def preview_theme(self, theme_name):
#         self.settings.set("theme", theme_name)
#         self.main.apply_theme()

#     # -------------------------
#     # SOUND TOGGLE
#     # -------------------------
#     def toggle_sound(self, state):
#         self.settings.set("sound_enabled", bool(state))

#     # -------------------------
#     # NOTIFICATION TOGGLE
#     # -------------------------
#     def toggle_notifications(self, state):
#         self.settings.set("notifications_enabled", bool(state))

#     # -------------------------
#     # RESET SETTINGS
#     # -------------------------
#     def reset_settings(self):
#         self.settings.reset()
#         self.main.apply_theme()

#         # Refresh UI
#         self.theme_combo.setCurrentText(self.settings.get("theme"))
#         self.sound_toggle.setChecked(self.settings.get("sound_enabled"))
#         self.notify_toggle.setChecked(self.settings.get("notifications_enabled"))
























from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QLabel, QComboBox, QCheckBox,
    QPushButton, QFileDialog, QHBoxLayout, QMessageBox
)
from PySide6.QtCore import Qt


class SettingsPage(QWidget):
    def __init__(self, main):
        super().__init__()
        self.main = main
        self.settings = main.settings

        layout = QVBoxLayout(self)
        layout.setContentsMargins(30, 30, 30, 30)
        layout.setSpacing(20)

        # -------------------------
        # PAGE TITLE
        # -------------------------
        title = QLabel("Settings")
        title.setObjectName("PageTitle")
        layout.addWidget(title)

        # ============================================================
        # THEME
        # ============================================================
        theme_label = QLabel("Theme")
        theme_label.setObjectName("SectionLabel")
        layout.addWidget(theme_label)

        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["light", "dark", "system"])
        self.theme_combo.setCurrentText(self.settings.get("theme"))
        self.theme_combo.currentTextChanged.connect(self.preview_theme)
        layout.addWidget(self.theme_combo)

        # ============================================================
        # SOUND
        # ============================================================
        self.sound_toggle = QCheckBox("Enable Notification Sound")
        self.sound_toggle.setChecked(self.settings.get("sound_enabled", True))
        self.sound_toggle.stateChanged.connect(self.toggle_sound)
        layout.addWidget(self.sound_toggle)

        # ============================================================
        # NOTIFICATIONS
        # ============================================================
        self.notify_toggle = QCheckBox("Enable Break Notifications")
        self.notify_toggle.setChecked(self.settings.get("notifications_enabled", True))
        self.notify_toggle.stateChanged.connect(self.toggle_notifications)
        layout.addWidget(self.notify_toggle)

        # ============================================================
        # PROFILES
        # ============================================================
        profile_label = QLabel("Profile")
        profile_label.setObjectName("SectionLabel")
        layout.addWidget(profile_label)

        profile_row = QHBoxLayout()

        self.profile_combo = QComboBox()
        self.profile_combo.addItems(self.settings.list_profiles())
        self.profile_combo.setCurrentText(self.settings.current_profile)
        self.profile_combo.currentTextChanged.connect(self.switch_profile)
        profile_row.addWidget(self.profile_combo)

        btn_new_profile = QPushButton("New")
        btn_new_profile.clicked.connect(self.create_profile)
        profile_row.addWidget(btn_new_profile)

        btn_delete_profile = QPushButton("Delete")
        btn_delete_profile.clicked.connect(self.delete_profile)
        profile_row.addWidget(btn_delete_profile)

        layout.addLayout(profile_row)

        # ============================================================
        # EXPORT / IMPORT
        # ============================================================
        export_btn = QPushButton("Export Settings")
        export_btn.clicked.connect(self.export_settings)
        layout.addWidget(export_btn)

        import_btn = QPushButton("Import Settings")
        import_btn.clicked.connect(self.import_settings)
        layout.addWidget(import_btn)

        # ============================================================
        # RESET
        # ============================================================
        reset_btn = QPushButton("Reset to Defaults")
        reset_btn.setObjectName("DangerButton")
        reset_btn.clicked.connect(self.reset_settings)
        layout.addWidget(reset_btn)

        layout.addStretch()

    # ============================================================
    # THEME PREVIEW
    # ============================================================
    def preview_theme(self, theme_name):
        self.settings.set("theme", theme_name)
        self.main.apply_theme()

    # ============================================================
    # SOUND
    # ============================================================
    def toggle_sound(self, state):
        self.settings.set("sound_enabled", bool(state))

    # ============================================================
    # NOTIFICATIONS
    # ============================================================
    def toggle_notifications(self, state):
        self.settings.set("notifications_enabled", bool(state))

    # ============================================================
    # PROFILES
    # ============================================================
    def switch_profile(self, profile_name):
        self.settings.switch_profile(profile_name)
        self.refresh_ui()
        self.main.apply_theme()

    def create_profile(self):
        name, ok = QFileDialog.getSaveFileName(
            self, "Create Profile", "", "Profile (*.json)"
        )
        if not ok or not name:
            return

        profile_name = name.split("/")[-1].replace(".json", "")
        self.settings.switch_profile(profile_name)
        self.refresh_ui()

    def delete_profile(self):
        profile = self.profile_combo.currentText()
        if profile == "default":
            QMessageBox.warning(self, "Error", "Cannot delete the default profile.")
            return

        self.settings.delete_profile(profile)
        self.profile_combo.clear()
        self.profile_combo.addItems(self.settings.list_profiles())
        self.profile_combo.setCurrentText(self.settings.current_profile)
        self.refresh_ui()

    # ============================================================
    # EXPORT / IMPORT
    # ============================================================
    def export_settings(self):
        path, ok = QFileDialog.getSaveFileName(
            self, "Export Settings", "", "JSON Files (*.json)"
        )
        if ok and path:
            self.settings.export_settings(path)

    def import_settings(self):
        path, ok = QFileDialog.getOpenFileName(
            self, "Import Settings", "", "JSON Files (*.json)"
        )
        if ok and path:
            self.settings.import_settings(path)
            self.refresh_ui()
            self.main.apply_theme()

    # ============================================================
    # RESET
    # ============================================================
    def reset_settings(self):
        self.settings.reset()
        self.refresh_ui()
        self.main.apply_theme()

    # ============================================================
    # REFRESH UI
    # ============================================================
    def refresh_ui(self):
        self.theme_combo.setCurrentText(self.settings.get("theme"))
        self.sound_toggle.setChecked(self.settings.get("sound_enabled"))
        self.notify_toggle.setChecked(self.settings.get("notifications_enabled"))
        self.profile_combo.clear()
        self.profile_combo.addItems(self.settings.list_profiles())
        self.profile_combo.setCurrentText(self.settings.current_profile)
