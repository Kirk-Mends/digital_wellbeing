# import csv
# from datetime import datetime, timedelta

# from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QHBoxLayout, QFrame
# from PySide6.QtCore import Qt
# import pyqtgraph as pg


# class WeeklyAnalyticsPage(QWidget):
#     def __init__(self):
#         super().__init__()
#         self.setObjectName("WeeklyAnalyticsPage")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # -------------------------
#         # TITLE
#         # -------------------------
#         title = QLabel("Weekly Analytics")
#         title.setObjectName("PageTitle")
#         layout.addWidget(title)

#         # -------------------------
#         # SUMMARY CARDS
#         # -------------------------
#         self.summary_container = QHBoxLayout()
#         layout.addLayout(self.summary_container)

#         self.card_avg = self.make_card("Average Active Minutes", "0")
#         self.card_total = self.make_card("Total Active Minutes", "0")
#         self.card_best = self.make_card("Best Day", "-")
#         self.card_trend = self.make_card("Trend", "-")

#         self.summary_container.addWidget(self.card_avg)
#         self.summary_container.addWidget(self.card_total)
#         self.summary_container.addWidget(self.card_best)
#         self.summary_container.addWidget(self.card_trend)

#         # -------------------------
#         # WEEKLY BAR CHART
#         # -------------------------
#         self.chart = pg.PlotWidget()
#         self.chart.setBackground(None)
#         self.chart.showGrid(x=False, y=True, alpha=0.2)
#         self.chart.getAxis("left").setVisible(False)
#         self.chart.getAxis("bottom").setVisible(False)

#         self.bar_item = pg.BarGraphItem(x=[], height=[], width=0.6, brush="#0078D7")
#         self.chart.addItem(self.bar_item)

#         layout.addWidget(self.chart)

#         # Load data immediately
#         self.update_weekly_data()

#     # -------------------------
#     # SUMMARY CARD WIDGET
#     # -------------------------
#     def make_card(self, title, value):
#         frame = QFrame()
#         frame.setObjectName("SummaryCard")
#         frame.setMinimumWidth(150)

#         v = QVBoxLayout(frame)
#         v.setContentsMargins(16, 16, 16, 16)

#         label_title = QLabel(title)
#         label_title.setObjectName("CardTitle")

#         label_value = QLabel(value)
#         label_value.setObjectName("CardValue")

#         v.addWidget(label_title)
#         v.addWidget(label_value)
#         v.addStretch()

#         frame.value_label = label_value
#         return frame

#     # -------------------------
#     # LOAD WEEKLY DATA
#     # -------------------------
#     def update_weekly_data(self):
#         today = datetime.now().date()
#         week_start = today - timedelta(days=today.weekday())  # Monday

#         dates = []
#         minutes = []

#         # Initialize dictionary for 7 days
#         daily = {week_start + timedelta(days=i): 0 for i in range(7)}

#         # Read CSV
#         try:
#             with open("usage_log.csv", "r") as f:
#                 reader = csv.DictReader(f)
#                 for row in reader:
#                     date = datetime.fromisoformat(row["date"]).date()
#                     if date in daily:
#                         daily[date] += float(row["active_minutes"])
#         except FileNotFoundError:
#             pass

#         # Convert to lists
#         dates = list(daily.keys())
#         minutes = list(daily.values())

#         # Update chart
#         x = list(range(7))
#         self.bar_item.setOpts(x=x, height=minutes)

#         # Update summary cards
#         avg = sum(minutes) / 7
#         total = sum(minutes)
#         best_day_index = minutes.index(max(minutes))
#         best_day = dates[best_day_index].strftime("%A")

#         # Trend: compare last week vs this week
#         trend = "↗ Improving" if minutes[-1] > minutes[0] else "↘ Declining"

#         self.card_avg.value_label.setText(f"{avg:.1f} min")
#         self.card_total.value_label.setText(f"{total:.0f} min")
#         self.card_best.value_label.setText(best_day)
#         self.card_trend.value_label.setText(trend)














# # Cleaned for UI nice seeing without dashes
# import csv
# from datetime import datetime, timedelta

# from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QHBoxLayout, QFrame
# from PySide6.QtCore import Qt
# import pyqtgraph as pg


# class WeeklyAnalyticsPage(QWidget):
#     def __init__(self):
#         super().__init__()
#         self.setObjectName("WeeklyAnalyticsPage")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # -------------------------
#         # TITLE
#         # -------------------------
#         title = QLabel("Weekly Analytics")
#         title.setObjectName("PageTitle")
#         layout.addWidget(title)

#         # -------------------------
#         # SUMMARY CARDS
#         # -------------------------
#         self.summary_container = QHBoxLayout()
#         layout.addLayout(self.summary_container)

#         self.card_avg = self.make_card("Average Active Minutes", "0")
#         self.card_total = self.make_card("Total Active Minutes", "0")
#         self.card_best = self.make_card("Best Day", "-")
#         self.card_trend = self.make_card("Trend", "-")

#         self.summary_container.addWidget(self.card_avg)
#         self.summary_container.addWidget(self.card_total)
#         self.summary_container.addWidget(self.card_best)
#         self.summary_container.addWidget(self.card_trend)

#         # -------------------------
#         # WEEKLY BAR CHART
#         # -------------------------
#         self.chart = pg.PlotWidget()
#         self.chart.setBackground(None)
#         self.chart.showGrid(x=False, y=True, alpha=0.2)
#         self.chart.getAxis("left").setVisible(False)
#         self.chart.getAxis("bottom").setVisible(False)

#         self.bar_item = pg.BarGraphItem(x=[], height=[], width=0.6, brush="#0078D7")
#         self.chart.addItem(self.bar_item)

#         layout.addWidget(self.chart)

#         # Load data immediately
#         self.update_weekly_data()

#     # -------------------------
#     # SUMMARY CARD WIDGET
#     # -------------------------
#     def make_card(self, title, value):
#         frame = QFrame()
#         frame.setObjectName("SummaryCard")
#         frame.setMinimumWidth(150)

#         v = QVBoxLayout(frame)
#         v.setContentsMargins(16, 16, 16, 16)

#         label_title = QLabel(title)
#         label_title.setObjectName("CardTitle")

#         label_value = QLabel(value)
#         label_value.setObjectName("CardValue")

#         v.addWidget(label_title)
#         v.addWidget(label_value)
#         v.addStretch()

#         frame.value_label = label_value
#         return frame

#     # -------------------------
#     # LOAD WEEKLY DATA
#     # -------------------------
#     def update_weekly_data(self):
#         today = datetime.now().date()
#         week_start = today - timedelta(days=today.weekday())  # Monday

#         # Initialize dictionary for 7 days
#         daily = {week_start + timedelta(days=i): 0 for i in range(7)}

#         # Read CSV
#         try:
#             with open("usage_log.csv", "r") as f:
#                 reader = csv.DictReader(f)
#                 for row in reader:
#                     date = datetime.fromisoformat(row["date"]).date()
#                     if date in daily:
#                         daily[date] += float(row["active_minutes"])
#         except FileNotFoundError:
#             pass

#         # Convert to lists
#         dates = list(daily.keys())
#         minutes = list(daily.values())

#         # Update chart
#         x = list(range(7))
#         self.bar_item.setOpts(x=x, height=minutes)

#         # Update summary cards
#         avg = sum(minutes) / 7
#         total = sum(minutes)
#         best_day_index = minutes.index(max(minutes))
#         best_day = dates[best_day_index].strftime("%A")

#         # Trend: compare first vs last day
#         if minutes[-1] > minutes[0]:
#             trend = "↗ Improving"
#         elif minutes[-1] < minutes[0]:
#             trend = "↘ Declining"
#         else:
#             trend = "→ Stable"

#         self.card_avg.value_label.setText(f"{avg:.1f} min")
#         self.card_total.value_label.setText(f"{total:.0f} min")
#         self.card_best.value_label.setText(best_day)
#         self.card_trend.value_label.setText(trend)
















# Cleaned for UI nice seeing without dashes
from datetime import datetime, timedelta
from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QHBoxLayout, QFrame
from PySide6.QtCore import Qt
import pyqtgraph as pg

from core.weekly_summary_engine import WeeklySummaryEngine


class WeeklyAnalyticsPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("WeeklyAnalyticsPage")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)

        # -------------------------
        # TITLE
        # -------------------------
        title = QLabel("Weekly Analytics")
        title.setObjectName("PageTitle")
        layout.addWidget(title)

        # -------------------------
        # SUMMARY CARDS
        # -------------------------
        self.summary_container = QHBoxLayout()
        layout.addLayout(self.summary_container)

        self.card_avg = self.make_card("Average Focus Minutes", "0")
        self.card_total = self.make_card("Total Focus Minutes", "0")
        self.card_best = self.make_card("Strongest Day", "-")
        self.card_trend = self.make_card("Trend", "-")

        self.summary_container.addWidget(self.card_avg)
        self.summary_container.addWidget(self.card_total)
        self.summary_container.addWidget(self.card_best)
        self.summary_container.addWidget(self.card_trend)

        # -------------------------
        # WEEKLY BAR CHART
        # -------------------------
        self.chart = pg.PlotWidget()
        self.chart.setBackground(None)
        self.chart.showGrid(x=False, y=True, alpha=0.2)
        self.chart.getAxis("left").setVisible(False)
        self.chart.getAxis("bottom").setVisible(False)

        self.bar_item = pg.BarGraphItem(x=[], height=[], width=0.6, brush="#0078D7")
        self.chart.addItem(self.bar_item)

        layout.addWidget(self.chart)

        # Load data immediately
        self.update_weekly_data()

    # -------------------------
    # SUMMARY CARD WIDGET
    # -------------------------
    def make_card(self, title, value):
        frame = QFrame()
        frame.setObjectName("SummaryCard")
        frame.setMinimumWidth(150)

        v = QVBoxLayout(frame)
        v.setContentsMargins(16, 16, 16, 16)

        label_title = QLabel(title)
        label_title.setObjectName("CardTitle")

        label_value = QLabel(value)
        label_value.setObjectName("CardValue")

        v.addWidget(label_title)
        v.addWidget(label_value)
        v.addStretch()

        frame.value_label = label_value
        return frame

    # -------------------------
    # LOAD WEEKLY DATA (NEW)
    # -------------------------
    def update_weekly_data(self):
        engine = WeeklySummaryEngine()
        summary = engine.generate_this_week()

        # Extract values
        total = summary["total_focus"]
        avg = total / 7
        deep_work = summary["deep_work"]
        deep_reading = summary["deep_reading"]
        focused_interaction = summary["focused_interaction"]

        # Build bar chart data (focus minutes per day)
        # We load daily summaries directly from storage
        week_start = datetime.strptime(summary["week_start"], "%Y-%m-%d")
        daily_values = []

        for i in range(7):
            date_str = (week_start).strftime("%Y-%m-%d")
            row = engine.storage.get_daily_summary(date_str)
            if row:
                daily_values.append(row[1])  # total_focus
            else:
                daily_values.append(0)
            week_start += timedelta(days=1)

        # Update chart
        x = list(range(7))
        self.bar_item.setOpts(x=x, height=daily_values)

        # Best day
        best_index = daily_values.index(max(daily_values))
        best_day = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"][best_index]

        # Trend
        if daily_values[-1] > daily_values[0]:
            trend = "↗ Improving"
        elif daily_values[-1] < daily_values[0]:
            trend = "↘ Declining"
        else:
            trend = "→ Stable"

        # Update summary cards
        self.card_avg.value_label.setText(f"{avg:.1f} min")
        self.card_total.value_label.setText(f"{total:.0f} min")
        self.card_best.value_label.setText(best_day)
        self.card_trend.value_label.setText(trend)
