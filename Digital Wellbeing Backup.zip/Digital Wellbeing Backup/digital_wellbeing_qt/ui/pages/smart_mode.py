















# # ui/pages/smart_mode.py

# import time
# from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton
# from PySide6.QtCore import Qt

# from ui.pages.shared.fluent_card import FluentCard
# from ui.widgets.fluent_blur import FluentBlur
# from ui.core.theme import AppColors
# from ui.animations import (
#     FadeInAnimator, SlideInAnimator, SparklineAnimator,
#     ValueAnimator, PulseAnimator
# )


# class SmartModePage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main
#         self.setObjectName("SmartModePage")

#         self.behavior_trend = []
#         self.fatigue_trend = []
#         self.interval_trend = []

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(0)

#         # TIMER
#         self.card_timer = FluentCard("Smart Mode Timer", AppColors.BREAK, has_spark=False)
#         layout.addWidget(self._wrap_blur(self.card_timer))

#         # ROW 1 — Behavior + Fatigue (260px each)
#         row1 = QHBoxLayout()
#         row1.setSpacing(20)

#         self.card_behavior = FluentCard("Behavior", AppColors.BEHAVIOR)
#         self.card_fatigue = FluentCard("Fatigue", AppColors.FATIGUE)

#         self.card_behavior.setMinimumHeight(260)
#         self.card_fatigue.setMinimumHeight(260)

#         row1.addWidget(self._wrap_blur(self.card_behavior))
#         row1.addWidget(self._wrap_blur(self.card_fatigue))
#         layout.addLayout(row1)

#         # ROW 2 — Reason (300px) + Next Break (180px)
#         row2 = QHBoxLayout()
#         row2.setSpacing(20)

#         self.card_reason = FluentCard("Reason", AppColors.INSIGHT, has_spark=False)
#         self.card_next_break = FluentCard("Next Break", AppColors.BREAK)

#         self.card_reason.setMinimumHeight(300)
#         self.card_next_break.setMinimumHeight(180)

#         row2.addWidget(self._wrap_blur(self.card_reason))
#         row2.addWidget(self._wrap_blur(self.card_next_break))
#         layout.addLayout(row2)

#         # SUPPRESSION (260px)
#         self.card_suppression = FluentCard("Suppression", AppColors.SUPPRESSION, has_spark=False)
#         self.card_suppression.setMinimumHeight(260)
#         layout.addWidget(self._wrap_blur(self.card_suppression))

#         # SUMMARY (300px)
#         self.card_summary = FluentCard("Summary", AppColors.INSIGHT, has_spark=False)
#         self.card_summary.setMinimumHeight(300)
#         layout.addWidget(self._wrap_blur(self.card_summary))

#         # Stretch ensures Summary can expand without hitting the button
#         layout.addStretch()

#         # BUTTON — Left aligned, correct PySide6 signature
#         self.btn_toggle = QPushButton("Start Smart Mode")
#         self.btn_toggle.setObjectName("PrimaryButton")
#         self.btn_toggle.setFixedHeight(44)
#         self.btn_toggle.setContentsMargins(0, 10, 0, 0)
#         self.btn_toggle.clicked.connect(self.on_toggle_clicked)
#         layout.addWidget(self.btn_toggle, 0, Qt.AlignLeft)

#     def _wrap_blur(self, card: FluentCard) -> FluentBlur:
#         blur = FluentBlur(radius=25, opacity=0.30)
#         blur.layout.addWidget(card)
#         return blur

#     def on_toggle_clicked(self):
#         self.main.show_smart()
#         self.main.toggle_monitoring()
#         self.btn_toggle.setText("Stop Smart Mode" if self.main.monitoring else "Start Smart Mode")

#     def update_smart_status(self, behavior, fatigue, reason, trigger, next_break_seconds):
#         # TIMER
#         elapsed = 0
#         engine = self.main.hybrid_engine
#         if engine.session_start and self.main.monitoring and self.main.active_monitoring_mode == "Smart Mode":
#             elapsed = int(time.time() - engine.session_start)
#         self.card_timer.update_value(time.strftime("%H:%M:%S", time.gmtime(elapsed)))

#         # BEHAVIOR
#         self.card_behavior.update_value(behavior)
#         self.behavior_trend.append(len(self.behavior_trend) % 5)
#         self.behavior_trend = self.behavior_trend[-30:]
#         SparklineAnimator(self.card_behavior.spark, AppColors.BEHAVIOR).animate(self.behavior_trend)

#         # FATIGUE
#         ValueAnimator(
#             start_value=self._fatigue_value(),
#             end_value=int(fatigue),
#             duration=500,
#             callback=lambda v: self.card_fatigue.update_value(f"{int(v)}%"),
#         ).start()

#         self.fatigue_trend.append(int(fatigue))
#         self.fatigue_trend = self.fatigue_trend[-30:]
#         SparklineAnimator(self.card_fatigue.spark, AppColors.FATIGUE).animate(self.fatigue_trend)

#         # REASON
#         self.card_reason.update_value(reason)

#         # NEXT BREAK
#         nb = max(0, int(next_break_seconds))
#         self.card_next_break.update_value(f"{nb}s" if nb else "—")
#         self.interval_trend.append(nb)
#         self.interval_trend = self.interval_trend[-30:]
#         SparklineAnimator(self.card_next_break.spark, AppColors.BREAK).animate(self.interval_trend)

#         # SUPPRESSION
#         if "suppressed" in reason.lower():
#             self.card_suppression.update_value("Active")
#             PulseAnimator(self.card_suppression).start()
#         else:
#             self.card_suppression.update_value("None")

#         # SUMMARY
#         summary = (
#             f"Behavior: {behavior}\n"
#             f"Fatigue: {int(fatigue)}%\n"
#             f"Reason: {reason}\n"
#             f"Next Break: {nb}s\n"
#             f"Trigger: {'Yes' if trigger else 'No'}"
#         )
#         self.card_summary.update_value(summary)

#         # ANIMATIONS
#         for card in [
#             self.card_timer, self.card_behavior, self.card_fatigue,
#             self.card_reason, self.card_next_break, self.card_suppression,
#             self.card_summary
#         ]:
#             FadeInAnimator(card).start()
#             SlideInAnimator(card.accent).start()

#     def _fatigue_value(self):
#         text = self.card_fatigue.value_label.text().replace("%", "").strip()
#         return int(text) if text.isdigit() else 0





















# I only changed arrangement for row 3

# ui/pages/smart_mode.py

# # ui/pages/smart_mode.py

# import time
# from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton
# from PySide6.QtCore import Qt

# from ui.pages.shared.fluent_card import FluentCard
# from ui.widgets.fluent_blur import FluentBlur
# from ui.core.theme import AppColors
# from ui.animations import (
#     FadeInAnimator, SlideInAnimator, SparklineAnimator,
#     ValueAnimator, PulseAnimator
# )


# class SmartModePage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main
#         self.setObjectName("SmartModePage")

#         self.behavior_trend = []
#         self.fatigue_trend = []
#         self.interval_trend = []

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(0)

#         # TIMER
#         self.card_timer = FluentCard("Smart Mode Timer", AppColors.BREAK, has_spark=False)
#         layout.addWidget(self._wrap_blur(self.card_timer))

#         # ROW 1 — Behavior + Fatigue (260px each)
#         row1 = QHBoxLayout()
#         row1.setSpacing(20)

#         self.card_behavior = FluentCard("Behavior", AppColors.BEHAVIOR)
#         self.card_fatigue = FluentCard("Fatigue", AppColors.FATIGUE)

#         self.card_behavior.setMinimumHeight(260)
#         self.card_fatigue.setMinimumHeight(260)

#         row1.addWidget(self._wrap_blur(self.card_behavior))
#         row1.addWidget(self._wrap_blur(self.card_fatigue))
#         layout.addLayout(row1)

#         # ROW 2 — Next Break (180px) + Reason (300px) + Suppression (180px)
#         row2 = QHBoxLayout()
#         row2.setSpacing(20)

#         self.card_next_break = FluentCard("Next Break", AppColors.BREAK)
#         self.card_reason = FluentCard("Reason", AppColors.INSIGHT, has_spark=False)
#         self.card_suppression = FluentCard("Suppression", AppColors.SUPPRESSION, has_spark=False)

#         self.card_next_break.setMinimumHeight(150)
#         self.card_reason.setMinimumHeight(300)
#         self.card_suppression.setMinimumHeight(180)
#         self.card_next_break.setMaximumHeight(180)

#         # ORDER: Next Break → Reason → Suppression
#         row2.addWidget(self._wrap_blur(self.card_next_break), 1)
#         row2.addWidget(self._wrap_blur(self.card_reason), 2)
#         row2.addWidget(self._wrap_blur(self.card_suppression), 1)
#         layout.addLayout(row2)

#         # SUMMARY (300px)
#         self.card_summary = FluentCard("Summary", AppColors.INSIGHT, has_spark=False)
#         self.card_summary.setMinimumHeight(300)
#         layout.addWidget(self._wrap_blur(self.card_summary))

#         layout.addStretch()

#         # BUTTON — Left aligned
#         self.btn_toggle = QPushButton("Start Smart Mode")
#         self.btn_toggle.setObjectName("PrimaryButton")
#         self.btn_toggle.setFixedHeight(44)
#         self.btn_toggle.setContentsMargins(0, 10, 0, 0)
#         self.btn_toggle.clicked.connect(self.on_toggle_clicked)
#         layout.addWidget(self.btn_toggle, 0, Qt.AlignLeft)

#     def _wrap_blur(self, card: FluentCard) -> FluentBlur:
#         blur = FluentBlur(radius=25, opacity=0.30)
#         blur.layout.addWidget(card)
#         return blur

#     def on_toggle_clicked(self):
#         self.main.show_smart()
#         self.main.toggle_monitoring()
#         self.btn_toggle.setText("Stop Smart Mode" if self.main.monitoring else "Start Smart Mode")

#     def update_smart_status(self, behavior, fatigue, reason, trigger, next_break_seconds):
#         # TIMER
#         elapsed = 0
#         engine = self.main.hybrid_engine
#         if engine.session_start and self.main.monitoring and self.main.active_monitoring_mode == "Smart Mode":
#             elapsed = int(time.time() - engine.session_start)
#         self.card_timer.update_value(time.strftime("%H:%M:%S", time.gmtime(elapsed)))

#         # BEHAVIOR
#         self.card_behavior.update_value(behavior)
#         self.behavior_trend.append(len(self.behavior_trend) % 5)
#         self.behavior_trend = self.behavior_trend[-30:]
#         SparklineAnimator(self.card_behavior.spark, AppColors.BEHAVIOR).animate(self.behavior_trend)

#         # FATIGUE
#         ValueAnimator(
#             start_value=self._fatigue_value(),
#             end_value=int(fatigue),
#             duration=500,
#             callback=lambda v: self.card_fatigue.update_value(f"{int(v)}%"),
#         ).start()

#         self.fatigue_trend.append(int(fatigue))
#         self.fatigue_trend = self.fatigue_trend[-30:]
#         SparklineAnimator(self.card_fatigue.spark, AppColors.FATIGUE).animate(self.fatigue_trend)

#         # REASON
#         self.card_reason.update_value(reason)

#         # NEXT BREAK
#         nb = max(0, int(next_break_seconds))
#         self.card_next_break.update_value(f"{nb}s" if nb else "—")
#         self.interval_trend.append(nb)
#         self.interval_trend = self.interval_trend[-30:]
#         SparklineAnimator(self.card_next_break.spark, AppColors.BREAK).animate(self.interval_trend)

#         # SUPPRESSION
#         if "suppressed" in reason.lower():
#             self.card_suppression.update_value("Active")
#             PulseAnimator(self.card_suppression).start()
#         else:
#             self.card_suppression.update_value("None")

#         # SUMMARY
#         summary = (
#             f"Behavior: {behavior}\n"
#             f"Fatigue: {int(fatigue)}%\n"
#             f"Reason: {reason}\n"
#             f"Next Break: {nb}s\n"
#             f"Trigger: {'Yes' if trigger else 'No'}"
#         )
#         self.card_summary.update_value(summary)

#         # ANIMATIONS
#         for card in [
#             self.card_timer, self.card_behavior, self.card_fatigue,
#             self.card_reason, self.card_next_break, self.card_suppression,
#             self.card_summary
#         ]:
#             FadeInAnimator(card).start()
#             SlideInAnimator(card.accent).start()

#     def _fatigue_value(self):
#         text = self.card_fatigue.value_label.text().replace("%", "").strip()
#         return int(text) if text.isdigit() else 0
















# # ui/pages/smart_mode.py

# import time
# from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton
# from PySide6.QtCore import Qt

# from ui.pages.shared.fluent_card import FluentCard
# from ui.widgets.fluent_blur import FluentBlur
# from ui.core.theme import AppColors
# from ui.animations import (
#     FadeInAnimator, SlideInAnimator, SparklineAnimator,
#     ValueAnimator, PulseAnimator
# )


# class SmartModePage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main
#         self.setObjectName("SmartModePage")

#         self.behavior_trend = []
#         self.fatigue_trend = []
#         self.interval_trend = []

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(0)

#         # TIMER
#         self.card_timer = FluentCard("Smart Mode Timer", AppColors.BREAK, has_spark=False)
#         layout.addWidget(self._wrap_blur(self.card_timer))

#         # ROW 1 — Behavior + Fatigue (260px each)
#         row1 = QHBoxLayout()
#         row1.setSpacing(20)

#         self.card_behavior = FluentCard("Behavior", AppColors.BEHAVIOR)
#         self.card_fatigue = FluentCard("Fatigue", AppColors.FATIGUE)

#         self.card_behavior.setMinimumHeight(260)
#         self.card_fatigue.setMinimumHeight(260)

#         row1.addWidget(self._wrap_blur(self.card_behavior))
#         row1.addWidget(self._wrap_blur(self.card_fatigue))
#         layout.addLayout(row1)

#         # ROW 2 — Next Break (180px) + Reason (300px) + Suppression (180px)
#         row2 = QHBoxLayout()
#         row2.setSpacing(20)

#         self.card_next_break = FluentCard("Next Break", AppColors.BREAK)
#         self.card_reason = FluentCard("Reason", AppColors.INSIGHT, has_spark=False)
#         self.card_suppression = FluentCard("Suppression", AppColors.SUPPRESSION, has_spark=False)

#         self.card_next_break.setMinimumHeight(150)
#         self.card_reason.setMinimumHeight(300)
#         self.card_suppression.setMinimumHeight(180)
#         self.card_next_break.setMaximumHeight(180)

#         # ORDER: Next Break → Reason → Suppression
#         row2.addWidget(self._wrap_blur(self.card_next_break), 1)
#         row2.addWidget(self._wrap_blur(self.card_reason), 2)
#         row2.addWidget(self._wrap_blur(self.card_suppression), 1)
#         layout.addLayout(row2)

#         # SUMMARY (300px)
#         self.card_summary = FluentCard("Summary", AppColors.INSIGHT, has_spark=False)
#         self.card_summary.setMinimumHeight(300)
#         layout.addWidget(self._wrap_blur(self.card_summary))

#         layout.addStretch()

#         # BUTTON — Left aligned
#         self.btn_toggle = QPushButton("Start Smart Mode")
#         self.btn_toggle.setObjectName("PrimaryButton")
#         self.btn_toggle.setFixedHeight(44)
#         self.btn_toggle.setContentsMargins(0, 10, 0, 0)
#         self.btn_toggle.clicked.connect(self.on_toggle_clicked)
#         layout.addWidget(self.btn_toggle, 0, Qt.AlignLeft)

#     def _wrap_blur(self, card: FluentCard) -> FluentBlur:
#         blur = FluentBlur(radius=25, opacity=0.30)
#         blur.layout.addWidget(card)
#         return blur

#     def on_toggle_clicked(self):
#         self.main.show_smart()
#         self.main.toggle_monitoring()
#         self.btn_toggle.setText("Stop Smart Mode" if self.main.monitoring else "Start Smart Mode")

#     def update_smart_status(self, behavior, fatigue, reason, trigger, next_break_seconds):
#         engine = self.main.hybrid_engine

#         # -----------------------------
#         # DEBUG PRINTS
#         # -----------------------------
#         print("\n--- SMART MODE DEBUG ---")
#         print("Behavior:", behavior)
#         print("Fatigue:", fatigue)
#         print("Reason:", reason)
#         print("Trigger:", trigger)
#         print("Next Break Seconds:", next_break_seconds)

#         print("session_start:", engine.session_start)
#         print("last_break_time:", engine.last_break_time)

#         if engine.session_start:
#             elapsed_debug = time.time() - engine.session_start
#         else:
#             elapsed_debug = None
#         print("Elapsed (debug):", elapsed_debug)

#         signals = getattr(self.main, "last_signals", None)
#         if signals:
#             print("idle_seconds:", signals.get("idle_seconds"))
#             print("screen_locked:", signals.get("screen_locked"))
#             print("raw behavior key:", signals.get("behavior"))
#         else:
#             print("No signals found in main.last_signals")
#         print("--- END DEBUG ---\n")
#         # -----------------------------
#         # END DEBUG PRINTS
#         # -----------------------------

#         # TIMER
#         elapsed = 0
#         if engine.session_start and self.main.monitoring and self.main.active_monitoring_mode == "Smart Mode":
#             elapsed = int(time.time() - engine.session_start)
#         self.card_timer.update_value(time.strftime("%H:%M:%S", time.gmtime(elapsed)))

#         # BEHAVIOR
#         self.card_behavior.update_value(behavior)
#         self.behavior_trend.append(len(self.behavior_trend) % 5)
#         self.behavior_trend = self.behavior_trend[-30:]
#         SparklineAnimator(self.card_behavior.spark, AppColors.BEHAVIOR).animate(self.behavior_trend)

#         # FATIGUE
#         ValueAnimator(
#             start_value=self._fatigue_value(),
#             end_value=int(fatigue),
#             duration=500,
#             callback=lambda v: self.card_fatigue.update_value(f"{int(v)}%"),
#         ).start()

#         self.fatigue_trend.append(int(fatigue))
#         self.fatigue_trend = self.fatigue_trend[-30:]
#         SparklineAnimator(self.card_fatigue.spark, AppColors.FATIGUE).animate(self.fatigue_trend)

#         # REASON
#         self.card_reason.update_value(reason)

#         # NEXT BREAK
#         nb = max(0, int(next_break_seconds))
#         self.card_next_break.update_value(f"{nb}s" if nb else "—")
#         self.interval_trend.append(nb)
#         self.interval_trend = self.interval_trend[-30:]
#         SparklineAnimator(self.card_next_break.spark, AppColors.BREAK).animate(self.interval_trend)

#         # SUPPRESSION
#         if "suppressed" in reason.lower():
#             self.card_suppression.update_value("Active")
#             PulseAnimator(self.card_suppression).start()
#         else:
#             self.card_suppression.update_value("None")

#         # SUMMARY
#         summary = (
#             f"Behavior: {behavior}\n"
#             f"Fatigue: {int(fatigue)}%\n"
#             f"Reason: {reason}\n"
#             f"Next Break: {nb}s\n"
#             f"Trigger: {'Yes' if trigger else 'No'}"
#         )
#         self.card_summary.update_value(summary)

#         # ANIMATIONS
#         for card in [
#             self.card_timer, self.card_behavior, self.card_fatigue,
#             self.card_reason, self.card_next_break, self.card_suppression,
#             self.card_summary
#         ]:
#             FadeInAnimator(card).start()
#             SlideInAnimator(card.accent).start()

#     def _fatigue_value(self):
#         text = self.card_fatigue.value_label.text().replace("%", "").strip()
#         return int(text) if text.isdigit() else 0



















# New arrangements

# # ui/pages/smart_mode.py

# import time
# from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton
# from PySide6.QtCore import Qt

# from ui.pages.shared.fluent_card import FluentCard
# from ui.widgets.fluent_blur import FluentBlur
# from ui.core.theme import AppColors
# from ui.animations import (
#     FadeInAnimator, SlideInAnimator, SparklineAnimator,
#     ValueAnimator, PulseAnimator
# )


# class SmartModePage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main
#         self.setObjectName("SmartModePage")

#         self.behavior_trend = []
#         self.fatigue_trend = []
#         self.interval_trend = []

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(0)

#         # ============================================
#         # TOP ROW — Timer + Behavior + Fatigue
#         # ============================================
#         top_row = QHBoxLayout()
#         top_row.setSpacing(20)

#         # TIMER
#         self.card_timer = FluentCard("Smart Mode Timer", AppColors.BREAK, has_spark=False)
#         self.card_timer.setMinimumHeight(260)
#         top_row.addWidget(self._wrap_blur(self.card_timer))

#         # BEHAVIOR
#         self.card_behavior = FluentCard("Behavior", AppColors.BEHAVIOR)
#         self.card_behavior.setMinimumHeight(260)
#         top_row.addWidget(self._wrap_blur(self.card_behavior))

#         # FATIGUE
#         self.card_fatigue = FluentCard("Fatigue", AppColors.FATIGUE)
#         self.card_fatigue.setMinimumHeight(260)
#         top_row.addWidget(self._wrap_blur(self.card_fatigue))

#         layout.addLayout(top_row)

#         # ============================================
#         # ROW 2 — Next Break + Reason + Suppression
#         # ============================================
#         row2 = QHBoxLayout()
#         row2.setSpacing(20)

#         self.card_next_break = FluentCard("Next Break", AppColors.BREAK)
#         self.card_next_break.setMinimumHeight(150)
#         self.card_next_break.setMaximumHeight(180)
#         row2.addWidget(self._wrap_blur(self.card_next_break), 1)

#         self.card_reason = FluentCard("Reason", AppColors.INSIGHT, has_spark=False)
#         self.card_reason.setMinimumHeight(300)
#         row2.addWidget(self._wrap_blur(self.card_reason), 2)

#         self.card_suppression = FluentCard("Suppression", AppColors.SUPPRESSION, has_spark=False)
#         self.card_suppression.setMinimumHeight(180)
#         row2.addWidget(self._wrap_blur(self.card_suppression), 1)

#         layout.addLayout(row2)

#         # SUMMARY
#         self.card_summary = FluentCard("Summary", AppColors.INSIGHT, has_spark=False)
#         self.card_summary.setMinimumHeight(300)
#         layout.addWidget(self._wrap_blur(self.card_summary))

#         layout.addStretch()

#         # BUTTON
#         self.btn_toggle = QPushButton("Start Smart Mode")
#         self.btn_toggle.setObjectName("PrimaryButton")
#         self.btn_toggle.setFixedHeight(44)
#         self.btn_toggle.clicked.connect(self.on_toggle_clicked)
#         layout.addWidget(self.btn_toggle, 0, Qt.AlignLeft)

#     def _wrap_blur(self, card: FluentCard) -> FluentBlur:
#         blur = FluentBlur(radius=25, opacity=0.30)
#         blur.layout.addWidget(card)
#         return blur

#     def on_toggle_clicked(self):
#         self.main.show_smart()
#         self.main.toggle_monitoring()
#         self.btn_toggle.setText("Stop Smart Mode" if self.main.monitoring else "Start Smart Mode")

#     def update_smart_status(self, behavior, fatigue, reason, trigger, next_break_seconds):
#         engine = self.main.hybrid_engine

#         # TIMER
#         elapsed = 0
#         if engine.session_start and self.main.monitoring and self.main.active_monitoring_mode == "Smart Mode":
#             elapsed = int(time.time() - engine.session_start)
#         self.card_timer.update_value(time.strftime("%H:%M:%S", time.gmtime(elapsed)))

#         # BEHAVIOR
#         self.card_behavior.update_value(behavior)
#         self.behavior_trend.append(len(self.behavior_trend) % 5)
#         self.behavior_trend = self.behavior_trend[-30:]
#         SparklineAnimator(self.card_behavior.spark, AppColors.BEHAVIOR).animate(self.behavior_trend)

#         # FATIGUE
#         ValueAnimator(
#             start_value=self._fatigue_value(),
#             end_value=int(fatigue),
#             duration=500,
#             callback=lambda v: self.card_fatigue.update_value(f"{int(v)}%"),
#         ).start()

#         self.fatigue_trend.append(int(fatigue))
#         self.fatigue_trend = self.fatigue_trend[-30:]
#         SparklineAnimator(self.card_fatigue.spark, AppColors.FATIGUE).animate(self.fatigue_trend)

#         # REASON
#         self.card_reason.update_value(reason)

#         # NEXT BREAK
#         nb = max(0, int(next_break_seconds))
#         self.card_next_break.update_value(f"{nb}s" if nb else "—")
#         self.interval_trend.append(nb)
#         self.interval_trend = self.interval_trend[-30:]
#         SparklineAnimator(self.card_next_break.spark, AppColors.BREAK).animate(self.interval_trend)

#         # SUPPRESSION
#         if "suppressed" in reason.lower():
#             self.card_suppression.update_value("Active")
#             PulseAnimator(self.card_suppression).start()
#         else:
#             self.card_suppression.update_value("None")

#         # SUMMARY
#         summary = (
#             f"Behavior: {behavior}\n"
#             f"Fatigue: {int(fatigue)}%\n"
#             f"Reason: {reason}\n"
#             f"Next Break: {nb}s\n"
#             f"Trigger: {'Yes' if trigger else 'No'}"
#         )
#         self.card_summary.update_value(summary)

#         # ANIMATIONS
#         for card in [
#             self.card_timer, self.card_behavior, self.card_fatigue,
#             self.card_reason, self.card_next_break, self.card_suppression,
#             self.card_summary
#         ]:
#             FadeInAnimator(card).start()
#             SlideInAnimator(card.accent).start()

#     def _fatigue_value(self):
#         text = self.card_fatigue.value_label.text().replace("%", "").strip()
#         return int(text) if text.isdigit() else 0








# I changed the summary card
# ui/pages/smart_mode.py

import time
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton
from PySide6.QtCore import Qt

from ui.pages.shared.fluent_card import FluentCard
from ui.widgets.fluent_blur import FluentBlur
from ui.core.theme import AppColors
from ui.animations import (
    FadeInAnimator, SlideInAnimator, SparklineAnimator,
    ValueAnimator, PulseAnimator
)


class SmartModePage(QWidget):
    def __init__(self, main):
        super().__init__()
        self.main = main
        self.setObjectName("SmartModePage")

        self.behavior_trend = []
        self.fatigue_trend = []
        self.interval_trend = []

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(0)

        # ============================================
        # TOP ROW — Timer + Behavior + Fatigue
        # ============================================
        top_row = QHBoxLayout()
        top_row.setSpacing(20)

        self.card_timer = FluentCard("Smart Mode Timer", AppColors.BREAK, has_spark=False)
        self.card_timer.setMinimumHeight(260)
        top_row.addWidget(self._wrap_blur(self.card_timer))

        self.card_behavior = FluentCard("Behavior", AppColors.BEHAVIOR)
        self.card_behavior.setMinimumHeight(260)
        top_row.addWidget(self._wrap_blur(self.card_behavior))

        self.card_fatigue = FluentCard("Fatigue", AppColors.FATIGUE)
        self.card_fatigue.setMinimumHeight(260)
        top_row.addWidget(self._wrap_blur(self.card_fatigue))

        layout.addLayout(top_row)

        # ============================================
        # ROW 2 — Next Break + Reason + Suppression
        # ============================================
        row2 = QHBoxLayout()
        row2.setSpacing(20)

        self.card_next_break = FluentCard("Next Break", AppColors.BREAK)
        self.card_next_break.setMinimumHeight(150)
        self.card_next_break.setMaximumHeight(180)
        row2.addWidget(self._wrap_blur(self.card_next_break), 1)

        self.card_reason = FluentCard("Reason", AppColors.INSIGHT, has_spark=False)
        self.card_reason.setMinimumHeight(300)
        row2.addWidget(self._wrap_blur(self.card_reason), 2)

        self.card_suppression = FluentCard("Suppression", AppColors.SUPPRESSION, has_spark=False)
        self.card_suppression.setMinimumHeight(180)
        row2.addWidget(self._wrap_blur(self.card_suppression), 1)

        layout.addLayout(row2)

        # ============================================
        # INSIGHT (Slim, professional summary)
        # ============================================
        self.card_insight = FluentCard("Insight", AppColors.INSIGHT, has_spark=False)
        self.card_insight.setMinimumHeight(140)
        layout.addWidget(self._wrap_blur(self.card_insight))

        layout.addStretch()

        # BUTTON
        self.btn_toggle = QPushButton("Start Smart Mode")
        self.btn_toggle.setObjectName("PrimaryButton")
        self.btn_toggle.setFixedHeight(44)
        self.btn_toggle.clicked.connect(self.on_toggle_clicked)
        layout.addWidget(self.btn_toggle, 0, Qt.AlignLeft)

    def _wrap_blur(self, card: FluentCard) -> FluentBlur:
        blur = FluentBlur(radius=25, opacity=0.30)
        blur.layout.addWidget(card)
        return blur

    def on_toggle_clicked(self):
        self.main.show_smart()
        self.main.toggle_monitoring()
        self.btn_toggle.setText("Stop Smart Mode" if self.main.monitoring else "Start Smart Mode")

    # ============================================
    # PROFESSIONAL INSIGHT GENERATOR
    # ============================================
    def _generate_insight(self, behavior, fatigue, reason, next_break_seconds):
        fatigue = int(fatigue)
        nb_min = max(1, next_break_seconds // 60)

        if "meeting" in behavior.lower():
            return "You appear to be in a meeting. Break reminders are paused."

        if "watch" in behavior.lower():
            return "You’re watching content. Monitoring will resume when activity changes."

        if "suppressed" in reason.lower():
            return "Current activity suggests a break isn’t appropriate. Monitoring continues."

        if fatigue >= 70:
            return "Fatigue is elevated. A short pause soon may help maintain clarity."

        if fatigue >= 40:
            return "Fatigue is rising gradually. A break will be helpful in the next period."

        if nb_min <= 3:
            return "You’ve been active for a while. A break is coming up shortly."

        return f"Focus is steady and fatigue remains low. Your next break is in about {nb_min} minutes."

    # ============================================
    # UPDATE UI
    # ============================================
    def update_smart_status(self, behavior, fatigue, reason, trigger, next_break_seconds):
        print(f"[PAGE] UI received next_break_seconds={next_break_seconds}")

        engine = self.main.hybrid_engine

        # TIMER
        elapsed = 0
        if engine.session_start and self.main.monitoring and self.main.active_monitoring_mode == "Smart Mode":
            elapsed = int(time.time() - engine.session_start)
        self.card_timer.update_value(time.strftime("%H:%M:%S", time.gmtime(elapsed)))

        # BEHAVIOR
        self.card_behavior.update_value(behavior)
        self.behavior_trend.append(len(self.behavior_trend) % 5)
        self.behavior_trend = self.behavior_trend[-30:]
        SparklineAnimator(self.card_behavior.spark, AppColors.BEHAVIOR).animate(self.behavior_trend)

        # FATIGUE
        # Convert fatigue to a clean string immediately
        if fatigue is None:
            self.card_fatigue.update_value("0%")
        else:
            self.card_fatigue.update_value(f"{int(fatigue)}%")


        self.fatigue_trend.append(int(fatigue))
        self.fatigue_trend = self.fatigue_trend[-30:]
        SparklineAnimator(self.card_fatigue.spark, AppColors.FATIGUE).animate(self.fatigue_trend)

        # REASON
        self.card_reason.update_value(reason)

        # NEXT BREAK
        nb = max(0, int(next_break_seconds))
        self.card_next_break.update_value(f"{nb}s" if nb else "—")
        self.interval_trend.append(nb)
        self.interval_trend = self.interval_trend[-30:]
        SparklineAnimator(self.card_next_break.spark, AppColors.BREAK).animate(self.interval_trend)

        # SUPPRESSION
        if "suppressed" in reason.lower():
            self.card_suppression.update_value("Active")
            PulseAnimator(self.card_suppression).start()
        else:
            self.card_suppression.update_value("None")

        # INSIGHT (Professional tone)
        insight = self._generate_insight(behavior, fatigue, reason, nb)
        self.card_insight.update_value(insight)

        # ANIMATIONS
        for card in [
            self.card_timer, self.card_behavior, self.card_fatigue,
            self.card_reason, self.card_next_break, self.card_suppression,
            self.card_insight
        ]:
            FadeInAnimator(card).start()
            SlideInAnimator(card.accent).start()

    def _fatigue_value(self):
        text = self.card_fatigue.value_label.text().replace("%", "").strip()
        return int(text) if text.isdigit() else 0
