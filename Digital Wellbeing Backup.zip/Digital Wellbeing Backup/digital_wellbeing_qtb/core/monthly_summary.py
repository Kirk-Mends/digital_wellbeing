import csv
from datetime import datetime, timedelta
from statistics import mean


class MonthlySummaryEngine:
    def __init__(self, csv_path="usage_log.csv"):
        self.csv_path = csv_path

    def load_month(self):
        today = datetime.now().date()
        month_start = today - timedelta(days=29)

        entries = []

        try:
            with open(self.csv_path, "r") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    date = datetime.fromisoformat(row["date"]).date()
                    if month_start <= date <= today:
                        entries.append({
                            "date": date,
                            "active": float(row["active_minutes"])
                        })
        except FileNotFoundError:
            return []

        return entries

    def summarize(self):
        data = self.load_month()
        if not data:
            return None

        # Aggregate by day
        daily = {}
        for e in data:
            daily.setdefault(e["date"], 0)
            daily[e["date"]] += e["active"]

        days = sorted(daily.keys())
        values = [daily[d] for d in days]

        avg = mean(values)
        total = sum(values)
        best_day = days[values.index(max(values))].strftime("%A")
        worst_day = days[values.index(min(values))].strftime("%A")

        # Weekly breakdown
        weeks = []
        for i in range(0, len(days), 7):
            week_vals = values[i:i+7]
            if week_vals:
                weeks.append(sum(week_vals))

        best_week = max(weeks)
        worst_week = min(weeks)

        trend = "up" if values[-1] > values[0] else "down"

        # Consistency score
        diffs = []
        for i in range(1, len(values)):
            diffs.append(abs(values[i] - values[i-1]))
        consistency = max(0, 100 - mean(diffs))

        return {
            "avg": avg,
            "total": total,
            "best_day": best_day,
            "worst_day": worst_day,
            "best_week": best_week,
            "worst_week": worst_week,
            "trend": trend,
            "consistency": consistency,
            "daily": daily
        }
