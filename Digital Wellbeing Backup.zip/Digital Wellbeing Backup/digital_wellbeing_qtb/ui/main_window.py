# from PySide6.QtWidgets import (
#     QMainWindow, QWidget, QHBoxLayout, QStackedWidget
# )
# from PySide6.QtCore import Qt, QTimer

# from ui.sidebar import Sidebar
# from ui.pages.dashboard_classic import ClassicDashboard
# from ui.pages.dashboard_smart import SmartDashboard
# from ui.pages.dashboard_ai import AIDashboard

# from core.settings import SettingsManager
# from core.smart_break_engine import SmartBreakEngine
# from core.smart_break_engine_v2 import SmartBreakEngineV2
# from core.signal_collector import SignalCollector
# from core.reminder import Reminder
# from core.ai_reminder_messages import AIMessageGenerator
# from core.smart_break_engine import SmartBreakEngine, SmartConfig


# import time


# class MainWindow(QMainWindow):
#     def __init__(self):
#         super().__init__()

#         self.setWindowTitle("Digital Wellbeing Assistant")
#         self.resize(1100, 700)

#         # Settings + engines
#         self.settings = SettingsManager()
#         self.signals = SignalCollector()
#         self.hybrid_engine = SmartBreakEngine(SmartConfig())
#         self.ai_engine = SmartBreakEngineV2()
#         self.reminder = Reminder()
#         self.ai_messages = AIMessageGenerator()

#         self.monitoring = False
#         self.poll_interval = 1.0

#         # Layout
#         container = QWidget()
#         layout = QHBoxLayout(container)
#         layout.setContentsMargins(0, 0, 0, 0)

#         # Sidebar
#         self.sidebar = Sidebar(self)
#         layout.addWidget(self.sidebar)

#         # Pages
#         self.pages = QStackedWidget()
#         layout.addWidget(self.pages, 1)

#         # Add pages
#         self.classic_page = ClassicDashboard(self)
#         self.smart_page = SmartDashboard(self)
#         self.ai_page = AIDashboard(self)

#         self.pages.addWidget(self.classic_page)
#         self.pages.addWidget(self.smart_page)
#         self.pages.addWidget(self.ai_page)

#         self.setCentralWidget(container)

#         # Timer for break engine
#         self.timer = QTimer()
#         self.timer.timeout.connect(self.update_break_engine)
#         self.timer.start(1000)

#         self.apply_theme()

#         # -------------------------
#     # MONITORING TOGGLE
#     # -------------------------
#     def toggle_monitoring(self):
#         self.monitoring = not self.monitoring
#         print("Monitoring:", "ON" if self.monitoring else "OFF")

#         if self.monitoring:
#             # optional: reset timers/engines
#             if hasattr(self.hybrid_engine, "reset_after_break"):
#                 self.hybrid_engine.reset_after_break()
#             if hasattr(self.ai_engine, "reset_after_break"):
#                 self.ai_engine.reset_after_break()

#             print("Monitoring: ON")
#         else:
#             print("Monitoring: OFF")

#     # -------------------------
#     # PAGE SWITCHING
#     # -------------------------
#     def show_classic(self):
#         self.pages.setCurrentWidget(self.classic_page)

#     def show_smart(self):
#         self.pages.setCurrentWidget(self.smart_page)

#     def show_ai(self):
#         self.pages.setCurrentWidget(self.ai_page)

#     # -------------------------
#     # THEME LOADING
#     # -------------------------
#     def apply_theme(self):
#         theme_name = self.settings.get("theme")
#         path = f"assets/themes/{theme_name}.qss"

#         try:
#             with open(path, "r") as f:
#                 self.setStyleSheet(f.read())
#         except:
#             pass

#     # -------------------------
#     # BREAK ENGINE LOOP
#     # -------------------------
#     def update_break_engine(self):
#         if not self.monitoring:
#             return

#         self.signals.update()
#         signals_dict = self.signals.to_dict()

#         mode = self.settings.get("break_mode")

#         if mode == "strict":
#             if not hasattr(self.hybrid_engine, "session_start"):
#                 self.hybrid_engine.session_start = time.time()

#             self.hybrid_engine.real_time = time.time() - self.hybrid_engine.session_start
#             interval_sec = int(self.settings.get("break_interval_minutes")) * 60
#             should_break = self.hybrid_engine.real_time >= interval_sec
#             decision = None

#         elif mode == "hybrid":
#             decision = None
#             should_break = self.hybrid_engine.update(signals_dict, self.poll_interval)

#             if getattr(self.signals, "input_detected", False):
#                 self.hybrid_engine.register_input()

#         elif mode == "ai":
#             if not hasattr(self.ai_engine, "session_start"):
#                 self.ai_engine.session_start = time.time()

#             self.ai_engine.real_time = time.time() - self.ai_engine.session_start
#             decision = self.ai_engine.should_trigger_break(signals_dict)
#             should_break = decision["trigger"]

#         else:
#             should_break = False
#             decision = None

#         if should_break:
#             if mode == "ai" and decision is not None:
#                 behavior = decision["behavior"]
#                 fatigue = decision["fatigue_score"]
#                 reason = decision["reason"]

#                 message = self.ai_messages.generate(behavior, fatigue, reason)
#                 self.reminder.send_break_message(custom_message=message)

#                 self.ai_engine.last_break_time = time.time()
#                 self.hybrid_engine.reset_after_break()
#                 self.ai_engine.session_start = time.time()
#                 self.ai_engine.real_time = 0

#             else:
#                 self.reminder.send_break_message()
#                 self.hybrid_engine.reset_after_break()
#                 self.hybrid_engine.session_start = time.time()
#                 self.hybrid_engine.real_time = 0












# from PySide6.QtWidgets import (
#     QMainWindow, QWidget, QHBoxLayout, QStackedWidget
# )
# from PySide6.QtCore import QTimer

# from ui.sidebar import Sidebar
# from ui.pages.dashboard import Dashboard
# from ui.pages.smart_mode import SmartModePage
# from ui.pages.ai_mode import AIModePage
# from ui.pages.settings import SettingsPage
# from ui.pages.weekly_analytics import WeeklyAnalyticsPage

# from core.settings import SettingsManager
# from core.smart_break_engine import SmartBreakEngine, SmartConfig
# from core.smart_break_engine_v2 import SmartBreakEngineV2
# from core.signal_collector import SignalCollector
# from core.reminder import Reminder
# from core.ai_reminder_messages import AIMessageGenerator

# from ui.pages.ai_insights import AIInsightsPage
# from ui.pages.weekly_report import WeeklyReportPage
# from ui.pages.monthly_report import MonthlyReportPage
# from ui.pages.analytics_suite import AnalyticsSuitePage

# import time


# class MainWindow(QMainWindow):
#     def __init__(self):
#         super().__init__()

#         # Window basics
#         self.setWindowTitle("Digital Wellbeing Assistant")
#         self.resize(960, 620)
#         self.setMinimumSize(820, 560)

#         # Settings + engines
#         self.settings = SettingsManager()
#         self.signals = SignalCollector()
#         self.hybrid_engine = SmartBreakEngine(SmartConfig())
#         self.ai_engine = SmartBreakEngineV2()
#         self.reminder = Reminder(main_window=self)
#         self.ai_messages = AIMessageGenerator()

#         self.monitoring = False
#         self.poll_interval = 1.0

#         # Root layout
#         container = QWidget()
#         layout = QHBoxLayout(container)
#         layout.setContentsMargins(0, 0, 0, 0)
#         layout.setSpacing(0)

#         # Sidebar
#         self.sidebar = Sidebar(self)
#         layout.addWidget(self.sidebar)

#         # Pages container (STACKED WIDGET)
#         self.pages = QStackedWidget()
#         layout.addWidget(self.pages, 1)

#         # Create pages
#         self.dashboard_page = Dashboard(self)
#         self.smart_page = SmartModePage(self)
#         self.ai_page = AIModePage(self)
#         self.settings_page = SettingsPage(self)
#         self.weekly_page = WeeklyAnalyticsPage()

#         # New analytics-related pages
#         self.analytics_page = AnalyticsSuitePage()
#         self.insights_page = AIInsightsPage()
#         self.weekly_report_page = WeeklyReportPage()
#         self.monthly_report_page = MonthlyReportPage()

#         # Add pages to stack
#         self.pages.addWidget(self.dashboard_page)
#         self.pages.addWidget(self.smart_page)
#         self.pages.addWidget(self.ai_page)
#         self.pages.addWidget(self.settings_page)
#         self.pages.addWidget(self.weekly_page)
#         self.pages.addWidget(self.analytics_page)
#         self.pages.addWidget(self.insights_page)
#         self.pages.addWidget(self.weekly_report_page)
#         self.pages.addWidget(self.monthly_report_page)

#         self.setCentralWidget(container)

#         # Timer for break engine
#         self.timer = QTimer()
#         self.timer.timeout.connect(self.update_break_engine)
#         self.timer.start(1000)

#         # Apply theme
#         self.apply_theme()

#         # Default page
#         self.show_dashboard()

#     # -------------------------
#     # PAGE SWITCHING
#     # -------------------------
#     def show_analytics(self):
#         self.analytics_page.refresh_all()
#         self.pages.setCurrentWidget(self.analytics_page)

#     def show_monthly_report(self):
#         self.monthly_report_page.refresh()
#         self.pages.setCurrentWidget(self.monthly_report_page)

#     def show_weekly_report(self):
#         self.weekly_report_page.refresh()
#         self.pages.setCurrentWidget(self.weekly_report_page)

#     def show_insights(self):
#         self.pages.setCurrentWidget(self.insights_page)

#     def show_dashboard(self):
#         self.pages.setCurrentWidget(self.dashboard_page)

#     def show_smart(self):
#         self.pages.setCurrentWidget(self.smart_page)

#     def show_ai(self):
#         self.pages.setCurrentWidget(self.ai_page)

#     def show_settings(self):
#         self.pages.setCurrentWidget(self.settings_page)

#     def show_weekly(self):
#         self.pages.setCurrentWidget(self.weekly_page)

#     # -------------------------
#     # MONITORING TOGGLE
#     # -------------------------
#     def toggle_monitoring(self):
#         self.monitoring = not self.monitoring
#         print("Monitoring:", "ON" if self.monitoring else "OFF")

#         if self.monitoring:
#             if hasattr(self.hybrid_engine, "reset_after_break"):
#                 self.hybrid_engine.reset_after_break()
#             if hasattr(self.ai_engine, "reset_after_break"):
#                 self.ai_engine.reset_after_break()

#     # -------------------------
#     # THEME LOADING
#     # -------------------------
#     def apply_theme(self):
#         theme_name = self.settings.get("theme")
#         path = f"assets/themes/{theme_name}.qss"

#         try:
#             with open(path, "r") as f:
#                 self.setStyleSheet(f.read())
#         except Exception as e:
#             print(f"Failed to load theme {path}: {e}")

#     # -------------------------
#     # BREAK ENGINE LOOP
#     # -------------------------
#     def update_break_engine(self):
#         if not self.monitoring:
#             return

#         self.signals.update()
#         signals_dict = self.signals.to_dict()

#         # MEETING MODE UI UPDATE
#         meeting_active = getattr(self.signals, "in_meeting", False)

#         if meeting_active:
#             self.dashboard_page.meeting_badge.show_badge()
#             self.smart_page.meeting_badge.show_badge()
#             self.ai_page.meeting_badge.show_badge()
#         else:
#             self.dashboard_page.meeting_badge.hide_badge()
#             self.smart_page.meeting_badge.hide_badge()
#             self.ai_page.meeting_badge.hide_badge()

#         self.sidebar.set_meeting_mode(meeting_active)

#         # BREAK ENGINE LOGIC
#         mode = self.settings.get("break_mode")

#         if mode == "strict":
#             if not hasattr(self.hybrid_engine, "session_start"):
#                 self.hybrid_engine.session_start = time.time()

#             self.hybrid_engine.real_time = time.time() - self.hybrid_engine.session_start
#             interval_sec = int(self.settings.get("break_interval_minutes")) * 60
#             should_break = self.hybrid_engine.real_time >= interval_sec
#             decision = None

#         elif mode == "hybrid":
#             decision = None
#             should_break = self.hybrid_engine.update(signals_dict, self.poll_interval)

#             if getattr(self.signals, "input_detected", False):
#                 self.hybrid_engine.register_input()

#         elif mode == "ai":
#             if not hasattr(self.ai_engine, "session_start"):
#                 self.ai_engine.session_start = time.time()

#             self.ai_engine.real_time = time.time() - self.ai_engine.session_start
#             decision = self.ai_engine.should_trigger_break(signals_dict)
#             should_break = decision["trigger"]

#         else:
#             should_break = False
#             decision = None

#         if should_break:
#             if mode == "ai" and decision is not None:
#                 behavior = decision["behavior"]
#                 fatigue = decision["fatigue_score"]
#                 reason = decision["reason"]

#                 message = self.ai_messages.generate(behavior, fatigue, reason)
#                 self.reminder.send_break_message(custom_message=message)

#                 self.ai_engine.last_break_time = time.time()
#                 self.hybrid_engine.reset_after_break()
#                 self.ai_engine.session_start = time.time()
#                 self.ai_engine.real_time = 0

#             else:
#                 self.reminder.send_break_message()
#                 self.hybrid_engine.reset_after_break()
#                 self.hybrid_engine.session_start = time.time()
#                 self.hybrid_engine.real_time = 0


















# from PySide6.QtWidgets import (
#     QMainWindow, QWidget, QHBoxLayout, QStackedWidget
# )
# from PySide6.QtCore import QTimer

# from ui.sidebar import Sidebar
# from ui.pages.dashboard import Dashboard
# from ui.pages.smart_mode import SmartModePage
# from ui.pages.ai_mode import AIModePage
# from ui.pages.settings import SettingsPage
# from ui.pages.weekly_analytics import WeeklyAnalyticsPage

# from core.settings import SettingsManager
# from core.smart_break_engine import SmartBreakEngine, SmartConfig
# from core.smart_break_engine_v2 import SmartBreakEngineV2
# from core.signal_collector import SignalCollector
# from core.reminder import Reminder
# from core.ai_reminder_messages import AIMessageGenerator

# from ui.pages.ai_insights import AIInsightsPage
# from ui.pages.weekly_report import WeeklyReportPage
# from ui.pages.monthly_report import MonthlyReportPage
# from ui.pages.analytics_suite import AnalyticsSuitePage

# import time


# class MainWindow(QMainWindow):
#     def __init__(self):
#         super().__init__()

#         # Window basics
#         self.setWindowTitle("Digital Wellbeing Assistant")
#         self.resize(960, 620)
#         self.setMinimumSize(820, 560)

#         # Settings + engines
#         self.settings = SettingsManager()
#         self.signals = SignalCollector()
#         self.hybrid_engine = SmartBreakEngine(SmartConfig())
#         self.ai_engine = SmartBreakEngineV2()
#         self.reminder = Reminder(main_window=self)
#         self.ai_messages = AIMessageGenerator()

#         self.monitoring = False
#         self.poll_interval = 1.0

#         # Root layout
#         container = QWidget()
#         layout = QHBoxLayout(container)
#         layout.setContentsMargins(0, 0, 0, 0)
#         layout.setSpacing(0)

#         # Sidebar
#         self.sidebar = Sidebar(self)
#         layout.addWidget(self.sidebar)

#         # Pages container
#         self.pages = QStackedWidget()
#         layout.addWidget(self.pages, 1)

#         # Create pages
#         self.dashboard_page = Dashboard(self)
#         self.smart_page = SmartModePage(self)
#         self.ai_page = AIModePage(self)
#         self.settings_page = SettingsPage(self)
#         self.weekly_page = WeeklyAnalyticsPage()

#         # Analytics pages
#         self.analytics_page = AnalyticsSuitePage()
#         self.insights_page = AIInsightsPage()
#         self.weekly_report_page = WeeklyReportPage()
#         self.monthly_report_page = MonthlyReportPage()

#         # Add pages
#         self.pages.addWidget(self.dashboard_page)
#         self.pages.addWidget(self.smart_page)
#         self.pages.addWidget(self.ai_page)
#         self.pages.addWidget(self.settings_page)
#         self.pages.addWidget(self.weekly_page)
#         self.pages.addWidget(self.analytics_page)
#         self.pages.addWidget(self.insights_page)
#         self.pages.addWidget(self.weekly_report_page)
#         self.pages.addWidget(self.monthly_report_page)

#         self.setCentralWidget(container)

#         # Timer for break engine
#         self.timer = QTimer()
#         self.timer.timeout.connect(self.update_break_engine)
#         self.timer.start(1000)

#         # Apply theme
#         self.apply_theme()

#         # Default page
#         self.show_dashboard()

#     # -------------------------
#     # PAGE SWITCHING
#     # -------------------------
#     def show_dashboard(self):
#         self.pages.setCurrentWidget(self.dashboard_page)

#     def show_smart(self):
#         self.pages.setCurrentWidget(self.smart_page)

#     def show_ai(self):
#         self.pages.setCurrentWidget(self.ai_page)

#     def show_settings(self):
#         self.pages.setCurrentWidget(self.settings_page)

#     def show_weekly(self):
#         self.pages.setCurrentWidget(self.weekly_page)

#     def show_analytics(self):
#         self.analytics_page.refresh_all()
#         self.pages.setCurrentWidget(self.analytics_page)

#     def show_monthly_report(self):
#         self.monthly_report_page.refresh()
#         self.pages.setCurrentWidget(self.monthly_report_page)

#     def show_weekly_report(self):
#         self.weekly_report_page.refresh()
#         self.pages.setCurrentWidget(self.weekly_report_page)

#     def show_insights(self):
#         self.pages.setCurrentWidget(self.insights_page)

#     # -------------------------
#     # MONITORING TOGGLE
#     # -------------------------
#     def toggle_monitoring(self):
#         self.monitoring = not self.monitoring
#         print("Monitoring:", "ON" if self.monitoring else "OFF")

#         if self.monitoring:
#             if hasattr(self.hybrid_engine, "reset_after_break"):
#                 self.hybrid_engine.reset_after_break()
#             if hasattr(self.ai_engine, "reset_after_break"):
#                 self.ai_engine.reset_after_break()

#     # -------------------------
#     # THEME LOADING
#     # -------------------------
#     def apply_theme(self):
#         theme_name = self.settings.get("theme")
#         path = f"assets/themes/{theme_name}.qss"

#         try:
#             with open(path, "r") as f:
#                 self.setStyleSheet(f.read())
#         except Exception as e:
#             print(f"Failed to load theme {path}: {e}")

#     # -------------------------
#     # BREAK ENGINE LOOP
#     # -------------------------
#     def update_break_engine(self):
#         if not self.monitoring:
#             return

#         # Update signals
#         self.signals.update()
#         signals = self.signals.to_dict()

#         # -------------------------
#         # STRICT MEETING DETECTION
#         # -------------------------
#         meeting_active = (
#             signals.get("window_category") == "meeting"
#             or signals.get("webcam_active") is True
#         )

#         # Update meeting badges on all pages
#         if meeting_active:
#             self.dashboard_page.meeting_badge.show_badge()
#             self.smart_page.meeting_badge.show_badge()
#             self.ai_page.meeting_badge.show_badge()
#         else:
#             self.dashboard_page.meeting_badge.hide_badge()
#             self.smart_page.meeting_badge.hide_badge()
#             self.ai_page.meeting_badge.hide_badge()

#         self.sidebar.set_meeting_mode(meeting_active)

#         # -------------------------
#         # BREAK ENGINE LOGIC
#         # -------------------------
#         mode = self.settings.get("break_mode")

#         # STRICT MODE
#         if mode == "strict":
#             if not hasattr(self.hybrid_engine, "session_start"):
#                 self.hybrid_engine.session_start = time.time()

#             self.hybrid_engine.real_time = time.time() - self.hybrid_engine.session_start
#             interval_sec = int(self.settings.get("break_interval_minutes")) * 60
#             should_break = self.hybrid_engine.real_time >= interval_sec
#             decision = None

#         # HYBRID MODE
#         elif mode == "hybrid":
#             decision = None
#             should_break = self.hybrid_engine.update(signals, self.poll_interval)

#             if signals.get("keypress_rate", 0) > 0 or signals.get("mouse_rate", 0) > 0:
#                 self.hybrid_engine.register_input()

#         # ⭐ AI MODE (FULLY CORRECTED)
#         elif mode == "ai":
#             if not hasattr(self.ai_engine, "session_start"):
#                 self.ai_engine.session_start = time.time()

#             self.ai_engine.real_time = time.time() - self.ai_engine.session_start

#             decision = self.ai_engine.should_trigger_break(signals)
#             should_break = decision["trigger"]

#             # Update AI Mode UI
#             self.ai_page.update_ai_status(
#                 behavior=decision["behavior"],
#                 fatigue=decision["fatigue_score"],
#                 reason=decision["reason"],
#                 trigger=decision["trigger"]
#             )

#         else:
#             should_break = False
#             decision = None

#         # -------------------------
#         # BREAK TRIGGER
#         # -------------------------
#         if should_break:
#             if mode == "ai" and decision is not None:
#                 behavior = decision["behavior"]
#                 fatigue = decision["fatigue_score"]
#                 reason = decision["reason"]

#                 message = self.ai_messages.generate(behavior, fatigue, reason)
#                 self.reminder.send_break_message(custom_message=message)

#                 self.ai_engine.last_break_time = time.time()
#                 self.hybrid_engine.reset_after_break()
#                 self.ai_engine.session_start = time.time()
#                 self.ai_engine.real_time = 0

#             else:
#                 self.reminder.send_break_message()
#                 self.hybrid_engine.reset_after_break()
#                 self.hybrid_engine.session_start = time.time()
#                 self.hybrid_engine.real_time = 0












# # main_window.py

# import time
# from PySide6.QtWidgets import (
#     QMainWindow, QWidget, QHBoxLayout, QStackedWidget
# )
# from PySide6.QtCore import QTimer

# from ui.sidebar import Sidebar
# from ui.pages.dashboard import Dashboard
# from ui.pages.smart_mode import SmartModePage
# from ui.pages.ai_mode import AIModePage
# from ui.pages.settings import SettingsPage
# from ui.pages.weekly_analytics import WeeklyAnalyticsPage
# from ui.pages.analytics_suite import AnalyticsSuitePage
# from ui.pages.ai_insights import AIInsightsPage
# from ui.pages.weekly_report import WeeklyReportPage
# from ui.pages.monthly_report import MonthlyReportPage

# from core.settings import SettingsManager
# from core.smart_break_engine import SmartBreakEngine, SmartConfig
# from core.smart_break_engine_v2 import SmartBreakEngineV2
# from core.signal_collector import SignalCollector
# from core.reminder import Reminder
# from core.ai_reminder_messages import AIMessageGenerator


# class MainWindow(QMainWindow):
#     def __init__(self):
#         super().__init__()

#         self.setWindowTitle("Digital Wellbeing Assistant")
#         self.resize(960, 620)
#         self.setMinimumSize(820, 560)

#         # Core systems
#         self.settings = SettingsManager()
#         self.signals = SignalCollector()
#         self.hybrid_engine = SmartBreakEngine(SmartConfig())
#         self.ai_engine = SmartBreakEngineV2()
#         self.reminder = Reminder(main_window=self)
#         self.ai_messages = AIMessageGenerator()

#         # Monitoring state
#         self.monitoring = False
#         self.poll_interval = 1.0

#         # Layout
#         container = QWidget()
#         layout = QHBoxLayout(container)
#         layout.setContentsMargins(0, 0, 0, 0)
#         layout.setSpacing(0)

#         # Sidebar
#         self.sidebar = Sidebar(self)
#         layout.addWidget(self.sidebar)

#         # Pages
#         self.pages = QStackedWidget()
#         layout.addWidget(self.pages, 1)

#         self.dashboard_page = Dashboard(self)
#         self.smart_page = SmartModePage(self)
#         self.ai_page = AIModePage(self)
#         self.settings_page = SettingsPage(self)
#         self.weekly_page = WeeklyAnalyticsPage()
#         self.analytics_page = AnalyticsSuitePage()
#         self.insights_page = AIInsightsPage()
#         self.weekly_report_page = WeeklyReportPage()
#         self.monthly_report_page = MonthlyReportPage()

#         # Add pages
#         self.pages.addWidget(self.dashboard_page)
#         self.pages.addWidget(self.smart_page)
#         self.pages.addWidget(self.ai_page)
#         self.pages.addWidget(self.settings_page)
#         self.pages.addWidget(self.weekly_page)
#         self.pages.addWidget(self.analytics_page)
#         self.pages.addWidget(self.insights_page)
#         self.pages.addWidget(self.weekly_report_page)
#         self.pages.addWidget(self.monthly_report_page)

#         self.setCentralWidget(container)

#         # Timer loop
#         self.timer = QTimer()
#         self.timer.timeout.connect(self.update_break_engine)
#         self.timer.start(1000)

#         self.apply_theme()
#         self.show_dashboard()



#     # -------------------------
#     # FATIGUE LEVEL HELPER
#     # -------------------------
#     def fatigue_level(self, score):
#         try:
#             score = float(score)
#         except Exception:
#             return "Low"

#         if score < 25:
#             return "Low"
#         elif score < 50:
#             return "Medium"
#         elif score < 75:
#             return "High"
#         else:
#             return "Critical"

#     # Dashboard
#         # Dashboard
#     def build_dashboard_data(self):
#         signals = self.signals.to_dict()

#         # Active mode
#         if self.pages.currentWidget() == self.smart_page:
#             mode = "Smart Mode"
#         elif self.pages.currentWidget() == self.ai_page:
#             mode = "AI Mode"
#         else:
#             mode = "Idle"

#         # Meeting mode
#         meeting_active = (
#             signals.get("window_category") == "meeting"
#             or signals.get("webcam_active") is True
#         )

#         # Screen time (real_time from Smart Mode)
#         screen_seconds = int(self.hybrid_engine.real_time)
#         screen_time = time.strftime("%H:%M:%S", time.gmtime(screen_seconds))

#         # Break count (from Reminder)
#         breaks_taken = self.reminder.break_count if hasattr(self.reminder, "break_count") else 0

#         # Behavior (from AI Mode) — clean label
#         raw_behavior = getattr(self.ai_engine, "last_behavior", "—")
#         if isinstance(raw_behavior, str):
#             behavior = raw_behavior.replace("_", " ").title()
#         else:
#             behavior = "—"

#         # Fatigue (from AI Mode)
#         fatigue_score = getattr(self.ai_engine, "last_fatigue", 0.0)
#         fatigue_level = self.fatigue_level(fatigue_score)

#         # Status (simple logic)
#         status = "Healthy"
#         if fatigue_level == "High":
#             status = "Tired"
#         if fatigue_level == "Critical":
#             status = "Exhausted"
#         if meeting_active:
#             status = "In Meeting"

#         # Simple prototype trend
#         trend_value = screen_seconds % 100

#         return {
#             "screen_time": screen_time,
#             "screen_seconds": screen_seconds,
#             "breaks": str(breaks_taken),
#             "mode": mode,
#             "behavior": behavior,
#             "fatigue_score": float(fatigue_score),
#             "fatigue_level": fatigue_level,
#             "meeting": "On" if meeting_active else "Off",
#             "status": status,
#             "trend_value": trend_value
#         }

#     # -------------------------
#     # PAGE SWITCHING
#     # -------------------------
#     def show_dashboard(self):
#         self.pages.setCurrentWidget(self.dashboard_page)

#     def show_smart(self):
#         self.pages.setCurrentWidget(self.smart_page)

#     def show_ai(self):
#         self.pages.setCurrentWidget(self.ai_page)

#     def show_settings(self):
#         self.pages.setCurrentWidget(self.settings_page)

#     def show_weekly(self):
#         self.pages.setCurrentWidget(self.weekly_page)

#     def show_analytics(self):
#         self.analytics_page.refresh_all()
#         self.pages.setCurrentWidget(self.analytics_page)

#     def show_insights(self):
#         self.pages.setCurrentWidget(self.insights_page)

#     def show_weekly_report(self):
#         self.weekly_report_page.refresh()
#         self.pages.setCurrentWidget(self.weekly_report_page)

#     def show_monthly_report(self):
#         self.monthly_report_page.refresh()
#         self.pages.setCurrentWidget(self.monthly_report_page)

#     # -------------------------
#     # MONITORING TOGGLE
#     # -------------------------
#     def toggle_monitoring(self):
#         self.monitoring = not self.monitoring
#         print("Monitoring:", "ON" if self.monitoring else "OFF")

#         if self.monitoring:
#             # Reset engines when monitoring starts
#             self.hybrid_engine.reset_after_break()
#             self.ai_engine.last_break_time = time.time()
#             self.ai_engine.session_start = time.time()
#             self.ai_engine.real_time = 0

#         if not self.monitoring:
#             self.ai_engine.session_start = None
#             self.hybrid_engine.real_time = 0
#             return

#     # -------------------------
#     # THEME
#     # -------------------------
#     def apply_theme(self):
#         theme_name = self.settings.get("theme")
#         path = f"assets/themes/{theme_name}.qss"

#         try:
#             with open(path, "r") as f:
#                 self.setStyleSheet(f.read())
#         except Exception as e:
#             print(f"Failed to load theme {path}: {e}")

#     # -------------------------
#     # BREAK ENGINE LOOP (NEW ARCHITECTURE)
#     # -------------------------
#     def update_break_engine(self):
#         if not self.monitoring:
#             return

#         # Update signals
#         self.signals.update()
#         signals = self.signals.to_dict()

#         # -------------------------
#         # GLOBAL MEETING DETECTION
#         # -------------------------
#         meeting_active = (
#             signals.get("window_category") == "meeting"
#             or signals.get("webcam_active") is True
#         )

#         # Update meeting badges
#         if meeting_active:
#             self.dashboard_page.meeting_badge.show_badge()
#             self.smart_page.meeting_badge.show_badge()
#             self.ai_page.meeting_badge.show_badge()
#         else:
#             self.dashboard_page.meeting_badge.hide_badge()
#             self.smart_page.meeting_badge.hide_badge()
#             self.ai_page.meeting_badge.hide_badge()

#         self.sidebar.set_meeting_mode(meeting_active)

#         if self.signals.is_user_away():
#             self.ai_engine.session_start = time.time()
#             self.hybrid_engine.real_time = 0
#             return  # do NOT trigger breaks while away

#         # -------------------------
#         # UPDATE DASHBOARD
#         # -------------------------
#         data = self.build_dashboard_data()
#         self.dashboard_page.update_dashboard(data)

#         # -------------------------
#         # SMART MODE ACTIVE?
#         # -------------------------
#         if self.pages.currentWidget() == self.smart_page:
#             should_break = self.hybrid_engine.update(signals, self.poll_interval)
#             decision = None

#                 # -------------------------
#         # AI MODE ACTIVE?
#         # -------------------------
#         elif self.pages.currentWidget() == self.ai_page:

#             # Initialize session start
#             if not hasattr(self.ai_engine, "session_start") or self.ai_engine.session_start is None:
#                 self.ai_engine.session_start = time.time()

#             # Update real time
#             self.ai_engine.real_time = time.time() - self.ai_engine.session_start

#             # AI decision
#             decision = self.ai_engine.should_trigger_break(signals)
#             should_break = decision["trigger"]

#             # Store for dashboard
#             self.ai_engine.last_behavior = decision["behavior"]
#             self.ai_engine.last_fatigue = decision["fatigue_score"]

#             # Update AI Mode UI
#             self.ai_page.update_ai_status(
#                 behavior=decision["behavior"],
#                 fatigue=decision["fatigue_score"],
#                 reason=decision["reason"],
#                 trigger=decision["trigger"]
#             )


#         else:
#             # No mode active → no break logic
#             should_break = False
#             decision = None

#         # -------------------------
#         # BREAK TRIGGER
#         # -------------------------
#         if should_break:

#             # AI MODE BREAK
#             if decision is not None:
#                 message = self.ai_messages.generate(
#                     decision["behavior"],
#                     decision["fatigue_score"],
#                     decision["reason"]
#                 )
#                 self.reminder.send_break_message(custom_message=message)

#                 # Reset AI engine
#                 self.ai_engine.last_break_time = time.time()
#                 self.ai_engine.session_start = time.time()
#                 self.ai_engine.real_time = 0

#             # SMART MODE BREAK
#             else:
#                 self.reminder.send_break_message()
#                 self.hybrid_engine.reset_after_break()







































# This is for a cleaned architecture

# main_window.py

# import time
# from PySide6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QStackedWidget
# from PySide6.QtCore import QTimer

# from ui.sidebar import Sidebar
# from ui.pages.dashboard import Dashboard
# from ui.pages.smart_mode import SmartModePage
# from ui.pages.ai_mode import AIModePage
# from ui.pages.settings import SettingsPage
# from ui.pages.weekly_analytics import WeeklyAnalyticsPage
# from ui.pages.analytics_suite import AnalyticsSuitePage
# from ui.pages.ai_insights import AIInsightsPage
# from ui.pages.weekly_report import WeeklyReportPage
# from ui.pages.monthly_report import MonthlyReportPage

# from core.settings import SettingsManager
# from core.smart_break_engine import SmartBreakEngine, SmartConfig
# from core.smart_break_engine_v2 import SmartBreakEngineV2
# from core.signal_collector import SignalCollector
# from core.reminder import Reminder
# from core.ai_reminder_messages import AIMessageGenerator


# class MainWindow(QMainWindow):
#     def __init__(self):
#         super().__init__()

#         self.setWindowTitle("Digital Wellbeing Assistant")
#         self.resize(960, 620)
#         self.setMinimumSize(820, 560)

#         # Core systems
#         self.settings = SettingsManager()
#         self.signals = SignalCollector()
#         self.hybrid_engine = SmartBreakEngine(SmartConfig())
#         self.ai_engine = SmartBreakEngineV2()
#         self.reminder = Reminder(main_window=self)
#         self.ai_messages = AIMessageGenerator()

#         # Monitoring state
#         self.monitoring = False
#         self.poll_interval = 1.0

#         # Layout
#         container = QWidget()
#         layout = QHBoxLayout(container)
#         layout.setContentsMargins(0, 0, 0, 0)
#         layout.setSpacing(0)

#         # Sidebar
#         self.sidebar = Sidebar(self)
#         layout.addWidget(self.sidebar)

#         # Pages
#         self.pages = QStackedWidget()
#         layout.addWidget(self.pages, 1)

#         self.dashboard_page = Dashboard(self)
#         self.smart_page = SmartModePage(self)
#         self.ai_page = AIModePage(self)
#         self.settings_page = SettingsPage(self)
#         self.weekly_page = WeeklyAnalyticsPage()
#         self.analytics_page = AnalyticsSuitePage()
#         self.insights_page = AIInsightsPage()
#         self.weekly_report_page = WeeklyReportPage()
#         self.monthly_report_page = MonthlyReportPage()

#         # Add pages
#         for page in [
#             self.dashboard_page, self.smart_page, self.ai_page, self.settings_page,
#             self.weekly_page, self.analytics_page, self.insights_page,
#             self.weekly_report_page, self.monthly_report_page
#         ]:
#             self.pages.addWidget(page)

#         self.setCentralWidget(container)

#         # Timer loop
#         self.timer = QTimer()
#         self.timer.timeout.connect(self.update_break_engine)
#         self.timer.start(1000)

#         self.apply_theme()
#         self.show_dashboard()

#     # -------------------------
#     # FATIGUE LEVEL HELPER
#     # -------------------------
#     def fatigue_level(self, score):
#         try:
#             score = float(score)
#         except Exception:
#             return "Low"

#         if score < 25:
#             return "Low"
#         elif score < 50:
#             return "Medium"
#         elif score < 75:
#             return "High"
#         else:
#             return "Critical"

#     # -------------------------
#     # DASHBOARD DATA
#     # -------------------------
#     def build_dashboard_data(self):
#         signals = self.signals.to_dict()

#         # Active mode
#         # Active mode
#         mode = self.active_monitoring_mode or "No Active Mode"

#         # Meeting mode
#         meeting_active = (
#             signals.get("window_category") == "meeting"
#             or signals.get("webcam_active") is True
#         )

#         # Screen time
#         screen_seconds = int(self.hybrid_engine.real_time)
#         screen_time = time.strftime("%H:%M:%S", time.gmtime(screen_seconds))

#         # Break count
#         breaks_taken = getattr(self.reminder, "break_count", 0)

#         # Behavior
#         raw_behavior = getattr(self.ai_engine, "last_behavior", "—")
#         if isinstance(raw_behavior, str):
#             behavior = raw_behavior.replace("_", " ").title()
#         else:
#             behavior = str(raw_behavior)

#         # Fatigue
#         fatigue_score = getattr(self.ai_engine, "last_fatigue", 0.0)
#         fatigue_level = self.fatigue_level(fatigue_score)

#         # Status
#         status = "Healthy"
#         if fatigue_level == "High":
#             status = "Tired"
#         elif fatigue_level == "Critical":
#             status = "Exhausted"
#         if meeting_active:
#             status = "In Meeting"

#         # Trend
#         trend_value = screen_seconds % 100

#         return {
#             "screen_time": screen_time,
#             "screen_seconds": screen_seconds,
#             "breaks": str(breaks_taken),
#             "mode": mode,
#             "behavior": behavior,
#             "fatigue_score": float(fatigue_score),
#             "fatigue_level": fatigue_level,
#             "meeting": "On" if meeting_active else "Off",
#             "status": status,
#             "trend_value": trend_value
#         }

#     # -------------------------
#     # PAGE SWITCHING
#     # -------------------------
#     def show_dashboard(self): self.pages.setCurrentWidget(self.dashboard_page)
#     def show_smart(self): self.pages.setCurrentWidget(self.smart_page)
#     def show_ai(self): self.pages.setCurrentWidget(self.ai_page)
#     def show_settings(self): self.pages.setCurrentWidget(self.settings_page)
#     def show_weekly(self): self.pages.setCurrentWidget(self.weekly_page)
#     def show_analytics(self):
#         self.analytics_page.refresh_all()
#         self.pages.setCurrentWidget(self.analytics_page)
#     def show_insights(self): self.pages.setCurrentWidget(self.insights_page)
#     def show_weekly_report(self):
#         self.weekly_report_page.refresh()
#         self.pages.setCurrentWidget(self.weekly_report_page)
#     def show_monthly_report(self):
#         self.monthly_report_page.refresh()
#         self.pages.setCurrentWidget(self.monthly_report_page)

#     # -------------------------
#     # MONITORING TOGGLE
#     # -------------------------
#     def toggle_monitoring(self):
#         self.monitoring = not self.monitoring
#         print("Monitoring:", "ON" if self.monitoring else "OFF")

#         if self.monitoring:
#             # Detect which page initiated monitoring
#             if self.pages.currentWidget() == self.smart_page:
#                 self.active_monitoring_mode = "Smart Mode"
#                 self.hybrid_engine.reset_after_break()
#             elif self.pages.currentWidget() == self.ai_page:
#                 self.active_monitoring_mode = "AI Mode"
#                 self.ai_engine.last_break_time = time.time()
#                 self.ai_engine.session_start = time.time()
#                 self.ai_engine.real_time = 0
#         else:
#             # Monitoring stopped → no active mode
#             self.active_monitoring_mode = None
#             self.hybrid_engine.real_time = 0
#             self.ai_engine.session_start = None
#     # -------------------------
#     # THEME
#     # -------------------------
#     def apply_theme(self):
#         theme_name = self.settings.get("theme")
#         path = f"assets/themes/{theme_name}.qss"

#         try:
#             with open(path, "r") as f:
#                 self.setStyleSheet(f.read())
#         except Exception as e:
#             print(f"Failed to load theme {path}: {e}")

#     # -------------------------
#     # BREAK ENGINE LOOP
#     # -------------------------
#     def update_break_engine(self):
#         if not self.monitoring:
#             return

#         # Update signals
#         self.signals.update()
#         signals = self.signals.to_dict()

#         # -------------------------
#         # GLOBAL MEETING DETECTION
#         # -------------------------
#         meeting_active = (
#             signals.get("window_category") == "meeting"
#             or signals.get("webcam_active") is True
#         )
#         for page in [self.dashboard_page, self.smart_page, self.ai_page]:
#             if meeting_active:
#                 page.meeting_badge.show_badge()
#             else:
#                 page.meeting_badge.hide_badge()
#         self.sidebar.set_meeting_mode(meeting_active)

#         if self.signals.is_user_away():
#             self.ai_engine.session_start = time.time()
#             self.hybrid_engine.real_time = 0
#             return  # do NOT trigger breaks while away

#         # -------------------------
#         # UPDATE DASHBOARD
#         # -------------------------
#         data = self.build_dashboard_data()
#         self.dashboard_page.update_dashboard(data)

#         # -------------------------
#         # SMART MODE ACTIVE
#         # -------------------------
#         if self.pages.currentWidget() == self.smart_page:
#             should_break = self.hybrid_engine.update(signals, self.poll_interval)
#             decision = None

#         # -------------------------
#         # AI MODE ACTIVE
#         # -------------------------
#         elif self.pages.currentWidget() == self.ai_page:

#             # Initialize session start
#             if not hasattr(self.ai_engine, "session_start") or self.ai_engine.session_start is None:
#                 self.ai_engine.session_start = time.time()

#             # Update real time
#             self.ai_engine.real_time = time.time() - self.ai_engine.session_start

#             # AI decision
#             decision = self.ai_engine.should_trigger_break(signals)
#             should_break = decision["trigger"]

#             # Store for dashboard & UI safely
#             behavior_result = decision.get("behavior", "Idle")
#             if not isinstance(behavior_result, str):
#                 behavior_result = str(behavior_result)

#             self.ai_engine.last_behavior = behavior_result
#             self.ai_engine.last_fatigue = decision.get("fatigue_score", 0.0)

#             # Update AI Mode UI
#             self.ai_page.update_ai_status(
#                 behavior=self.ai_engine.last_behavior,
#                 fatigue=self.ai_engine.last_fatigue,
#                 reason=decision.get("reason", ""),
#                 trigger=decision.get("trigger", False)
#             )

#         else:
#             # No mode active
#             should_break = False
#             decision = None

#         # -------------------------
#         # BREAK TRIGGER
#         # -------------------------
#         if should_break:

#             if decision is not None:
#                 # AI MODE BREAK
#                 message = self.ai_messages.generate(
#                     decision.get("behavior", "Idle"),
#                     decision.get("fatigue_score", 0.0),
#                     decision.get("reason", "")
#                 )
#                 self.reminder.send_break_message(custom_message=message)

#                 # Reset AI engine
#                 self.ai_engine.last_break_time = time.time()
#                 self.ai_engine.session_start = time.time()
#                 self.ai_engine.real_time = 0

#             else:
#                 # SMART MODE BREAK
#                 self.reminder.send_break_message()
#                 self.hybrid_engine.reset_after_break()













# # 2.2
# # main_window.py

# import time
# from PySide6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QStackedWidget
# from PySide6.QtCore import QTimer

# from ui.sidebar import Sidebar
# from ui.pages.dashboard import Dashboard
# from ui.pages.smart_mode import SmartModePage
# from ui.pages.ai_mode import AIModePage
# from ui.pages.settings import SettingsPage
# from ui.pages.weekly_analytics import WeeklyAnalyticsPage
# from ui.pages.analytics_suite import AnalyticsSuitePage
# from ui.pages.ai_insights import AIInsightsPage
# from ui.pages.weekly_report import WeeklyReportPage
# from ui.pages.monthly_report import MonthlyReportPage

# from core.settings import SettingsManager
# from core.smart_break_engine import SmartBreakEngine, SmartConfig
# from core.smart_break_engine_v2 import SmartBreakEngineV2
# from core.signal_collector import SignalCollector
# from core.reminder import Reminder
# from core.ai_reminder_messages import AIMessageGenerator


# class MainWindow(QMainWindow):
#     def __init__(self):
#         super().__init__()

#         self.setWindowTitle("Digital Wellbeing Assistant")
#         self.resize(960, 620)
#         self.setMinimumSize(820, 560)

#         # =============================
#         # CORE SYSTEMS (UNCHANGED)
#         # =============================
#         self.settings = SettingsManager()
#         self.signals = SignalCollector()
#         self.hybrid_engine = SmartBreakEngine(SmartConfig())
#         self.ai_engine = SmartBreakEngineV2()
#         self.reminder = Reminder(main_window=self)
#         self.ai_messages = AIMessageGenerator()

#         # =============================
#         # GLOBAL TRACKING (NEVER RESETS)
#         # =============================
#         self.app_start_time = time.time()
#         self.global_screen_seconds = 0

#         # =============================
#         # MONITORING STATE
#         # =============================
#         self.monitoring = False
#         self.active_monitoring_mode = None  # "Smart Mode" | "AI Mode"
#         self.poll_interval = 1.0

#         # =============================
#         # LAYOUT (UNCHANGED)
#         # =============================
#         container = QWidget()
#         layout = QHBoxLayout(container)
#         layout.setContentsMargins(0, 0, 0, 0)
#         layout.setSpacing(0)

#         self.sidebar = Sidebar(self)
#         layout.addWidget(self.sidebar)

#         self.pages = QStackedWidget()
#         layout.addWidget(self.pages, 1)

#         self.dashboard_page = Dashboard(self)
#         self.smart_page = SmartModePage(self)
#         self.ai_page = AIModePage(self)
#         self.settings_page = SettingsPage(self)
#         self.weekly_page = WeeklyAnalyticsPage()
#         self.analytics_page = AnalyticsSuitePage()
#         self.insights_page = AIInsightsPage()
#         self.weekly_report_page = WeeklyReportPage()
#         self.monthly_report_page = MonthlyReportPage()

#         for page in [
#             self.dashboard_page, self.smart_page, self.ai_page, self.settings_page,
#             self.weekly_page, self.analytics_page, self.insights_page,
#             self.weekly_report_page, self.monthly_report_page
#         ]:
#             self.pages.addWidget(page)

#         self.setCentralWidget(container)

#         # =============================
#         # MAIN LOOP TIMER
#         # =============================
#         self.timer = QTimer()
#         self.timer.timeout.connect(self.update_break_engine)
#         self.timer.start(1000)

#         self.apply_theme()
#         self.show_dashboard()

#     # =============================
#     # FATIGUE LEVEL
#     # =============================
#     def fatigue_level(self, score):
#         try:
#             score = float(score)
#         except Exception:
#             return "Low"

#         if score < 25:
#             return "Low"
#         elif score < 50:
#             return "Medium"
#         elif score < 75:
#             return "High"
#         else:
#             return "Critical"

#     # =============================
#     # DASHBOARD DATA (FIXED)
#     # =============================
#     def build_dashboard_data(self):

#         signals = self.signals.to_dict()

#         mode = self.active_monitoring_mode or "No Active Mode"

#         meeting_active = (
#             signals.get("window_category") == "meeting"
#             or signals.get("webcam_active") is True
#         )

#         # 🔥 GLOBAL screen time (NOT engine time)
#         screen_seconds = self.global_screen_seconds
#         screen_time = time.strftime("%H:%M:%S", time.gmtime(screen_seconds))

#         breaks_taken = getattr(self.reminder, "break_count", 0)

#         raw_behavior = getattr(self.ai_engine, "last_behavior", "—")
#         behavior = str(raw_behavior).replace("_", " ").title()

#         fatigue_score = getattr(self.ai_engine, "last_fatigue", 0.0)
#         fatigue_level = self.fatigue_level(fatigue_score)

#         status = "Monitoring" if self.monitoring else "Not Monitoring"

#         trend_value = screen_seconds  # smooth increasing trend

#         return {
#             "screen_time": screen_time,
#             "screen_seconds": screen_seconds,
#             "breaks": str(breaks_taken),
#             "mode": mode,
#             "behavior": behavior,
#             "fatigue_score": float(fatigue_score),
#             "fatigue_level": fatigue_level,
#             "meeting": "On" if meeting_active else "Off",
#             "status": status,
#             "trend_value": trend_value
#         }

#     # =============================
#     # PAGE SWITCHING (UNCHANGED)
#     # =============================
#     def show_dashboard(self): self.pages.setCurrentWidget(self.dashboard_page)
#     def show_smart(self): self.pages.setCurrentWidget(self.smart_page)
#     def show_ai(self): self.pages.setCurrentWidget(self.ai_page)
#     def show_settings(self): self.pages.setCurrentWidget(self.settings_page)
#     def show_weekly(self): self.pages.setCurrentWidget(self.weekly_page)

#     def show_analytics(self):
#         self.analytics_page.refresh_all()
#         self.pages.setCurrentWidget(self.analytics_page)

#     def show_insights(self): self.pages.setCurrentWidget(self.insights_page)

#     def show_weekly_report(self):
#         self.weekly_report_page.refresh()
#         self.pages.setCurrentWidget(self.weekly_report_page)

#     def show_monthly_report(self):
#         self.monthly_report_page.refresh()
#         self.pages.setCurrentWidget(self.monthly_report_page)

#     # =============================
#     # MONITORING TOGGLE (FIXED)
#     # =============================
#     def toggle_monitoring(self):

#         self.monitoring = not self.monitoring

#         if self.monitoring:
#             if self.pages.currentWidget() == self.smart_page:
#                 self.active_monitoring_mode = "Smart Mode"
#                 self.hybrid_engine.reset_after_break()

#             elif self.pages.currentWidget() == self.ai_page:
#                 self.active_monitoring_mode = "AI Mode"
#                 self.ai_engine.session_start = time.time()
#                 self.ai_engine.real_time = 0
#         else:
#             self.active_monitoring_mode = None

#         print("Monitoring:", "ON" if self.monitoring else "OFF")

#     # =============================
#     # THEME
#     # =============================
#     def apply_theme(self):
#         theme_name = self.settings.get("theme")
#         path = f"assets/themes/{theme_name}.qss"

#         try:
#             with open(path, "r") as f:
#                 self.setStyleSheet(f.read())
#         except Exception as e:
#             print(f"Failed to load theme {path}: {e}")

#     # =============================
#     # BREAK ENGINE LOOP (FIXED)
#     # =============================
#     def update_break_engine(self):

#         # 🔥 GLOBAL TIME ALWAYS RUNS
#         if self.monitoring:
#             self.global_screen_seconds = int(time.time() - self.app_start_time)

#         # Always update dashboard
#         data = self.build_dashboard_data()
#         self.dashboard_page.update_dashboard(data)

#         if not self.monitoring or not self.active_monitoring_mode:
#             return

#         self.signals.update()
#         signals = self.signals.to_dict()

#         if self.signals.is_user_away():
#             return

#         should_break = False
#         decision = None

#         # 🔥 USE ACTIVE MODE (NOT CURRENT PAGE)
#         if self.active_monitoring_mode == "Smart Mode":
#             should_break = self.hybrid_engine.update(signals, self.poll_interval)

#         elif self.active_monitoring_mode == "AI Mode":

#             if self.ai_engine.session_start is None:
#                 self.ai_engine.session_start = time.time()

#             self.ai_engine.real_time = time.time() - self.ai_engine.session_start

#             decision = self.ai_engine.should_trigger_break(signals)
#             should_break = decision.get("trigger", False)

#             self.ai_engine.last_behavior = decision.get("behavior", "Idle")
#             self.ai_engine.last_fatigue = decision.get("fatigue_score", 0.0)

#             self.ai_page.update_ai_status(
#                 behavior=self.ai_engine.last_behavior,
#                 fatigue=self.ai_engine.last_fatigue,
#                 reason=decision.get("reason", ""),
#                 trigger=decision.get("trigger", False)
#             )

#         # 🔥 BREAK TRIGGER
#         if should_break:

#             if decision:
#                 message = self.ai_messages.generate(
#                     decision.get("behavior", "Idle"),
#                     decision.get("fatigue_score", 0.0),
#                     decision.get("reason", "")
#                 )
#                 self.reminder.send_break_message(custom_message=message)
#                 self.ai_engine.session_start = time.time()

#             else:
#                 self.reminder.send_break_message()
#                 self.hybrid_engine.reset_after_break()















# 5
# upgraded
# ui/main_window.py

import time
from PySide6.QtWidgets import QMainWindow, QWidget, QHBoxLayout, QStackedWidget
from PySide6.QtCore import QTimer

from ui.sidebar import Sidebar
from ui.pages.dashboard import Dashboard
from ui.pages.smart_mode_page import SmartModePage
from ui.pages.ai_mode_page import AIModePage
from ui.pages.settings import SettingsPage
from ui.pages.weekly_analytics import WeeklyAnalyticsPage
from ui.pages.analytics_suite import AnalyticsSuitePage
from ui.pages.ai_insights import AIInsightsPage
from ui.pages.weekly_report import WeeklyReportPage
from ui.pages.monthly_report import MonthlyReportPage

from core.settings import SettingsManager
from core.smart_break_engine import SmartBreakEngine, SmartConfig
from core.smart_break_engine_v2 import SmartBreakEngineV2
from core.signal_collector import SignalCollector
from core.reminder import Reminder
from core.ai_reminder_messages import AIMessageGenerator
from ui.core.theme import make_dark_theme

from ui.core.card_registry import CardRegistry


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.theme = make_dark_theme()
        self.setWindowTitle("Digital Wellbeing Assistant")
        self.resize(960, 620)
        self.setMinimumSize(820, 560)

        # =============================
        # CORE SYSTEMS
        # =============================
        self.settings = SettingsManager()
        self.signals = SignalCollector()

        # Smart Mode engine (hybrid)
        self.hybrid_engine = SmartBreakEngine(SmartConfig())

        # AI Mode engine (V2)
        self.ai_engine = SmartBreakEngineV2()

        self.reminder = Reminder(main_window=self)
        self.ai_messages = AIMessageGenerator()

        # =============================
        # GLOBAL TRACKING
        # =============================
        self.app_start_time = time.time()
        self.global_screen_seconds = 0

        # =============================
        # MONITORING STATE
        # =============================
        self.monitoring = False
        self.active_monitoring_mode = None  # "Smart Mode" | "AI Mode"
        self.poll_interval = 1.0

        # =============================
        # LAYOUT
        # =============================
        container = QWidget()
        layout = QHBoxLayout(container)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        self.sidebar = Sidebar(self)
        layout.addWidget(self.sidebar)

        self.pages = QStackedWidget()
        layout.addWidget(self.pages, 1)

        # Pages
        self.dashboard_page = Dashboard(self)
        self.smart_page = SmartModePage(self.theme)
        self.smart_page.bottomBar.startStopButton.clicked.connect(self.toggle_monitoring)

        self.ai_page = AIModePage(self.theme)
        self.ai_page.bottomBar.startStopButton.clicked.connect(self.toggle_monitoring)

        self.settings_page = SettingsPage(self)
        self.weekly_page = WeeklyAnalyticsPage()
        self.analytics_page = AnalyticsSuitePage()
        self.insights_page = AIInsightsPage()
        self.weekly_report_page = WeeklyReportPage()
        self.monthly_report_page = MonthlyReportPage()

        for page in [
            self.dashboard_page, self.smart_page, self.ai_page, self.settings_page,
            self.weekly_page, self.analytics_page, self.insights_page,
            self.weekly_report_page, self.monthly_report_page
        ]:
            self.pages.addWidget(page)

        self.setCentralWidget(container)

        # =============================
        # MAIN LOOP TIMER
        # =============================
        self.timer = QTimer()
        self.timer.timeout.connect(self.update_break_engine)
        self.timer.start(1000)

        self.apply_theme()
        self.show_dashboard()

    # =============================
    # FATIGUE LEVEL
    # =============================
    def fatigue_level(self, score):
        try:
            score = float(score)
        except Exception:
            return "Low"

        if score < 25:
            return "Low"
        elif score < 50:
            return "Medium"
        elif score < 75:
            return "High"
        else:
            return "Critical"

    # =============================
    # DASHBOARD DATA
    # =============================
    def build_dashboard_data(self):

        signals = self.signals.to_dict()

        mode = self.active_monitoring_mode or "No Active Mode"

        meeting_active = (
            signals.get("window_category") == "meeting"
            or signals.get("webcam_active") is True
        )

        screen_seconds = self.global_screen_seconds
        screen_time = time.strftime("%H:%M:%S", time.gmtime(screen_seconds))

        breaks_taken = getattr(self.reminder, "break_count", 0)

        raw_behavior = getattr(self.ai_engine, "last_behavior", "—")
        behavior = str(raw_behavior).replace("_", " ").title()

        fatigue_score = getattr(self.ai_engine, "last_fatigue", 0.0)
        fatigue_level = self.fatigue_level(fatigue_score)

        status = "Monitoring" if self.monitoring else "Not Monitoring"

        trend_value = screen_seconds

        return {
            "screen_time": screen_time,
            "screen_seconds": screen_seconds,
            "breaks": str(breaks_taken),
            "mode": mode,
            "behavior": behavior,
            "fatigue_score": float(fatigue_score),
            "fatigue_level": fatigue_level,
            "meeting": "On" if meeting_active else "Off",
            "status": status,
            "trend_value": trend_value
        }

    # =============================
    # PAGE SWITCHING
    # =============================
    def show_dashboard(self): self.pages.setCurrentWidget(self.dashboard_page)
    def show_smart(self): self.pages.setCurrentWidget(self.smart_page)
    def show_ai(self): self.pages.setCurrentWidget(self.ai_page)
    def show_settings(self): self.pages.setCurrentWidget(self.settings_page)
    def show_weekly(self): self.pages.setCurrentWidget(self.weekly_page)

    def show_analytics(self):
        self.analytics_page.refresh_all()
        self.pages.setCurrentWidget(self.analytics_page)

    def show_insights(self): self.pages.setCurrentWidget(self.insights_page)

    def show_weekly_report(self):
        self.weekly_report_page.refresh()
        self.pages.setCurrentWidget(self.weekly_report_page)

    def show_monthly_report(self):
        self.monthly_report_page.refresh()
        self.pages.setCurrentWidget(self.monthly_report_page)

    # =============================
    # MONITORING TOGGLE
    # =============================
    def toggle_monitoring(self):

        self.monitoring = not self.monitoring

        if self.monitoring:
            if self.pages.currentWidget() == self.smart_page:
                self.active_monitoring_mode = "Smart Mode"
                self.hybrid_engine.reset_after_break()
                self.smart_page.monitoring = True
                self.smart_page.session_start = time.time()

            elif self.pages.currentWidget() == self.ai_page:
                self.active_monitoring_mode = "AI Mode"
                self.ai_page.monitoring = True
                self.ai_page.session_start = time.time()
                self.ai_engine.session_start = time.time()
                self.ai_engine.real_time = 0
        else:
            self.active_monitoring_mode = None
            self.smart_page.monitoring = False
            self.ai_page.monitoring = False

        print("Monitoring:", "ON" if self.monitoring else "OFF")

    # =============================
    # THEME
    # =============================
    def apply_theme(self):
        theme_name = self.settings.get("theme")
        path = f"assets/themes/{theme_name}.qss"

        try:
            with open(path, "r") as f:
                self.setStyleSheet(f.read())
        except Exception as e:
            print(f"Failed to load theme {path}: {e}")

    # =============================
    # BREAK ENGINE LOOP
    # =============================
    def update_break_engine(self):

        # GLOBAL TIME ALWAYS RUNS
        if self.monitoring:
            self.global_screen_seconds = int(time.time() - self.app_start_time)

        # Always update dashboard
        data = self.build_dashboard_data()
        self.dashboard_page.update_dashboard(data)

        if not self.monitoring or not self.active_monitoring_mode:
            return

        self.signals.update()
        signals = self.signals.to_dict()

        if self.signals.is_user_away():
            return

        should_break = False
        decision = None

        # SMART MODE
        if self.active_monitoring_mode == "Smart Mode":
            decision = self.hybrid_engine.update(signals, self.poll_interval)
            # If your SmartBreakEngine.update returns only bool, adapt this:
            if isinstance(decision, dict):
                should_break = decision.get("trigger", False)

                interval = decision.get("interval_used", self.hybrid_engine.base_interval)
                now = time.time()
                next_break_seconds = max(
                    0, int(interval - (now - self.hybrid_engine.session_start))
                )

                CardRegistry.update_all(
                    behavior=decision.get("behavior", "Idle"),
                    fatigue=decision.get("fatigue_score", 0.0),
                    reason=decision.get("reason", ""),
                    trigger=should_break,
                    next_break_seconds=next_break_seconds,
                    session_start=self.smart_page.session_start,
                    monitoring=self.smart_page.monitoring,
                )
            else:
                # Legacy: decision is just a bool
                should_break = bool(decision)

        # AI MODE
        elif self.active_monitoring_mode == "AI Mode":
            if self.ai_engine.session_start is None:
                self.ai_engine.session_start = time.time()

            self.ai_engine.real_time = time.time() - self.ai_engine.session_start

            decision = self.ai_engine.should_trigger_break(signals)
            should_break = decision.get("trigger", False)

            self.ai_engine.last_behavior = decision.get("behavior", "Idle")
            self.ai_engine.last_fatigue = decision.get("fatigue_score", 0.0)

            next_break_seconds = int(decision.get("interval_used", 0))

            CardRegistry.update_all(
                behavior=self.ai_engine.last_behavior,
                fatigue=self.ai_engine.last_fatigue,
                reason=decision.get("reason", ""),
                trigger=decision.get("trigger", False),
                next_break_seconds=next_break_seconds,
                session_start=self.ai_engine.session_start,
                monitoring=self.ai_page.monitoring,
            )

        # BREAK TRIGGER
        if should_break:

            if decision and isinstance(decision, dict):
                message = self.ai_messages.generate(
                    decision.get("behavior", "Idle"),
                    decision.get("fatigue_score", 0.0),
                    decision.get("reason", "")
                )
                self.reminder.send_break_message(custom_message=message)

                if self.active_monitoring_mode == "AI Mode":
                    self.ai_engine.session_start = time.time()
                elif self.active_monitoring_mode == "Smart Mode":
                    self.hybrid_engine.reset_after_break()
            else:
                self.reminder.send_break_message()
                self.hybrid_engine.reset_after_break()
