from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QFrame
from PySide6.QtCore import Qt

from core.monthly_summary import MonthlySummaryEngine
from core.monthly_report_generator import MonthlyReportGenerator


class MonthlyReportPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("MonthlyReportPage")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)

        title = QLabel("Monthly Summary Report")
        title.setObjectName("PageTitle")
        layout.addWidget(title)

        # Card container
        self.card = QFrame()
        self.card.setObjectName("ReportCard")

        card_layout = QVBoxLayout(self.card)
        card_layout.setContentsMargins(16, 16, 16, 16)

        self.text_label = QLabel()
        self.text_label.setObjectName("ReportText")
        self.text_label.setWordWrap(True)

        card_layout.addWidget(self.text_label)
        layout.addWidget(self.card)

        # Generate report
        self.refresh()

    def refresh(self):
        engine = MonthlySummaryEngine()
        summary = engine.summarize()

        generator = MonthlyReportGenerator()
        report = generator.generate(summary)

        self.text_label.setText(report)
