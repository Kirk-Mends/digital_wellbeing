from PIL import Image

img = Image.open("icon.png")
img = img.resize((128, 128))
img.save("icon.png", optimize=True)
print("Icon resized to 128x128 successfully.")
