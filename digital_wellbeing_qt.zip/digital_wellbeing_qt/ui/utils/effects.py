from PySide6.QtWidgets import QGraphicsDropShadowEffect
from PySide6.QtGui import QColor

def apply_button_shadow(btn):
    shadow = QGraphicsDropShadowEffect(btn)
    shadow.setBlurRadius(24)
    shadow.setOffset(0, 4)
    shadow.setColor(QColor(0, 0, 0, 60))
    btn.setGraphicsEffect(shadow)
