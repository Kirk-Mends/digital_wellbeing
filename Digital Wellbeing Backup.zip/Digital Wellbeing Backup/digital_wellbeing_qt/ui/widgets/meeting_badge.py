from PySide6.QtWidgets import QLabel
from PySide6.QtCore import Qt, QPropertyAnimation, QByteArray
from PySide6.QtGui import QColor

class MeetingBadge(QLabel):
    def __init__(self):
        super().__init__("🟣 In a meeting")
        self.setObjectName("MeetingBadge")
        self.setVisible(False)

        # Fade animation
        self.anim = QPropertyAnimation(self, b"windowOpacity")
        self.anim.setDuration(250)

    def show_badge(self):
        self.setVisible(True)
        self.anim.stop()
        self.anim.setStartValue(0.0)
        self.anim.setEndValue(1.0)
        self.anim.start()

    def hide_badge(self):
        self.anim.stop()
        self.anim.setStartValue(1.0)
        self.anim.setEndValue(0.0)
        self.anim.start()
        self.anim.finished.connect(lambda: self.setVisible(False))
