class MonthlyReportGenerator:
    def generate(self, summary):
        if summary is None:
            return "No activity data available for this month."

        avg = summary["avg"]
        total = summary["total"]
        best_day = summary["best_day"]
        worst_day = summary["worst_day"]
        best_week = summary["best_week"]
        worst_week = summary["worst_week"]
        trend = summary["trend"]
        consistency = summary["consistency"]

        trend_text = (
            "Your activity increased toward the end of the month."
            if trend == "up"
            else "Your activity tapered off slightly toward the end of the month."
        )

        return (
            f"Here’s your monthly wellbeing summary:\n\n"
            f"• You were active for a total of **{total:.0f} minutes** this month.\n"
            f"• Your average daily active time was **{avg:.1f} minutes**.\n"
            f"• Your most productive day was **{best_day}**, while **{worst_day}** was your lightest day.\n"
            f"• Your best week totaled **{best_week:.0f} minutes**, compared to **{worst_week:.0f} minutes** in your lightest week.\n"
            f"• Your consistency score for the month is **{consistency:.0f}/100**.\n"
            f"• {trend_text}\n\n"
            f"Keep up the momentum — steady habits lead to long‑term wellbeing."
        )
