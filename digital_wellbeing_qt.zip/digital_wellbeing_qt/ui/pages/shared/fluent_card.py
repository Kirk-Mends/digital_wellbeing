# # ui/pages/shared/fluent_card.py

# from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel
# import pyqtgraph as pg

# from ui.theme import AppMetrics, AppFonts


# class FluentCard(QFrame):
#     """
#     Universal Fluent card used by Smart Mode and AI Mode.
#     Automatically styled by QSS via:
#         #FluentCard
#         #CardTitle
#         #CardValue
#     """

#     def __init__(self, title, accent_color, value_font=None, has_spark=True):
#         super().__init__()

#         # QSS hook
#         self.setObjectName("FluentCard")

#         self.accent_color = accent_color
#         self.setMinimumHeight(AppMetrics.CARD_HEIGHT)

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(
#             AppMetrics.CARD_PADDING,
#             AppMetrics.CARD_PADDING,
#             AppMetrics.CARD_PADDING,
#             AppMetrics.CARD_PADDING,
#         )
#         layout.setSpacing(AppMetrics.GAP_SMALL)

#         # Accent bar
#         self.accent = QFrame()
#         self.accent.setFixedHeight(4)
#         self.accent.setStyleSheet(f"background-color: {accent_color}; border-radius: 2px;")
#         layout.addWidget(self.accent)

#         # Title
#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")
#         self.title_label.setFont(AppFonts.card_title())
#         layout.addWidget(self.title_label)

#         # Value
#         self.value_label = QLabel("—")
#         self.value_label.setObjectName("CardValue")
#         self.value_label.setFont(value_font or AppFonts.primary_value())
#         self.value_label.setWordWrap(True)
#         self.value_label.setContentsMargins(0, 6, 0, 0)
#         layout.addWidget(self.value_label)

#         # Sparkline
#         self.spark = None
#         if has_spark:
#             self.spark = pg.PlotWidget()
#             self.spark.setFixedHeight(60)
#             self.spark.setBackground(None)
#             self.spark.hideAxis("left")
#             self.spark.hideAxis("bottom")
#             layout.addWidget(self.spark)

#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)












# from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel
# import pyqtgraph as pg

# from ui.core.theme import AppMetrics


# class FluentCard(QFrame):
#     """
#     Universal Fluent card used by Smart Mode and AI Mode.
#     Styled entirely by QSS via:
#         #FluentCard
#         #CardTitle
#         #CardValue
#     """

#     def __init__(self, title, accent_color, value_font=None, has_spark=True):
#         super().__init__()

#         # QSS hook
#         self.setObjectName("FluentCard")

#         # Ensure card height is never collapsed by QSS
#         self.setMinimumHeight(AppMetrics.CARD_HEIGHT)

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(
#             AppMetrics.CARD_PADDING,
#             AppMetrics.CARD_PADDING,
#             AppMetrics.CARD_PADDING,
#             AppMetrics.CARD_PADDING,
#         )
#         layout.setSpacing(AppMetrics.GAP_SMALL)

#         # Accent bar
#         self.accent = QFrame()
#         self.accent.setFixedHeight(4)
#         self.accent.setStyleSheet(f"background-color: {accent_color}; border-radius: 2px;")
#         layout.addWidget(self.accent)

#         # Title (QSS controls font)
#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")
#         layout.addWidget(self.title_label)

#         # Value (QSS controls font)
#         self.value_label = QLabel("—")
#         self.value_label.setObjectName("CardValue")
#         self.value_label.setWordWrap(True)
#         self.value_label.setContentsMargins(0, 6, 0, 0)
#         layout.addWidget(self.value_label)

#         # Sparkline (protected height)
#         self.spark = None
#         if has_spark:
#             self.spark = pg.PlotWidget()
#             self.spark.setFixedHeight(60)  # prevents collapse
#             self.spark.setBackground(None)
#             self.spark.hideAxis("left")
#             self.spark.hideAxis("bottom")
#             layout.addWidget(self.spark)

#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)





# from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel, QGraphicsDropShadowEffect
# from PySide6.QtCore import Qt
# from PySide6.QtGui import QColor

# from pyqtgraph import PlotWidget  # PySide6-compatible

# from ui.core.theme import AppMetrics


# class FluentCard(QFrame):
#     def __init__(self, title, accent_color, value_font=None, has_spark=True):
#         super().__init__()

#         self.setObjectName("FluentCard")
#         self.setMinimumHeight(AppMetrics.CARD_HEIGHT)

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(
#             AppMetrics.CARD_PADDING,
#             AppMetrics.CARD_PADDING,
#             AppMetrics.CARD_PADDING,
#             AppMetrics.CARD_PADDING,
#         )
#         layout.setSpacing(AppMetrics.GAP_SMALL)

#         self.accent = QFrame()
#         self.accent.setFixedHeight(4)
#         self.accent.setStyleSheet(
#             f"background-color: {accent_color}; border-radius: 2px;"
#         )
#         layout.addWidget(self.accent)

#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")
#         layout.addWidget(self.title_label)

#         self.value_label = QLabel("—")
#         self.value_label.setObjectName("CardValue")
#         self.value_label.setWordWrap(True)
#         self.value_label.setContentsMargins(0, 6, 0, 0)
#         layout.addWidget(self.value_label)

#         self.spark = None
#         if has_spark:
#             self.spark = PlotWidget()
#             self.spark.setFixedHeight(60)
#             self.spark.setBackground(None)
#             self.spark.hideAxis("left")
#             self.spark.hideAxis("bottom")
#             layout.addWidget(self.spark)
            
#             self.spark.setStyleSheet("background: transparent;")
#             self.spark.setAttribute(Qt.WA_TranslucentBackground)
#             self.spark.setAutoFillBackground(False)


#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)

#     def apply_card_shadow(card):
#         shadow = QGraphicsDropShadowEffect(card)
#         shadow.setBlurRadius(28)
#         shadow.setOffset(0, 6)
#         shadow.setColor(QColor(0, 0, 0, 70))
#         card.setGraphicsEffect(shadow)

    







from PySide6.QtWidgets import QFrame, QVBoxLayout, QLabel, QGraphicsDropShadowEffect
from PySide6.QtCore import Qt
from PySide6.QtGui import QColor
from pyqtgraph import PlotWidget

from ui.core.theme import AppMetrics


class FluentCard(QFrame):
    def __init__(self, title, accent_color, value_font=None, has_spark=True):
        super().__init__()

        self.setObjectName("FluentCard")
        self.setMinimumHeight(AppMetrics.CARD_HEIGHT)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(
            AppMetrics.CARD_PADDING,
            AppMetrics.CARD_PADDING,
            AppMetrics.CARD_PADDING,
            AppMetrics.CARD_PADDING,
        )
        layout.setSpacing(AppMetrics.GAP_SMALL)

        # Accent bar
        self.accent = QFrame()
        self.accent.setFixedHeight(4)
        self.accent.setStyleSheet(
            f"background-color: {accent_color}; border-radius: 2px;"
        )
        layout.addWidget(self.accent)

        # Title
        self.title_label = QLabel(title)
        self.title_label.setObjectName("CardTitle")
        layout.addWidget(self.title_label)

        # Value
        self.value_label = QLabel("—")
        self.value_label.setObjectName("CardValue")
        self.value_label.setWordWrap(True)
        self.value_label.setContentsMargins(0, 6, 0, 0)
        layout.addWidget(self.value_label)

        # Sparkline
        self.spark = None
        if has_spark:
            self.spark = PlotWidget()
            self.spark.setFixedHeight(60)
            self.spark.setBackground(None)
            self.spark.hideAxis("left")
            self.spark.hideAxis("bottom")
            self.spark.setStyleSheet("background: transparent;")
            self.spark.setAttribute(Qt.WA_TranslucentBackground)
            self.spark.setAutoFillBackground(False)
            layout.addWidget(self.spark)

        layout.addStretch()

        # Apply premium Fluent shadow
        FluentCard.apply_card_shadow(self)

    def update_value(self, text):
        self.value_label.setText(text)

    @staticmethod
    def apply_card_shadow(card):
        shadow = QGraphicsDropShadowEffect(card)
        shadow.setBlurRadius(28)
        shadow.setOffset(0, 6)
        shadow.setColor(QColor(0, 0, 0, 70))
        card.setGraphicsEffect(shadow)
