# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame
# )
# from PySide6.QtCore import Qt
# from ui.widgets.meeting_badge import MeetingBadge
# from ui.widgets.mini_chart import MiniChart


# class FluentCard(QFrame):
#     def __init__(self, title, value="—"):
#         super().__init__()
#         self.setObjectName("FluentCard")

#         # ⭐ Create layout FIRST
#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(14, 14, 14, 14)
#         layout.setSpacing(6)

#         # Meeting badge (hidden by default)
#         self.meeting_badge = MeetingBadge()
#         self.meeting_badge.hide()
#         layout.addWidget(self.meeting_badge, alignment=Qt.AlignLeft)

#         # Title
#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")
#         layout.addWidget(self.title_label)

#         # Value
#         self.value_label = QLabel(value)
#         self.value_label.setObjectName("CardValue")
#         layout.addWidget(self.value_label)

#         # Mini chart (optional)
#         self.chart = MiniChart()
#         layout.addWidget(self.chart)

#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)


# class Dashboard(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # -------------------------
#         # TOP ROW (3 cards)
#         # -------------------------
#         top_row = QHBoxLayout()
#         top_row.setSpacing(20)

#         self.card_screen_time = FluentCard("Screen Time Today")
#         self.card_breaks = FluentCard("Breaks Taken")
#         self.card_mode = FluentCard("Current Mode")

#         top_row.addWidget(self.card_screen_time)
#         top_row.addWidget(self.card_breaks)
#         top_row.addWidget(self.card_mode)

#         layout.addLayout(top_row)

#         # -------------------------
#         # SECOND ROW (3 cards)
#         # -------------------------
#         mid_row = QHBoxLayout()
#         mid_row.setSpacing(20)

#         self.card_real_time = FluentCard("Real Time")
#         self.card_active_time = FluentCard("Active Time")
#         self.card_next_break = FluentCard("Next Break")

#         mid_row.addWidget(self.card_real_time)
#         mid_row.addWidget(self.card_active_time)
#         mid_row.addWidget(self.card_next_break)

#         layout.addLayout(mid_row)

#         # -------------------------
#         # THIRD ROW (3 cards)
#         # -------------------------
#         bottom_row = QHBoxLayout()
#         bottom_row.setSpacing(20)

#         self.card_meeting = FluentCard("Meeting Mode")
#         self.card_behavior = FluentCard("Behavior")
#         self.card_fatigue = FluentCard("Fatigue Score")

#         bottom_row.addWidget(self.card_meeting)
#         bottom_row.addWidget(self.card_behavior)
#         bottom_row.addWidget(self.card_fatigue)

#         layout.addLayout(bottom_row)

#         # -------------------------
#         # MINI CHART PLACEHOLDER
#         # -------------------------
#         self.chart_placeholder = QFrame()
#         self.chart_placeholder.setObjectName("ChartPlaceholder")
#         self.chart_placeholder.setMinimumHeight(160)

#         layout.addWidget(self.chart_placeholder)

#     # -------------------------
#     # UPDATE DASHBOARD VALUES
#     # -------------------------
#     def update_dashboard(self, data):
#         self.card_screen_time.update_value(data.get("screen_time", "—"))
#         self.card_breaks.update_value(data.get("breaks", "—"))
#         self.card_mode.update_value(data.get("mode", "—"))

#         self.card_real_time.update_value(data.get("real_time", "—"))
#         self.card_active_time.update_value(data.get("active_time", "—"))
#         self.card_next_break.update_value(data.get("next_break", "—"))

#         self.card_meeting.update_value(data.get("meeting", "—"))
#         self.card_behavior.update_value(data.get("behavior", "—"))
#         self.card_fatigue.update_value(data.get("fatigue", "—"))













# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame
# )
# from PySide6.QtCore import Qt
# from ui.widgets.meeting_badge import MeetingBadge
# from ui.widgets.mini_chart import MiniChart


# class FluentCard(QFrame):
#     def __init__(self, title, value="—"):
#         super().__init__()
#         self.setObjectName("FluentCard")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(14, 14, 14, 14)
#         layout.setSpacing(6)

#         # Meeting badge (hidden by default)
#         self.meeting_badge = MeetingBadge()
#         self.meeting_badge.hide()
#         layout.addWidget(self.meeting_badge, alignment=Qt.AlignLeft)

#         # Title
#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")
#         layout.addWidget(self.title_label)

#         # Value
#         self.value_label = QLabel(value)
#         self.value_label.setObjectName("CardValue")
#         layout.addWidget(self.value_label)

#         # Mini chart
#         self.chart = MiniChart()
#         layout.addWidget(self.chart)

#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)


# class Dashboard(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # -------------------------
#         # TOP ROW
#         # -------------------------
#         top_row = QHBoxLayout()
#         top_row.setSpacing(20)

#         self.card_screen_time = FluentCard("Screen Time Today")
#         self.card_breaks = FluentCard("Breaks Taken")
#         self.card_mode = FluentCard("Current Mode")

#         top_row.addWidget(self.card_screen_time)
#         top_row.addWidget(self.card_breaks)
#         top_row.addWidget(self.card_mode)

#         layout.addLayout(top_row)

#         # -------------------------
#         # SECOND ROW
#         # -------------------------
#         mid_row = QHBoxLayout()
#         mid_row.setSpacing(20)

#         self.card_real_time = FluentCard("Real Time")
#         self.card_active_time = FluentCard("Active Time")
#         self.card_next_break = FluentCard("Next Break")

#         mid_row.addWidget(self.card_real_time)
#         mid_row.addWidget(self.card_active_time)
#         mid_row.addWidget(self.card_next_break)

#         layout.addLayout(mid_row)

#         # -------------------------
#         # THIRD ROW
#         # -------------------------
#         bottom_row = QHBoxLayout()
#         bottom_row.setSpacing(20)

#         self.card_meeting = FluentCard("Meeting Mode")
#         self.card_behavior = FluentCard("Behavior")
#         self.card_fatigue = FluentCard("Fatigue Score")

#         bottom_row.addWidget(self.card_meeting)
#         bottom_row.addWidget(self.card_behavior)
#         bottom_row.addWidget(self.card_fatigue)

#         layout.addLayout(bottom_row)

#         # ⭐ FIX: Expose a page‑level meeting badge
#         self.meeting_badge = self.card_meeting.meeting_badge

#         # -------------------------
#         # CHART PLACEHOLDER
#         # -------------------------
#         self.chart_placeholder = QFrame()
#         self.chart_placeholder.setObjectName("ChartPlaceholder")
#         self.chart_placeholder.setMinimumHeight(160)

#         layout.addWidget(self.chart_placeholder)

#     # -------------------------
#     # UPDATE DASHBOARD VALUES
#     # -------------------------
#     def update_dashboard(self, data):
#         self.card_screen_time.update_value(data.get("screen_time", "—"))
#         self.card_breaks.update_value(data.get("breaks", "—"))
#         self.card_mode.update_value(data.get("mode", "—"))

#         self.card_real_time.update_value(data.get("real_time", "—"))
#         self.card_active_time.update_value(data.get("active_time", "—"))
#         self.card_next_break.update_value(data.get("next_break", "—"))

#         self.card_meeting.update_value(data.get("meeting", "—"))
#         self.card_behavior.update_value(data.get("behavior", "—"))
#         self.card_fatigue.update_value(data.get("fatigue", "—"))


































# # new architectural version with intelligent panel and meeting badge support
# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame
# )
# from PySide6.QtCore import Qt
# from ui.widgets.meeting_badge import MeetingBadge
# from ui.widgets.mini_chart import MiniChart


# class FluentCard(QFrame):
#     def __init__(self, title, value="—"):
#         super().__init__()
#         self.setObjectName("FluentCard")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(14, 14, 14, 14)
#         layout.setSpacing(6)

#         # Meeting badge (hidden by default)
#         self.meeting_badge = MeetingBadge()
#         self.meeting_badge.hide()
#         layout.addWidget(self.meeting_badge, alignment=Qt.AlignLeft)

#         # Title
#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")
#         layout.addWidget(self.title_label)

#         # Value
#         self.value_label = QLabel(value)
#         self.value_label.setObjectName("CardValue")
#         layout.addWidget(self.value_label)

#         # Mini chart (optional)
#         self.chart = MiniChart()
#         layout.addWidget(self.chart)

#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)


# class Dashboard(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # -------------------------
#         # TOP ROW (Screen Time, Breaks, Behavior)
#         # -------------------------
#         top_row = QHBoxLayout()
#         top_row.setSpacing(20)

#         self.card_screen_time = FluentCard("Screen Time Today")
#         self.card_breaks = FluentCard("Breaks Taken")
#         self.card_behavior = FluentCard("Behavior")

#         top_row.addWidget(self.card_screen_time)
#         top_row.addWidget(self.card_breaks)
#         top_row.addWidget(self.card_behavior)

#         layout.addLayout(top_row)

#         # -------------------------
#         # SECOND ROW (Fatigue, Meeting Mode, Status)
#         # -------------------------
#         mid_row = QHBoxLayout()
#         mid_row.setSpacing(20)

#         self.card_fatigue = FluentCard("Fatigue Score")
#         self.card_meeting = FluentCard("Meeting Mode")
#         self.card_status = FluentCard("Status")

#         mid_row.addWidget(self.card_fatigue)
#         mid_row.addWidget(self.card_meeting)
#         mid_row.addWidget(self.card_status)

#         layout.addLayout(mid_row)

#         # Expose meeting badge for main_window
#         self.meeting_badge = self.card_meeting.meeting_badge

#         layout.addStretch()

#     # -------------------------
#     # UPDATE DASHBOARD VALUES
#     # -------------------------
#     def update_dashboard(self, data):
#         self.card_screen_time.update_value(data.get("screen_time", "—"))
#         self.card_breaks.update_value(data.get("breaks", "—"))
#         self.card_behavior.update_value(data.get("behavior", "—"))
#         self.card_fatigue.update_value(data.get("fatigue", "—"))
#         self.card_meeting.update_value(data.get("meeting", "—"))
#         self.card_status.update_value(data.get("status", "—"))

























# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame
# )
# from PySide6.QtCore import Qt
# from PySide6.QtGui import QPixmap

# from ui.widgets.meeting_badge import MeetingBadge
# from ui.widgets.mini_chart import MiniChart


# class FluentCard(QFrame):
#     def __init__(self, title, value="—", show_chart=True, show_heat=False, icon_path=None):
#         super().__init__()
#         self.setObjectName("FluentCard")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(14, 14, 14, 14)
#         layout.setSpacing(6)

#         # Optional icon
#         if icon_path:
#             self.icon = QLabel()
#             self.icon.setPixmap(
#                 QPixmap(icon_path).scaled(22, 22, Qt.KeepAspectRatio, Qt.SmoothTransformation)
#             )
#             layout.addWidget(self.icon, alignment=Qt.AlignLeft)

#         # Meeting badge (hidden by default)
#         self.meeting_badge = MeetingBadge()
#         self.meeting_badge.hide()
#         layout.addWidget(self.meeting_badge, alignment=Qt.AlignLeft)

#         # Title
#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")
#         layout.addWidget(self.title_label)

#         # Value
#         self.value_label = QLabel(value)
#         self.value_label.setObjectName("CardValue")
#         layout.addWidget(self.value_label)

#         # Heat bar (for fatigue)
#         self.heat_bar = None
#         if show_heat:
#             self.heat_bar = QFrame()
#             self.heat_bar.setFixedHeight(6)
#             self.heat_bar.setStyleSheet("background-color: #4CAF50; border-radius: 3px;")
#             layout.addWidget(self.heat_bar)

#         # Mini chart
#         self.chart = None
#         if show_chart:
#             self.chart = MiniChart()
#             layout.addWidget(self.chart)

#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)

#     def set_heat_color(self, level):
#         if not self.heat_bar:
#             return

#         colors = {
#             "Low": "#4CAF50",
#             "Medium": "#FFC107",
#             "High": "#FF5722",
#             "Critical": "#F44336"
#         }
#         self.heat_bar.setStyleSheet(
#             f"background-color: {colors.get(level, '#4CAF50')}; border-radius: 3px;"
#         )


# class Dashboard(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # -------------------------
#         # ROW 1 — Screen Time, Breaks, Active Mode
#         # -------------------------
#         row1 = QHBoxLayout()
#         row1.setSpacing(20)

#         self.card_screen_time = FluentCard(
#             "Screen Time Today", icon_path="assets/icons/time.png"
#         )
#         self.card_breaks = FluentCard(
#             "Breaks Taken", icon_path="assets/icons/break.png"
#         )
#         self.card_mode = FluentCard(
#             "Active Mode", icon_path="assets/icons/mode.png"
#         )

#         row1.addWidget(self.card_screen_time)
#         row1.addWidget(self.card_breaks)
#         row1.addWidget(self.card_mode)

#         layout.addLayout(row1)

#         # -------------------------
#         # ROW 2 — Behavior, Fatigue, Meeting
#         # -------------------------
#         row2 = QHBoxLayout()
#         row2.setSpacing(20)

#         self.card_behavior = FluentCard(
#             "Behavior", icon_path="assets/icons/behavior.png"
#         )
#         self.card_fatigue = FluentCard(
#             "Fatigue", show_heat=True, icon_path="assets/icons/fatigue.png"
#         )
#         self.card_meeting = FluentCard(
#             "Meeting Mode", icon_path="assets/icons/meeting.png"
#         )

#         row2.addWidget(self.card_behavior)
#         row2.addWidget(self.card_fatigue)
#         row2.addWidget(self.card_meeting)

#         layout.addLayout(row2)

#         # -------------------------
#         # ROW 3 — Status + Trend Charts
#         # -------------------------
#         row3 = QHBoxLayout()
#         row3.setSpacing(20)

#         self.card_status = FluentCard(
#             "Status", icon_path="assets/icons/status.png", show_chart=False
#         )
#         self.card_trend = FluentCard(
#             "Daily Trend", icon_path="assets/icons/trend.png"
#         )
#         self.card_fatigue_trend = FluentCard(
#             "Fatigue Trend", icon_path="assets/icons/heat.png"
#         )

#         row3.addWidget(self.card_status)
#         row3.addWidget(self.card_trend)
#         row3.addWidget(self.card_fatigue_trend)

#         layout.addLayout(row3)

#         # Expose meeting badge for main_window
#         self.meeting_badge = self.card_meeting.meeting_badge

#         layout.addStretch()

#     # -------------------------
#     # UPDATE DASHBOARD VALUES
#     # -------------------------
#     def update_dashboard(self, data):
#         # Row 1
#         self.card_screen_time.update_value(data["screen_time"])
#         self.card_breaks.update_value(data["breaks"])
#         self.card_mode.update_value(data["mode"])

#         # Row 2
#         self.card_behavior.update_value(data["behavior"])
#         self.card_fatigue.update_value(f"{data['fatigue_score']} ({data['fatigue_level']})")
#         self.card_fatigue.set_heat_color(data["fatigue_level"])
#         self.card_meeting.update_value(data["meeting"])

#         # Row 3
#         self.card_status.update_value(data["status"])

#         # Charts
#         if self.card_screen_time.chart:
#             self.card_screen_time.chart.add_point(data["screen_seconds"])

#         if self.card_fatigue.chart:
#             self.card_fatigue.chart.add_point(data["fatigue_score"])

#         if self.card_trend.chart:
#             self.card_trend.chart.add_point(data["trend_value"])

#         if self.card_fatigue_trend.chart:
#             self.card_fatigue_trend.chart.add_point(data["fatigue_score"])

























# # I just upgraded the icos path to be able tto download. That's all add to the previous code.



# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame
# )
# from PySide6.QtCore import Qt
# from PySide6.QtGui import QPixmap

# from ui.widgets.meeting_badge import MeetingBadge
# from ui.widgets.mini_chart import MiniChart


# class FluentCard(QFrame):
#     def __init__(self, title, value="—", show_chart=True, show_heat=False, icon_path=None):
#         super().__init__()
#         self.setObjectName("FluentCard")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(14, 14, 14, 14)
#         layout.setSpacing(6)

        
#             # Optional icon
#         if icon_path:
#             self.icon = QLabel()
#             pix = QPixmap(icon_path)

#             if not pix.isNull():
#                 self.icon.setPixmap(
#                     pix.scaled(22, 22, Qt.KeepAspectRatio, Qt.SmoothTransformation)
#                 )

#             layout.addWidget(self.icon, alignment=Qt.AlignLeft)


#         # Meeting badge (hidden by default)
#         self.meeting_badge = MeetingBadge()
#         self.meeting_badge.hide()
#         layout.addWidget(self.meeting_badge, alignment=Qt.AlignLeft)

#         # Title
#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")
#         layout.addWidget(self.title_label)

#         # Value
#         self.value_label = QLabel(value)
#         self.value_label.setObjectName("CardValue")
#         layout.addWidget(self.value_label)

#         # Heat bar (for fatigue)
#         self.heat_bar = None
#         if show_heat:
#             self.heat_bar = QFrame()
#             self.heat_bar.setFixedHeight(6)
#             self.heat_bar.setStyleSheet("background-color: #4CAF50; border-radius: 3px;")
#             layout.addWidget(self.heat_bar)

#         # Mini chart
#         self.chart = None
#         if show_chart:
#             self.chart = MiniChart()
#             layout.addWidget(self.chart)

#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)

#     def set_heat_color(self, level):
#         if not self.heat_bar:
#             return

#         colors = {
#             "Low": "#4CAF50",
#             "Medium": "#FFC107",
#             "High": "#FF5722",
#             "Critical": "#F44336"
#         }
#         self.heat_bar.setStyleSheet(
#             f"background-color: {colors.get(level, '#4CAF50')}; border-radius: 3px;"
#         )


# class Dashboard(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # -------------------------
#         # ROW 1 — Screen Time, Breaks, Active Mode
#         # -------------------------
#         row1 = QHBoxLayout()
#         row1.setSpacing(20)

#         self.card_screen_time = FluentCard(
#             "Screen Time Today", icon_path="assets/icons/time.png"
#         )
#         self.card_breaks = FluentCard(
#             "Breaks Taken", icon_path="assets/icons/break.png"
#         )
#         self.card_mode = FluentCard(
#             "Active Mode", icon_path="assets/icons/mode.png"
#         )

#         row1.addWidget(self.card_screen_time)
#         row1.addWidget(self.card_breaks)
#         row1.addWidget(self.card_mode)

#         layout.addLayout(row1)

#         # -------------------------
#         # ROW 2 — Behavior, Fatigue, Meeting
#         # -------------------------
#         row2 = QHBoxLayout()
#         row2.setSpacing(20)

#         self.card_behavior = FluentCard(
#             "Behavior", icon_path="assets/icons/behavior.png"
#         )
#         self.card_fatigue = FluentCard(
#             "Fatigue", show_heat=True, icon_path="assets/icons/fatigue.png"
#         )
#         self.card_meeting = FluentCard(
#             "Meeting Mode", icon_path="assets/icons/meeting.png"
#         )

#         row2.addWidget(self.card_behavior)
#         row2.addWidget(self.card_fatigue)
#         row2.addWidget(self.card_meeting)

#         layout.addLayout(row2)

#         # -------------------------
#         # ROW 3 — Status + Trend Charts
#         # -------------------------
#         row3 = QHBoxLayout()
#         row3.setSpacing(20)

#         self.card_status = FluentCard(
#             "Status", icon_path="assets/icons/status.png", show_chart=False
#         )
#         self.card_trend = FluentCard(
#             "Daily Trend", icon_path="assets/icons/trend.png"
#         )
#         self.card_fatigue_trend = FluentCard(
#             "Fatigue Trend", icon_path="assets/icons/heat.png"
#         )

#         row3.addWidget(self.card_status)
#         row3.addWidget(self.card_trend)
#         row3.addWidget(self.card_fatigue_trend)

#         layout.addLayout(row3)

#         # Expose meeting badge for main_window
#         self.meeting_badge = self.card_meeting.meeting_badge

#         layout.addStretch()

#     # -------------------------
#     # UPDATE DASHBOARD VALUES
#     # -------------------------
#     def update_dashboard(self, data):
#         # Row 1
#         self.card_screen_time.update_value(data["screen_time"])
#         self.card_breaks.update_value(data["breaks"])
#         self.card_mode.update_value(data["mode"])

#         # Row 2
#         self.card_behavior.update_value(data["behavior"])
#         self.card_fatigue.update_value(f"{data['fatigue_score']} ({data['fatigue_level']})")
#         self.card_fatigue.set_heat_color(data["fatigue_level"])
#         self.card_meeting.update_value(data["meeting"])

#         # Row 3
#         self.card_status.update_value(data["status"])

#         # Charts
#         if self.card_screen_time.chart:
#             self.card_screen_time.chart.add_point(data["screen_seconds"])

#         if self.card_fatigue.chart:
#             self.card_fatigue.chart.add_point(data["fatigue_score"])

#         if self.card_trend.chart:
#             self.card_trend.chart.add_point(data["screen_seconds"])

#         if self.card_fatigue_trend.chart:
#             self.card_fatigue_trend.chart.add_point(data["fatigue_score"])















# 5 
# upgrade for old mini chart 



# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame
# )
# from PySide6.QtCore import Qt
# from PySide6.QtGui import QPixmap

# from ui.widgets.meeting_badge import MeetingBadge
# from ui.widgets.mini_chart import MiniChart


# class FluentCard(QFrame):
#     """
#     Dashboard Fluent card with optional icon, meeting badge, value, and mini chart.
#     Styled via QSS using:
#         #FluentCard
#         #CardTitle
#         #CardValue
#     """

#     def __init__(self, title, value="—", show_chart=True, show_heat=False, icon_path=None):
#         super().__init__()
#         self.setObjectName("FluentCard")

#         # Protect height so cards don't collapse/overlap
#         self.setMinimumHeight(180)

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(14, 14, 14, 14)
#         layout.setSpacing(6)

#         # Optional icon
#         if icon_path:
#             self.icon = QLabel()
#             pix = QPixmap(icon_path)
#             if not pix.isNull():
#                 self.icon.setPixmap(
#                     pix.scaled(22, 22, Qt.KeepAspectRatio, Qt.SmoothTransformation)
#                 )
#             layout.addWidget(self.icon, alignment=Qt.AlignLeft)
#         else:
#             self.icon = None

#         # Meeting badge (hidden by default, used mainly on Status card)
#         self.meeting_badge = MeetingBadge()
#         self.meeting_badge.hide()
#         layout.addWidget(self.meeting_badge, alignment=Qt.AlignLeft)

#         # Title
#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")
#         layout.addWidget(self.title_label)

#         # Value
#         self.value_label = QLabel(value)
#         self.value_label.setObjectName("CardValue")
#         self.value_label.setWordWrap(True)
#         layout.addWidget(self.value_label)

#         # Heat bar (for fatigue)
#         self.heat_bar = None
#         if show_heat:
#             self.heat_bar = QFrame()
#             self.heat_bar.setFixedHeight(6)
#             self.heat_bar.setStyleSheet("background-color: #4CAF50; border-radius: 3px;")
#             layout.addWidget(self.heat_bar)

#         # Mini chart (modern mini‑graph)
#         self.chart = None
#         if show_chart:
#             self.chart = MiniChart()
#             self.chart.setMinimumHeight(60)
#             self.chart.setMaximumHeight(80)
#             layout.addWidget(self.chart)

#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)

#     def set_heat_color(self, level):
#         if not self.heat_bar:
#             return

#         colors = {
#             "Low": "#4CAF50",
#             "Medium": "#FFC107",
#             "High": "#FF5722",
#             "Critical": "#F44336"
#         }
#         self.heat_bar.setStyleSheet(
#             f"background-color: {colors.get(level, '#4CAF50')}; border-radius: 3px;"
#         )


# class Dashboard(QWidget):
#     """
#     Premium dashboard with:
#       - Row 1: Screen Time, Breaks, Active Mode
#       - Row 2: Behavior, Fatigue (with heat + mini‑trend), Status (with meeting badge)
#       - Row 3: Daily Overview (combined trend card)
#     """

#     def __init__(self, main):
#         super().__init__()
#         self.main = main

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # -------------------------
#         # ROW 1 — Screen Time, Breaks, Active Mode
#         # -------------------------
#         row1 = QHBoxLayout()
#         row1.setSpacing(20)

#         self.card_screen_time = FluentCard(
#             "Screen Time Today", icon_path="assets/icons/time.png", show_chart=True
#         )
#         self.card_breaks = FluentCard(
#             "Breaks Taken", icon_path="assets/icons/break.png", show_chart=True
#         )
#         self.card_mode = FluentCard(
#             "Active Mode", icon_path="assets/icons/mode.png", show_chart=False
#         )

#         row1.addWidget(self.card_screen_time)
#         row1.addWidget(self.card_breaks)
#         row1.addWidget(self.card_mode)
#         layout.addLayout(row1)

#         # -------------------------
#         # ROW 2 — Behavior, Fatigue, Status (with Meeting badge)
#         # -------------------------
#         row2 = QHBoxLayout()
#         row2.setSpacing(20)

#         self.card_behavior = FluentCard(
#             "Behavior", icon_path="assets/icons/behavior.png", show_chart=True
#         )
#         self.card_fatigue = FluentCard(
#             "Fatigue", show_heat=True, icon_path="assets/icons/fatigue.png", show_chart=True
#         )
#         self.card_status = FluentCard(
#             "Status", icon_path="assets/icons/status.png", show_chart=False
#         )

#         row2.addWidget(self.card_behavior)
#         row2.addWidget(self.card_fatigue)
#         row2.addWidget(self.card_status)
#         layout.addLayout(row2)

#         # -------------------------
#         # ROW 3 — Daily Overview (combined trend)
#         # -------------------------
#         row3 = QHBoxLayout()
#         row3.setSpacing(20)

#         self.card_overview = FluentCard(
#             "Daily Overview", icon_path="assets/icons/trend.png", show_chart=True
#         )

#         row3.addWidget(self.card_overview)
#         layout.addLayout(row3)

#         # Expose meeting badge for main_window (from Status card)
#         self.meeting_badge = self.card_status.meeting_badge

#         layout.addStretch()

#     # -------------------------
#     # UPDATE DASHBOARD VALUES
#     # -------------------------
#     def update_dashboard(self, data):
#         # Row 1
#         self.card_screen_time.update_value(data["screen_time"])
#         self.card_breaks.update_value(data["breaks"])
#         self.card_mode.update_value(data["mode"])

#         # Row 2
#         self.card_behavior.update_value(data["behavior"])
#         self.card_fatigue.update_value(f"{data['fatigue_score']} ({data['fatigue_level']})")
#         self.card_fatigue.set_heat_color(data["fatigue_level"])
#         self.card_status.update_value(data["status"])

#         # Meeting badge visibility
#         if data.get("meeting") and data["meeting"] != "Off":
#             self.meeting_badge.show()
#             self.meeting_badge.update_text(data["meeting"])
#         else:
#             self.meeting_badge.hide()

#         # Row 3 — Overview text
#         overview_text = (
#             f"Screen Time: {data['screen_time']}\n"
#             f"Breaks: {data['breaks']}\n"
#             f"Behavior: {data['behavior']}\n"
#             f"Fatigue: {data['fatigue_score']} ({data['fatigue_level']})"
#         )
#         self.card_overview.update_value(overview_text)

#         # Charts — modern mini‑graphs
#         if self.card_screen_time.chart:
#             self.card_screen_time.chart.add_point(data["screen_seconds"])

#         if self.card_breaks.chart:
#             self.card_breaks.chart.add_point(data["breaks"])

#         if self.card_behavior.chart:
#             # You can map behavior to a numeric trend if desired
#             self.card_behavior.chart.add_point(data.get("behavior_score", 0))

#         if self.card_fatigue.chart:
#             self.card_fatigue.chart.add_point(data["fatigue_score"])

#         if self.card_overview.chart:
#             # Combined signal: e.g., screen time seconds
#             self.card_overview.chart.add_point(data["screen_seconds"])












# Upgrade with better mini chart support
from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame
)
from PySide6.QtCore import Qt, QPropertyAnimation, QEasingCurve
from PySide6.QtGui import QPixmap

from ui.widgets.meeting_badge import MeetingBadge
from ui.widgets.mini_chart import MiniChart
from ui.widgets.fluent_blur import FluentBlur


# ============================================================
# PREMIUM FLUENT CARD (Dashboard Version)
# ============================================================

class FluentCard(QFrame):
    """
    Premium Fluent dashboard card with:
      - icon
      - title
      - animated value
      - modern sparkline (MiniChart)
      - optional heat bar
      - optional meeting badge
      - fade-in animation
    """

    def __init__(self, title, value="—", show_chart=True, show_heat=False, icon_path=None):
        super().__init__()
        self.setObjectName("FluentCard")

        # Protect height so cards never collapse
        self.setMinimumHeight(190)

        # Fade-in animation
        self.setGraphicsEffect(None)
        self.fade_anim = QPropertyAnimation(self, b"windowOpacity")
        self.fade_anim.setDuration(350)
        self.fade_anim.setStartValue(0.0)
        self.fade_anim.setEndValue(1.0)
        self.fade_anim.start()

        layout = QVBoxLayout(self)
        layout.setContentsMargins(16, 16, 16, 16)
        layout.setSpacing(8)

        # Icon
        if icon_path:
            self.icon = QLabel()
            pix = QPixmap(icon_path)
            if not pix.isNull():
                self.icon.setPixmap(
                    pix.scaled(24, 24, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                )
            layout.addWidget(self.icon, alignment=Qt.AlignLeft)
        else:
            self.icon = None

        # Meeting badge (hidden unless used)
        self.meeting_badge = MeetingBadge()
        self.meeting_badge.hide()
        layout.addWidget(self.meeting_badge, alignment=Qt.AlignLeft)

        # Title
        self.title_label = QLabel(title)
        self.title_label.setObjectName("CardTitle")
        layout.addWidget(self.title_label)

        # Value (animated)
        self.value_label = QLabel(value)
        self.value_label.setObjectName("CardValue")
        self.value_label.setWordWrap(True)
        layout.addWidget(self.value_label)

        self.current_value = value
        self.value_anim = None

        # Heat bar
        self.heat_bar = None
        if show_heat:
            self.heat_bar = QFrame()
            self.heat_bar.setFixedHeight(6)
            self.heat_bar.setStyleSheet("background-color: #4CAF50; border-radius: 3px;")
            layout.addWidget(self.heat_bar)

        # Modern sparkline
        self.chart = None
        if show_chart:
            self.chart = MiniChart()
            self.chart.setMinimumHeight(70)
            self.chart.setMaximumHeight(80)
            layout.addWidget(self.chart)

        layout.addStretch()

    # Smooth value animation
    def update_value(self, new_value):
        if isinstance(new_value, (int, float)) and isinstance(self.current_value, (int, float)):
            self.animate_value(self.current_value, new_value)
        else:
            self.value_label.setText(str(new_value))

        self.current_value = new_value

    def animate_value(self, start, end):
        if self.value_anim:
            self.value_anim.stop()

        self.value_anim = QPropertyAnimation(self, b"value")
        self.value_anim.setDuration(350)
        self.value_anim.setStartValue(float(start))
        self.value_anim.setEndValue(float(end))
        self.value_anim.setEasingCurve(QEasingCurve.OutCubic)
        self.value_anim.valueChanged.connect(
            lambda v: self.value_label.setText(f"{v:.1f}")
        )
        self.value_anim.start()

    # Heat bar color
    def set_heat_color(self, level):
        if not self.heat_bar:
            return

        colors = {
            "Low": "#4CAF50",
            "Medium": "#FFC107",
            "High": "#FF5722",
            "Critical": "#F44336"
        }
        self.heat_bar.setStyleSheet(
            f"background-color: {colors.get(level, '#4CAF50')}; border-radius: 3px;"
        )


# ============================================================
# PREMIUM DASHBOARD
# ============================================================

class Dashboard(QWidget):
    """
    Premium dashboard with:
      - Row 1: Screen Time, Breaks, Active Mode
      - Row 2: Behavior, Fatigue (with heat + mini‑trend), Status (with meeting badge)
      - Row 3: Daily Overview (combined trend card)
    """

    def __init__(self, main):
        super().__init__()
        self.main = main

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)

        # -------------------------
        # ROW 1
        # -------------------------
        row1 = QHBoxLayout()
        row1.setSpacing(20)

        self.card_screen_time = FluentCard("Screen Time Today", icon_path="assets/icons/time.png")
        self.card_breaks = FluentCard("Breaks Taken", icon_path="assets/icons/break.png")
        self.card_mode = FluentCard("Active Mode", icon_path="assets/icons/mode.png", show_chart=False)

        row1.addWidget(self.wrap_blur(self.card_screen_time))
        row1.addWidget(self.wrap_blur(self.card_breaks))
        row1.addWidget(self.wrap_blur(self.card_mode))
        layout.addLayout(row1)

        # -------------------------
        # ROW 2
        # -------------------------
        row2 = QHBoxLayout()
        row2.setSpacing(20)

        self.card_behavior = FluentCard("Behavior", icon_path="assets/icons/behavior.png")
        self.card_fatigue = FluentCard("Fatigue", show_heat=True, icon_path="assets/icons/fatigue.png")
        self.card_status = FluentCard("Status", icon_path="assets/icons/status.png", show_chart=False)

        row2.addWidget(self.wrap_blur(self.card_behavior))
        row2.addWidget(self.wrap_blur(self.card_fatigue))
        row2.addWidget(self.wrap_blur(self.card_status))
        layout.addLayout(row2)

        # -------------------------
        # ROW 3
        # -------------------------
        row3 = QHBoxLayout()
        row3.setSpacing(20)

        self.card_overview = FluentCard("Daily Overview", icon_path="assets/icons/trend.png")

        row3.addWidget(self.wrap_blur(self.card_overview))
        layout.addLayout(row3)

        self.meeting_badge = self.card_status.meeting_badge

        layout.addStretch()

    # Wrap card in FluentBlur
    def wrap_blur(self, card):
        blur = FluentBlur(radius=25, opacity=0.30)
        blur.layout.addWidget(card)
        return blur

    # Update dashboard
    def update_dashboard(self, data):

        # Row 1
        self.card_screen_time.update_value(data["screen_time"])
        self.card_breaks.update_value(data["breaks"])
        self.card_mode.update_value(data["mode"])

        # Row 2
        self.card_behavior.update_value(data["behavior"])
        self.card_fatigue.update_value(f"{data['fatigue_score']} ({data['fatigue_level']})")
        self.card_fatigue.set_heat_color(data["fatigue_level"])
        self.card_status.update_value(data["status"])

        if data.get("meeting") and data["meeting"] != "Off":
            self.meeting_badge.show()
            self.meeting_badge.update_text(data["meeting"])
        else:
            self.meeting_badge.hide()

        # Row 3
        overview_text = (
            f"Screen Time: {data['screen_time']}\n"
            f"Breaks: {data['breaks']}\n"
            f"Behavior: {data['behavior']}\n"
            f"Fatigue: {data['fatigue_score']} ({data['fatigue_level']})"
        )
        self.card_overview.update_value(overview_text)

        # Charts
        if self.card_screen_time.chart:
            self.card_screen_time.chart.add_point(data["screen_seconds"])

        if self.card_breaks.chart:
            self.card_breaks.chart.add_point(float(data["breaks"]))

        if self.card_behavior.chart:
            self.card_behavior.chart.add_point(data.get("behavior_score", 0))

        if self.card_fatigue.chart:
            self.card_fatigue.chart.add_point(data["fatigue_score"])

        if self.card_overview.chart:
            self.card_overview.chart.add_point(data["screen_seconds"])
