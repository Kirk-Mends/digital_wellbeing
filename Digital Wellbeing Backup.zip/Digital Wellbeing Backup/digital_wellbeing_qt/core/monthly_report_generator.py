class MonthlyReportGenerator:
    def generate(self, summary, last_summary=None):
        if summary is None:
            return "No activity data available for this month."

        # Current month values
        total = summary["total_focus"]
        deep_work = summary["deep_work"]
        deep_reading = summary["deep_reading"]
        focused_interaction = summary["focused_interaction"]
        breaks = summary["breaks"]
        avg_fatigue = summary["avg_fatigue"]
        insights = summary["insights"]

        insights_text = "\n".join(f"• {i}" for i in insights)

        # ---------------------------------------------------------
        # MONTH-TO-MONTH COMPARISON (if last month exists)
        # ---------------------------------------------------------
        comparison_text = ""

        if last_summary:
            last_total = last_summary["total_focus"]
            last_deep_work = last_summary["deep_work"]
            last_fatigue = last_summary["avg_fatigue"]

            def pct_change(current, previous):
                if previous == 0:
                    return None
                return ((current - previous) / previous) * 100

            total_change = pct_change(total, last_total)
            deep_work_change = pct_change(deep_work, last_deep_work)
            fatigue_change = pct_change(avg_fatigue, last_fatigue)

            def format_change(label, value):
                if value is None:
                    return f"• {label}: no comparison available"
                arrow = "↑" if value > 0 else "↓"
                return f"• {label}: {arrow} {abs(value):.1f}%"

            comparison_text = (
                "\nMonth‑to‑Month Comparison:\n"
                f"{format_change('Total focus time', total_change)}\n"
                f"{format_change('Deep work time', deep_work_change)}\n"
                f"{format_change('Average fatigue', fatigue_change)}\n"
            )

        # ---------------------------------------------------------
        # FINAL REPORT TEXT
        # ---------------------------------------------------------
        report = (
            f"Here’s your monthly wellbeing summary:\n\n"
            f"• Total focused minutes: **{total}**\n"
            f"• Deep work minutes: **{deep_work}**\n"
            f"• Deep reading minutes: **{deep_reading}**\n"
            f"• Focused interaction minutes: **{focused_interaction}**\n"
            f"• Breaks taken: **{breaks}**\n"
            f"• Average fatigue level: **{avg_fatigue:.1f} / 100**\n\n"
            f"Monthly Insights:\n{insights_text}\n"
        )

        if comparison_text:
            report += f"\n{comparison_text}\n"

        report += "Keep building healthy habits — steady progress leads to long‑term wellbeing."

        return report
