# from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel
# from PySide6.QtCore import Qt

# from ui.widgets.live_timer import LiveTimer


# class SmartDashboard(QWidget):
#     def __init__(self, main_window):
#         super().__init__()

#         self.main = main_window

#         layout = QVBoxLayout(self)
#         layout.setAlignment(Qt.AlignTop)
#         layout.setContentsMargins(40, 40, 40, 40)
#         layout.setSpacing(20)

#         title = QLabel("Smart Mode")
#         title.setStyleSheet("font-size: 24px; font-weight: 600;")
#         layout.addWidget(title)

#         # Live Timer
#         self.timer_widget = LiveTimer(self.main.hybrid_engine, self.main)
#         layout.addWidget(self.timer_widget, alignment=Qt.AlignCenter)













# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton
# )
# from PySide6.QtCore import Qt, QTimer
# from ui.widgets.meeting_badge import MeetingBadge


# class FluentCard(QFrame):
#     def __init__(self, title, value="—"):
#         super().__init__()
#         self.setObjectName("FluentCard")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(14, 14, 14, 14)
#         layout.setSpacing(6)

#         # Meeting badge (hidden by default)
#         self.meeting_badge = MeetingBadge()
#         self.meeting_badge.hide()
#         layout.addWidget(self.meeting_badge, alignment=Qt.AlignLeft)

#         # Title
#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")
#         layout.addWidget(self.title_label)

#         # Value
#         self.value_label = QLabel(value)
#         self.value_label.setObjectName("CardValue")
#         layout.addWidget(self.value_label)

#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)


# class SmartModePage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # -------------------------
#         # LARGE TIMER CARD
#         # -------------------------
#         self.card_timer = FluentCard("Smart Mode Timer", "00:00:00")
#         self.card_timer.setMinimumHeight(150)
#         layout.addWidget(self.card_timer)

#         # -------------------------
#         # SECOND ROW (Next Break + Meeting Mode)
#         # -------------------------
#         row = QHBoxLayout()
#         row.setSpacing(20)

#         self.card_next_break = FluentCard("Next Break", "—")
#         self.card_meeting = FluentCard("Meeting Mode", "Off")

#         row.addWidget(self.card_next_break)
#         row.addWidget(self.card_meeting)

#         layout.addLayout(row)

#         # ⭐ FIX: Expose meeting badge for main_window
#         self.meeting_badge = self.card_meeting.meeting_badge

#         # -------------------------
#         # START / STOP BUTTON
#         # -------------------------
#         self.btn_toggle = QPushButton("Start Monitoring")
#         self.btn_toggle.setObjectName("PrimaryButton")
#         self.btn_toggle.setFixedHeight(44)
#         self.btn_toggle.clicked.connect(self.toggle_monitoring)

#         layout.addWidget(self.btn_toggle)

#         # Timer for updating UI
#         self.ui_timer = QTimer()
#         self.ui_timer.timeout.connect(self.update_ui)
#         self.ui_timer.start(1000)

#     # -------------------------
#     # START / STOP MONITORING
#     # -------------------------
#     def toggle_monitoring(self):
#         self.main.toggle_monitoring()

#         if self.main.monitoring:
#             self.btn_toggle.setText("Stop Monitoring")
#         else:
#             self.btn_toggle.setText("Start Monitoring")

#     # -------------------------
#     # UPDATE UI VALUES
#     # -------------------------
#     def update_ui(self):
#         if not self.main.monitoring:
#             return

#         # -------------------------
#         # REAL TIME
#         # -------------------------
#         real_seconds = int(self.main.hybrid_engine.real_time)
#         hrs = real_seconds // 3600
#         mins = (real_seconds % 3600) // 60
#         secs = real_seconds % 60

#         self.card_timer.update_value(
#             f"{int(hrs):02d}:{int(mins):02d}:{int(secs):02d}"
#         )

#         # -------------------------
#         # ACTIVE TIME
#         # -------------------------
#         active = getattr(self.main.hybrid_engine, "active_time", 0)
#         ahrs = active // 3600
#         amins = (active % 3600) // 60
#         asecs = active % 60

#         # ⭐ FIX: Convert to int to avoid float formatting crash
#         self.card_timer.title_label.setText(
#             f"Smart Mode Timer  •  Active: {int(ahrs):02d}:{int(amins):02d}:{int(asecs):02d}"
#         )

#         # -------------------------
#         # NEXT BREAK
#         # -------------------------
#         next_break = getattr(self.main.hybrid_engine, "next_break_estimate", None)
#         if next_break:
#             self.card_next_break.update_value(next_break)
#         else:
#             self.card_next_break.update_value("Calculating…")

#         # -------------------------
#         # MEETING MODE (new detection)
#         # -------------------------
#         signals = self.main.signals.to_dict()
#         meeting_active = (
#             signals.get("window_category") == "meeting"
#             or signals.get("webcam_active") is True
#         )

#         self.card_meeting.update_value("On" if meeting_active else "Off")











# # New architectural version

# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton
# )
# from PySide6.QtCore import Qt, QTimer
# from ui.widgets.meeting_badge import MeetingBadge
# import time


# class FluentCard(QFrame):
#     def __init__(self, title, value="—"):
#         super().__init__()
#         self.setObjectName("FluentCard")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(14, 14, 14, 14)
#         layout.setSpacing(6)

#         # Meeting badge
#         self.meeting_badge = MeetingBadge()
#         self.meeting_badge.hide()
#         layout.addWidget(self.meeting_badge, alignment=Qt.AlignLeft)

#         self.title_label = QLabel(title)
#         self.title_label.setObjectName("CardTitle")
#         layout.addWidget(self.title_label)

#         self.value_label = QLabel(value)
#         self.value_label.setObjectName("CardValue")
#         layout.addWidget(self.value_label)

#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)


# class SmartModePage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # -------------------------
#         # TIMER CARD
#         # -------------------------
#         self.card_timer = FluentCard("Smart Mode Timer", "00:00:00")
#         self.card_timer.setMinimumHeight(150)
#         layout.addWidget(self.card_timer)

#         # -------------------------
#         # SECOND ROW
#         # -------------------------
#         row = QHBoxLayout()
#         row.setSpacing(20)

#         self.card_next_break = FluentCard("Next Break", "Calculating…")
#         self.card_meeting = FluentCard("Meeting Mode", "Off")

#         row.addWidget(self.card_next_break)
#         row.addWidget(self.card_meeting)

#         layout.addLayout(row)

#         # Expose meeting badge
#         self.meeting_badge = self.card_meeting.meeting_badge

#         # -------------------------
#         # START / STOP BUTTON
#         # -------------------------
#         self.btn_toggle = QPushButton("Start Monitoring")
#         self.btn_toggle.setObjectName("PrimaryButton")
#         self.btn_toggle.setFixedHeight(44)
#         self.btn_toggle.clicked.connect(self.toggle_monitoring)
#         layout.addWidget(self.btn_toggle)

#         # UI update timer
#         self.ui_timer = QTimer()
#         self.ui_timer.timeout.connect(self.update_ui)
#         self.ui_timer.start(500)

#     # -------------------------
#     # START / STOP
#     # -------------------------
#     def toggle_monitoring(self):
#         self.main.toggle_monitoring()
#         self.btn_toggle.setText("Stop Monitoring" if self.main.monitoring else "Start Monitoring")

#     # -------------------------
#     # UPDATE UI
#     # -------------------------
#     def update_ui(self):
#         if not self.main.monitoring:
#             return

#         # Only update when Smart Mode page is active
#         if self.main.pages.currentWidget() != self:
#             return

#         engine = self.main.hybrid_engine

#         # REAL TIME
#         real_seconds = int(engine.real_time)
#         self.card_timer.update_value(time.strftime("%H:%M:%S", time.gmtime(real_seconds)))

#         # ACTIVE TIME
#         active_seconds = int(engine.active_time)
#         self.card_timer.title_label.setText(
#             f"Smart Mode Timer  •  Active: {time.strftime('%H:%M:%S', time.gmtime(active_seconds))}"
#         )

#         # NEXT BREAK (simple estimate)
#         remaining = engine.config.base_real_time * engine.real_factor - engine.real_time
#         if remaining > 0:
#             self.card_next_break.update_value(f"{int(remaining)}s")
#         else:
#             self.card_next_break.update_value("Soon")

#         # MEETING MODE
#         signals = self.main.signals.to_dict()
#         meeting_active = (
#             signals.get("window_category") == "meeting"
#             or signals.get("webcam_active") is True
#         )
#         self.card_meeting.update_value("On" if meeting_active else "Off")
























# 5
# ungrade

# pages/smart_mode_page.py

# import time
# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame, QPushButton
# )
# from PySide6.QtCore import Qt, QTimer

# from ui.theme import AppColors, AppFonts, AppMetrics
# from ui.animations import FadeInAnimator, SlideInAnimator, SparklineAnimator, ValueAnimator, PulseAnimator

# import pyqtgraph as pg


# # ---------------------------------------------------------
# # PREMIUM CARD COMPONENT
# # ---------------------------------------------------------
# class SmartCard(QFrame):
#     def __init__(self, title, accent_color):
#         super().__init__()
#         self.setObjectName("SmartModeCard")
#         self.accent_color = accent_color

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(AppMetrics.CARD_PADDING, AppMetrics.CARD_PADDING, AppMetrics.CARD_PADDING, AppMetrics.CARD_PADDING)
#         layout.setSpacing(AppMetrics.GAP_SMALL)

#         # Accent bar
#         self.accent = QFrame()
#         self.accent.setFixedHeight(4)
#         self.accent.setStyleSheet(f"background-color: {accent_color}; border-radius: 2px;")
#         layout.addWidget(self.accent)

#         # Title
#         self.title_label = QLabel(title)
#         self.title_label.setFont(AppFonts.card_title())
#         layout.addWidget(self.title_label)

#         # Value
#         self.value_label = QLabel("—")
#         self.value_label.setFont(AppFonts.primary_value())
#         layout.addWidget(self.value_label)

#         # Sparkline
#         self.spark = pg.PlotWidget()
#         self.spark.setFixedHeight(60)
#         self.spark.setBackground(None)
#         self.spark.hideAxis('left')
#         self.spark.hideAxis('bottom')
#         layout.addWidget(self.spark)

#         layout.addStretch()

#     def update_value(self, text):
#         self.value_label.setText(text)


# # ---------------------------------------------------------
# # SMART MODE PAGE
# # ---------------------------------------------------------
# class SmartModePage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main

#         # Trend buffers
#         self.fatigue_trend = []
#         self.interval_trend = []
#         self.behavior_trend = []

#         self.session_start = None
#         self.monitoring = False

#         # Layout
#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # ---------------------------------------------------------
#         # TIMER CARD
#         # ---------------------------------------------------------
#         self.card_timer = SmartCard("Smart Mode Timer", AppColors.BREAK)
#         self.card_timer.setMinimumHeight(AppMetrics.CARD_HEIGHT)
#         layout.addWidget(self.card_timer)

#         # ---------------------------------------------------------
#         # TWO-COLUMN ROW
#         # ---------------------------------------------------------
#         row = QHBoxLayout()
#         row.setSpacing(20)

#         self.card_behavior = SmartCard("Behavior", AppColors.BEHAVIOR)
#         self.card_fatigue = SmartCard("Fatigue", AppColors.FATIGUE)

#         row.addWidget(self.card_behavior)
#         row.addWidget(self.card_fatigue)

#         layout.addLayout(row)

#         # ---------------------------------------------------------
#         # SECOND ROW
#         # ---------------------------------------------------------
#         row2 = QHBoxLayout()
#         row2.setSpacing(20)

#         self.card_reason = SmartCard("Reason", AppColors.INSIGHT)
#         self.card_next_break = SmartCard("Next Break", AppColors.BREAK)

#         row2.addWidget(self.card_reason)
#         row2.addWidget(self.card_next_break)

#         layout.addLayout(row2)

#         # ---------------------------------------------------------
#         # SUPPRESSION CARD
#         # ---------------------------------------------------------
#         self.card_suppression = SmartCard("Suppression", AppColors.SUPPRESSION)
#         layout.addWidget(self.card_suppression)

#         # ---------------------------------------------------------
#         # SUMMARY CARD
#         # ---------------------------------------------------------
#         self.card_summary = SmartCard("Summary", AppColors.INSIGHT)
#         self.card_summary.setMinimumHeight(AppMetrics.CARD_HEIGHT)
#         layout.addWidget(self.card_summary)

#         # ---------------------------------------------------------
#         # START / STOP BUTTON
#         # ---------------------------------------------------------
#         self.btn_toggle = QPushButton("Start Smart Mode")
#         self.btn_toggle.setFixedHeight(48)
#         self.btn_toggle.setStyleSheet("background-color: #30D158; color: white; border-radius: 8px;")
#         self.btn_toggle.clicked.connect(self.toggle_monitoring)
#         layout.addWidget(self.btn_toggle)

#         # UI update timer
#         self.ui_timer = QTimer()
#         self.ui_timer.timeout.connect(self.update_ui)
#         self.ui_timer.start(500)

#     # ---------------------------------------------------------
#     # START / STOP
#     # ---------------------------------------------------------
#     def toggle_monitoring(self):
#         if not self.monitoring:
#             self.monitoring = True
#             self.session_start = time.time()
#             self.btn_toggle.setText("Stop Smart Mode")
#             self.btn_toggle.setStyleSheet("background-color: #FF453A; color: white; border-radius: 8px;")
#         else:
#             self.monitoring = False
#             self.session_start = None
#             self.btn_toggle.setText("Start Smart Mode")
#             self.btn_toggle.setStyleSheet("background-color: #30D158; color: white; border-radius: 8px;")

#     # ---------------------------------------------------------
#     # UPDATE UI
#     # ---------------------------------------------------------
#     def update_ui(self):
#         if not self.monitoring:
#             return

#         if self.main.pages.currentWidget() != self:
#             return

#         engine = self.main.smart_engine
#         signals = self.main.signals.to_dict()

#         result = engine.should_trigger_break(signals)

#         # ---------------------------------------------------------
#         # TIMER
#         # ---------------------------------------------------------
#         elapsed = int(time.time() - self.session_start)
#         self.card_timer.update_value(time.strftime("%H:%M:%S", time.gmtime(elapsed)))

#         # ---------------------------------------------------------
#         # BEHAVIOR
#         # ---------------------------------------------------------
#         behavior = result["behavior"]
#         self.card_behavior.update_value(behavior)

#         # ---------------------------------------------------------
#         # FATIGUE
#         # ---------------------------------------------------------
#         fatigue = int(result["fatigue_score"])
#         ValueAnimator(
#             start_value=self.card_fatigue.value_label.text().replace("%", "") if self.card_fatigue.value_label.text() != "—" else 0,
#             end_value=fatigue,
#             duration=500,
#             callback=lambda v: self.card_fatigue.update_value(f"{int(v)}%")
#         ).start()

#         # ---------------------------------------------------------
#         # REASON
#         # ---------------------------------------------------------
#         self.card_reason.update_value(result["reason"])

#         # ---------------------------------------------------------
#         # NEXT BREAK
#         # ---------------------------------------------------------
#         interval = result["interval_used"]
#         next_break = int(interval - (time.time() - engine.session_start))
#         next_break = max(0, next_break)
#         self.card_next_break.update_value(f"{next_break}s")

#         # ---------------------------------------------------------
#         # SUPPRESSION
#         # ---------------------------------------------------------
#         if "Suppressed" in result["reason"]:
#             self.card_suppression.update_value("Active")
#             PulseAnimator(self.card_suppression).start()
#         else:
#             self.card_suppression.update_value("None")

#         # ---------------------------------------------------------
#         # SUMMARY
#         # ---------------------------------------------------------
#         summary = (
#             f"Behavior: {behavior}\n"
#             f"Fatigue: {fatigue}%\n"
#             f"Reason: {result['reason']}\n"
#             f"Message: {result['message']}\n"
#             f"Next Break: {next_break}s\n"
#             f"Trigger: {result['trigger']}"
#         )
#         self.card_summary.update_value(summary)

#         # ---------------------------------------------------------
#         # ANIMATIONS
#         # ---------------------------------------------------------
#         FadeInAnimator(self.card_behavior).start()
#         FadeInAnimator(self.card_fatigue).start()
#         FadeInAnimator(self.card_reason).start()
#         FadeInAnimator(self.card_next_break).start()
#         FadeInAnimator(self.card_suppression).start()
#         FadeInAnimator(self.card_summary).start()

#         SlideInAnimator(self.card_behavior.accent).start()
#         SlideInAnimator(self.card_fatigue.accent).start()
#         SlideInAnimator(self.card_reason.accent).start()
#         SlideInAnimator(self.card_next_break.accent).start()
#         SlideInAnimator(self.card_suppression.accent).start()
#         SlideInAnimator(self.card_summary.accent).start()

#         # ---------------------------------------------------------
#         # SPARKLINES
#         # ---------------------------------------------------------
#         self.fatigue_trend.append(fatigue)
#         self.fatigue_trend = self.fatigue_trend[-30:]

#         SparklineAnimator(self.card_fatigue.spark, AppColors.FATIGUE).animate(self.fatigue_trend)

#         self.interval_trend.append(next_break)
#         self.interval_trend = self.interval_trend[-30:]

#         SparklineAnimator(self.card_next_break.spark, AppColors.BREAK).animate(self.interval_trend)











# # ui/pages/smart_mode.py
# import time
# from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton

# from ui.pages.shared.fluent_card import FluentCard
# from ui.theme import AppColors
# from ui.animations import (
#     FadeInAnimator, SlideInAnimator, SparklineAnimator,
#     ValueAnimator, PulseAnimator
# )


# class SmartModePage(QWidget):
#     def __init__(self, main):
#         super().__init__()
#         self.main = main
#         self.setObjectName("SmartModePage")

#         self.behavior_trend = []
#         self.fatigue_trend = []
#         self.interval_trend = []

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # TIMER
#         self.card_timer = FluentCard("Smart Mode Timer", AppColors.BREAK, has_spark=False)
#         layout.addWidget(self.card_timer)

#         # ROW 1
#         row1 = QHBoxLayout()
#         row1.setSpacing(20)
#         self.card_behavior = FluentCard("Behavior", AppColors.BEHAVIOR)
#         self.card_fatigue = FluentCard("Fatigue", AppColors.FATIGUE)
#         row1.addWidget(self.card_behavior)
#         row1.addWidget(self.card_fatigue)
#         layout.addLayout(row1)

#         # ROW 2
#         row2 = QHBoxLayout()
#         row2.setSpacing(20)
#         self.card_reason = FluentCard("Reason", AppColors.INSIGHT, has_spark=False)
#         self.card_next_break = FluentCard("Next Break", AppColors.BREAK)
#         row2.addWidget(self.card_reason)
#         row2.addWidget(self.card_next_break)
#         layout.addLayout(row2)

#         # SUPPRESSION
#         self.card_suppression = FluentCard("Suppression", AppColors.SUPPRESSION, has_spark=False)
#         layout.addWidget(self.card_suppression)

#         # SUMMARY
#         self.card_summary = FluentCard("Summary", AppColors.INSIGHT, has_spark=False)
#         layout.addWidget(self.card_summary)

#         # BUTTON
#         self.btn_toggle = QPushButton("Start Smart Mode")
#         self.btn_toggle.setObjectName("PrimaryButton")
#         self.btn_toggle.setFixedHeight(44)
#         self.btn_toggle.clicked.connect(self.on_toggle_clicked)
#         layout.addWidget(self.btn_toggle)

#     def on_toggle_clicked(self):
#         self.main.show_smart()
#         self.main.toggle_monitoring()
#         self.btn_toggle.setText("Stop Smart Mode" if self.main.monitoring else "Start Smart Mode")

#     def update_smart_status(self, behavior, fatigue, reason, trigger, next_break_seconds):
#         # TIMER
#         elapsed = 0
#         engine = self.main.hybrid_engine
#         if engine.session_start and self.main.monitoring and self.main.active_monitoring_mode == "Smart Mode":
#             elapsed = int(time.time() - engine.session_start)
#         self.card_timer.update_value(time.strftime("%H:%M:%S", time.gmtime(elapsed)))

#         # BEHAVIOR
#         self.card_behavior.update_value(behavior)
#         self.behavior_trend.append(len(self.behavior_trend) % 5)
#         self.behavior_trend = self.behavior_trend[-30:]
#         SparklineAnimator(self.card_behavior.spark, AppColors.BEHAVIOR).animate(self.behavior_trend)

#         # FATIGUE
#         ValueAnimator(
#             start_value=self._fatigue_value(),
#             end_value=int(fatigue),
#             duration=500,
#             callback=lambda v: self.card_fatigue.update_value(f"{int(v)}%"),
#         ).start()

#         self.fatigue_trend.append(int(fatigue))
#         self.fatigue_trend = self.fatigue_trend[-30:]
#         SparklineAnimator(self.card_fatigue.spark, AppColors.FATIGUE).animate(self.fatigue_trend)

#         # REASON
#         self.card_reason.update_value(reason)

#         # NEXT BREAK
#         nb = max(0, int(next_break_seconds))
#         self.card_next_break.update_value(f"{nb}s" if nb else "—")
#         self.interval_trend.append(nb)
#         self.interval_trend = self.interval_trend[-30:]
#         SparklineAnimator(self.card_next_break.spark, AppColors.BREAK).animate(self.interval_trend)

#         # SUPPRESSION
#         if "suppressed" in reason.lower():
#             self.card_suppression.update_value("Active")
#             PulseAnimator(self.card_suppression).start()
#         else:
#             self.card_suppression.update_value("None")

#         # SUMMARY
#         summary = (
#             f"Behavior: {behavior}\n"
#             f"Fatigue: {int(fatigue)}%\n"
#             f"Reason: {reason}\n"
#             f"Next Break: {nb}s\n"
#             f"Trigger: {'Yes' if trigger else 'No'}"
#         )
#         self.card_summary.update_value(summary)

#         # ANIMATIONS
#         for card in [
#             self.card_timer, self.card_behavior, self.card_fatigue,
#             self.card_reason, self.card_next_break, self.card_suppression,
#             self.card_summary
#         ]:
#             FadeInAnimator(card).start()
#             SlideInAnimator(card.accent).start()

#     def _fatigue_value(self):
#         text = self.card_fatigue.value_label.text().replace("%", "").strip()
#         return int(text) if text.isdigit() else 0

















# ui/pages/smart_mode.py

import time
from PySide6.QtWidgets import QWidget, QVBoxLayout, QHBoxLayout, QPushButton
from PySide6.QtCore import Qt

from ui.pages.shared.fluent_card import FluentCard
from ui.widgets.fluent_blur import FluentBlur
from ui.core.theme import AppColors
from ui.animations import (
    FadeInAnimator, SlideInAnimator, SparklineAnimator,
    ValueAnimator, PulseAnimator
)


class SmartModePage(QWidget):
    def __init__(self, main):
        super().__init__()
        self.main = main
        self.setObjectName("SmartModePage")

        self.behavior_trend = []
        self.fatigue_trend = []
        self.interval_trend = []

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(0)

        # TIMER
        self.card_timer = FluentCard("Smart Mode Timer", AppColors.BREAK, has_spark=False)
        layout.addWidget(self._wrap_blur(self.card_timer))

        # ROW 1 — Behavior + Fatigue (260px each)
        row1 = QHBoxLayout()
        row1.setSpacing(20)

        self.card_behavior = FluentCard("Behavior", AppColors.BEHAVIOR)
        self.card_fatigue = FluentCard("Fatigue", AppColors.FATIGUE)

        self.card_behavior.setMinimumHeight(260)
        self.card_fatigue.setMinimumHeight(260)

        row1.addWidget(self._wrap_blur(self.card_behavior))
        row1.addWidget(self._wrap_blur(self.card_fatigue))
        layout.addLayout(row1)

        # ROW 2 — Reason (300px) + Next Break (180px)
        row2 = QHBoxLayout()
        row2.setSpacing(20)

        self.card_reason = FluentCard("Reason", AppColors.INSIGHT, has_spark=False)
        self.card_next_break = FluentCard("Next Break", AppColors.BREAK)

        self.card_reason.setMinimumHeight(300)
        self.card_next_break.setMinimumHeight(180)

        row2.addWidget(self._wrap_blur(self.card_reason))
        row2.addWidget(self._wrap_blur(self.card_next_break))
        layout.addLayout(row2)

        # SUPPRESSION (260px)
        self.card_suppression = FluentCard("Suppression", AppColors.SUPPRESSION, has_spark=False)
        self.card_suppression.setMinimumHeight(260)
        layout.addWidget(self._wrap_blur(self.card_suppression))

        # SUMMARY (300px)
        self.card_summary = FluentCard("Summary", AppColors.INSIGHT, has_spark=False)
        self.card_summary.setMinimumHeight(300)
        layout.addWidget(self._wrap_blur(self.card_summary))

        # Stretch ensures Summary can expand without hitting the button
        layout.addStretch()

        # BUTTON — Left aligned, correct PySide6 signature
        self.btn_toggle = QPushButton("Start Smart Mode")
        self.btn_toggle.setObjectName("PrimaryButton")
        self.btn_toggle.setFixedHeight(44)
        self.btn_toggle.setContentsMargins(0, 10, 0, 0)
        self.btn_toggle.clicked.connect(self.on_toggle_clicked)
        layout.addWidget(self.btn_toggle, 0, Qt.AlignLeft)

    def _wrap_blur(self, card: FluentCard) -> FluentBlur:
        blur = FluentBlur(radius=25, opacity=0.30)
        blur.layout.addWidget(card)
        return blur

    def on_toggle_clicked(self):
        self.main.show_smart()
        self.main.toggle_monitoring()
        self.btn_toggle.setText("Stop Smart Mode" if self.main.monitoring else "Start Smart Mode")

    def update_smart_status(self, behavior, fatigue, reason, trigger, next_break_seconds):
        # TIMER
        elapsed = 0
        engine = self.main.hybrid_engine
        if engine.session_start and self.main.monitoring and self.main.active_monitoring_mode == "Smart Mode":
            elapsed = int(time.time() - engine.session_start)
        self.card_timer.update_value(time.strftime("%H:%M:%S", time.gmtime(elapsed)))

        # BEHAVIOR
        self.card_behavior.update_value(behavior)
        self.behavior_trend.append(len(self.behavior_trend) % 5)
        self.behavior_trend = self.behavior_trend[-30:]
        SparklineAnimator(self.card_behavior.spark, AppColors.BEHAVIOR).animate(self.behavior_trend)

        # FATIGUE
        ValueAnimator(
            start_value=self._fatigue_value(),
            end_value=int(fatigue),
            duration=500,
            callback=lambda v: self.card_fatigue.update_value(f"{int(v)}%"),
        ).start()

        self.fatigue_trend.append(int(fatigue))
        self.fatigue_trend = self.fatigue_trend[-30:]
        SparklineAnimator(self.card_fatigue.spark, AppColors.FATIGUE).animate(self.fatigue_trend)

        # REASON
        self.card_reason.update_value(reason)

        # NEXT BREAK
        nb = max(0, int(next_break_seconds))
        self.card_next_break.update_value(f"{nb}s" if nb else "—")
        self.interval_trend.append(nb)
        self.interval_trend = self.interval_trend[-30:]
        SparklineAnimator(self.card_next_break.spark, AppColors.BREAK).animate(self.interval_trend)

        # SUPPRESSION
        if "suppressed" in reason.lower():
            self.card_suppression.update_value("Active")
            PulseAnimator(self.card_suppression).start()
        else:
            self.card_suppression.update_value("None")

        # SUMMARY
        summary = (
            f"Behavior: {behavior}\n"
            f"Fatigue: {int(fatigue)}%\n"
            f"Reason: {reason}\n"
            f"Next Break: {nb}s\n"
            f"Trigger: {'Yes' if trigger else 'No'}"
        )
        self.card_summary.update_value(summary)

        # ANIMATIONS
        for card in [
            self.card_timer, self.card_behavior, self.card_fatigue,
            self.card_reason, self.card_next_break, self.card_suppression,
            self.card_summary
        ]:
            FadeInAnimator(card).start()
            SlideInAnimator(card.accent).start()

    def _fatigue_value(self):
        text = self.card_fatigue.value_label.text().replace("%", "").strip()
        return int(text) if text.isdigit() else 0

