# # behavior_classifier.py

# class BehaviorClassifier:
#     """
#     Classifies current behavior state based on signals.
#     States: deep_work, meeting, reading, watching, idle, multitasking, unknown.
#     """

#     def classify(self, signals: dict) -> str:
#         """
#         Input: signals from SignalCollector.to_dict()
#         Output: behavior label (string)
#         """
#         idle = signals.get("idle_seconds", 0)
#         window_cat = signals.get("window_category", "other")
#         fullscreen = signals.get("fullscreen", False)
#         webcam = signals.get("webcam_active", False)
#         mic = signals.get("microphone_active", False)
#         key_rate = signals.get("keypress_rate", 0)
#         mouse_rate = signals.get("mouse_rate", 0)
#         scroll_rate = signals.get("scroll_rate", 0)
#         window_switches = signals.get("window_switches", 0)
#         typing_burst_rate = signals.get("typing_burst_rate", 0)
#         micro_pause_rate = signals.get("micro_pause_rate", 0)

#         # 1. Idle
#         if idle > 60:
#             return "idle"

#         # 2. Meeting
#         if window_cat == "meeting" or (webcam and mic and fullscreen and key_rate < 5):
#             return "meeting"

#         # 3. Watching (video / lecture)
#         if window_cat == "video" and fullscreen and key_rate < 5 and mouse_rate < 5:
#             return "watching"

#         # 4. Reading (browser / doc with scroll)
#         if window_cat in ["browser", "office"] and scroll_rate > 5 and key_rate < 10:
#             return "reading"

#         # 5. Deep work (coding / writing)
#         if window_cat in ["coding", "office"] and typing_burst_rate > 10 and window_switches < 5:
#             return "deep_work"

#         # 6. Multitasking / context switching
#         if window_switches > 15:
#             return "multitasking"

#         # 7. Light activity / default
#         if micro_pause_rate > 10:
#             return "fatigued_activity"

#         return "unknown"









# class BehaviorClassifier:
#     def classify(self, signals):
#         window = signals.get("window_category")
#         typing = signals.get("keypress_rate", 0)
#         mouse = signals.get("mouse_rate", 0)
#         scroll = signals.get("scroll_rate", 0)
#         idle = signals.get("idle_seconds", 0)
#         brightness = signals.get("screen_brightness", 50)
#         webcam = signals.get("webcam_active", False)

#         # -------------------------
#         # AWAY
#         # -------------------------
#         if idle > 120:
#             return "Away"

#         # -------------------------
#         # MEETING
#         # -------------------------
#         if webcam or window == "meeting":
#             return "Meeting"

#         # -------------------------
#         # READING
#         # -------------------------
#         if (
#             window in ["reading", "pdf", "document", "article", "research"]
#             and typing < 5
#             and mouse < 10
#             and scroll > 0
#         ):
#             return "Reading"

#         # -------------------------
#         # WATCHING
#         # -------------------------
#         if window == "video" and typing < 5:
#             return "Watching"

#         # -------------------------
#         # CODING / WRITING
#         # -------------------------
#         if typing > 40:
#             if window == "coding":
#                 return "Coding"
#             return "Writing"

#         # -------------------------
#         # MULTITASKING
#         # -------------------------
#         if mouse > 40 and typing > 20:
#             return "Multitasking"

#         # -------------------------
#         # LIGHT BROWSING
#         # -------------------------
#         if window == "browser" and typing < 10:
#             return "Light Browsing"

#         # -------------------------
#         # HEAVY BROWSING
#         # -------------------------
#         if window == "browser" and typing >= 10:
#             return "Heavy Browsing"

#         # -------------------------
#         # DEEP WORK
#         # -------------------------
#         if typing > 20 and mouse < 20:
#             return "Deep Work"

#         # -------------------------
#         # EYE STRAIN RISK
#         # -------------------------
#         if brightness and brightness > 80 and idle < 60:
#             return "Eye Strain Risk"

#         # -------------------------
#         # POSTURE RISK
#         # -------------------------
#         if idle > 45 and typing > 20:
#             return "Posture Risk"

#         # -------------------------
#         # FATIGUED ACTIVITY
#         # -------------------------
#         if typing < 5 and mouse < 5 and idle < 60:
#             return "Fatigued Activity"

#         # -------------------------
#         # IDLE
#         # -------------------------
#         if typing == 0 and mouse == 0:
#             return "Idle"

#         return "Unknown"











# # Cleaned up version without underscores in UI labels:
# from dataclasses import dataclass
# from typing import Dict, Callable, List


# # ==========================================================
# # Configuration (Production Tunable Thresholds)
# # ==========================================================

# DEFAULT_THRESHOLDS = {
#     "away_idle": 120,
#     "idle": 60,
#     "low_typing": 5,
#     "medium_typing": 20,
#     "high_typing": 40,
#     "low_mouse": 10,
#     "high_mouse": 40,
#     "brightness_high": 80,
# }


# # ==========================================================
# # Classification Result Object
# # ==========================================================

# @dataclass
# class BehaviorResult:
#     category: str
#     confidence: float  # 0.0 – 1.0
#     signals: Dict


# # ==========================================================
# # Behavior Classifier
# # ==========================================================

# class BehaviorClassifier:
#     """
#     Production-grade behavioral classifier.

#     - Deterministic rule engine
#     - Priority-based evaluation
#     - Confidence scoring
#     - Configurable thresholds
#     - Clean fallback handling
#     """

#     def __init__(self, thresholds: Dict = None):
#         self.t = thresholds or DEFAULT_THRESHOLDS

#         # Rule priority (top = highest importance)
#         self.rules: List[Callable[[Dict], BehaviorResult | None]] = [
#             self._rule_away,
#             self._rule_meeting,
#             self._rule_reading,
#             self._rule_watching,
#             self._rule_coding_writing,
#             self._rule_multitasking,
#             self._rule_heavy_browsing,
#             self._rule_light_browsing,
#             self._rule_deep_work,
#             self._rule_eye_strain_risk,
#             self._rule_posture_risk,
#             self._rule_fatigued_activity,
#             self._rule_idle,
#         ]

#     # ------------------------------------------------------
#     # Public API
#     # ------------------------------------------------------

#     def classify(self, signals: Dict) -> BehaviorResult:
#         signals = self._normalize(signals)

#         for rule in self.rules:
#             result = rule(signals)
#             if result:
#                 return result

#         # Professional fallback (no "Unknown")
#         return BehaviorResult(
#             category="General Activity",
#             confidence=0.3,
#             signals=signals
#         )

#     # ------------------------------------------------------
#     # Normalization Layer
#     # ------------------------------------------------------

#     def _normalize(self, s: Dict) -> Dict:
#         return {
#             "window": s.get("window_category", "other"),
#             "typing": float(s.get("keypress_rate", 0)),
#             "mouse": float(s.get("mouse_rate", 0)),
#             "scroll": float(s.get("scroll_rate", 0)),
#             "idle": float(s.get("idle_seconds", 0)),
#             "brightness": float(s.get("screen_brightness", 50)),
#             "webcam": bool(s.get("webcam_active", False)),
#         }

#     # ======================================================
#     # RULE DEFINITIONS
#     # ======================================================

#     def _rule_away(self, s):
#         if s["idle"] > self.t["away_idle"]:
#             return BehaviorResult("Away", 0.95, s)

#     def _rule_meeting(self, s):
#         if s["webcam"] or s["window"] == "meeting":
#             return BehaviorResult("Meeting", 0.9, s)

#     def _rule_reading(self, s):
#         if (
#             s["window"] in ["reading", "pdf", "document", "article", "research"]
#             and s["typing"] < self.t["low_typing"]
#             and s["scroll"] > 0
#         ):
#             return BehaviorResult("Reading", 0.85, s)

#     def _rule_watching(self, s):
#         if s["window"] == "video" and s["typing"] < self.t["low_typing"]:
#             return BehaviorResult("Watching", 0.85, s)

#     def _rule_coding_writing(self, s):
#         if s["typing"] > self.t["high_typing"]:
#             if s["window"] == "coding":
#                 return BehaviorResult("Coding", 0.9, s)
#             return BehaviorResult("Writing", 0.85, s)

#     def _rule_multitasking(self, s):
#         if (
#             s["mouse"] > self.t["high_mouse"]
#             and s["typing"] > self.t["medium_typing"]
#         ):
#             return BehaviorResult("Multitasking", 0.8, s)

#     def _rule_heavy_browsing(self, s):
#         if s["window"] == "browser" and s["typing"] >= self.t["medium_typing"]:
#             return BehaviorResult("Heavy Browsing", 0.75, s)

#     def _rule_light_browsing(self, s):
#         if s["window"] == "browser" and s["typing"] < self.t["medium_typing"]:
#             return BehaviorResult("Light Browsing", 0.7, s)

#     def _rule_deep_work(self, s):
#         if (
#             s["typing"] > self.t["medium_typing"]
#             and s["mouse"] < self.t["medium_typing"]
#         ):
#             return BehaviorResult("Deep Work", 0.8, s)

#     def _rule_eye_strain_risk(self, s):
#         if s["brightness"] > self.t["brightness_high"] and s["idle"] < self.t["idle"]:
#             return BehaviorResult("Eye Strain Risk", 0.75, s)

#     def _rule_posture_risk(self, s):
#         if s["idle"] > 45 and s["typing"] > self.t["medium_typing"]:
#             return BehaviorResult("Posture Risk", 0.7, s)

#     def _rule_fatigued_activity(self, s):
#         if (
#             s["typing"] < self.t["low_typing"]
#             and s["mouse"] < self.t["low_mouse"]
#             and s["idle"] < self.t["idle"]
#         ):
#             return BehaviorResult("Low Engagement Activity", 0.6, s)

#     def _rule_idle(self, s):
#         if s["typing"] == 0 and s["mouse"] == 0:
#             return BehaviorResult("Idle", 0.6, s)










# # Upgraded with light and heavy browsing

from dataclasses import dataclass
from typing import Dict, Callable, List


DEFAULT_THRESHOLDS = {
    "away_idle": 120,
    "idle": 60,
    "low_typing": 5,
    "medium_typing": 20,
    "high_typing": 40,
    "low_mouse": 10,
    "high_mouse": 40,
    "brightness_high": 80,
}


@dataclass
class BehaviorResult:
    category: str
    confidence: float
    signals: Dict


class BehaviorClassifier:
    """
    Production-grade behavioral classifier.
    Priority-ordered, deterministic, and aligned with AI engine + message generator.
    """

    def __init__(self, thresholds: Dict = None):
        self.t = thresholds or DEFAULT_THRESHOLDS

        # Priority order:
        self.rules: List[Callable[[Dict], BehaviorResult | None]] = [
            self._rule_away,
            self._rule_meeting,
            self._rule_eye_strain_risk,
            self._rule_reading,
            self._rule_watching,
            self._rule_coding_writing,
            self._rule_deep_work,
            self._rule_multitasking,
            self._rule_heavy_browsing,
            self._rule_light_browsing,
            self._rule_posture_risk,
            self._rule_fatigued_activity,
            self._rule_idle,
        ]

    def classify(self, signals: Dict) -> BehaviorResult:
        signals = self._normalize(signals)

        for rule in self.rules:
            result = rule(signals)
            if result:
                return result

        return BehaviorResult("General Activity", 0.3, signals)

    def _normalize(self, s: Dict) -> Dict:
        return {
            "window": s.get("window_category", "other"),
            "typing": float(s.get("keypress_rate", 0)),
            "mouse": float(s.get("mouse_rate", 0)),
            "scroll": float(s.get("scroll_rate", 0)),
            "idle": float(s.get("idle_seconds", 0)),
            "brightness": float(s.get("screen_brightness", 50)),
            "webcam": bool(s.get("webcam_active", False)),
        }

    # RULES ---------------------------------------------------

    def _rule_away(self, s):
        if s["idle"] > self.t["away_idle"]:
            return BehaviorResult("Away", 0.95, s)

    def _rule_meeting(self, s):
        if s["webcam"] or s["window"] == "meeting":
            return BehaviorResult("Meeting", 0.9, s)

    def _rule_eye_strain_risk(self, s):
        if s["brightness"] > self.t["brightness_high"] and s["idle"] < self.t["idle"]:
            return BehaviorResult("Eye Strain Risk", 0.85, s)

    def _rule_reading(self, s):
        if (
            s["window"] in ["reading", "pdf", "document", "article", "research"]
            and s["typing"] < self.t["low_typing"]
            and s["scroll"] > 0
        ):
            return BehaviorResult("Reading", 0.85, s)

    def _rule_watching(self, s):
        if s["window"] == "video" and s["typing"] < self.t["low_typing"]:
            return BehaviorResult("Watching", 0.85, s)

    def _rule_coding_writing(self, s):
        if s["typing"] > self.t["high_typing"]:
            if s["window"] == "coding":
                return BehaviorResult("Coding", 0.9, s)
            return BehaviorResult("Writing", 0.85, s)

    def _rule_deep_work(self, s):
        if (
            s["typing"] > self.t["medium_typing"]
            and s["mouse"] < self.t["medium_typing"]
        ):
            return BehaviorResult("Deep Work", 0.8, s)

    def _rule_multitasking(self, s):
        if (
            s["mouse"] > self.t["high_mouse"]
            and s["typing"] > self.t["medium_typing"]
        ):
            return BehaviorResult("Multitasking", 0.8, s)

    def _rule_heavy_browsing(self, s):
        if s["window"] == "browser" and s["typing"] >= self.t["medium_typing"]:
            return BehaviorResult("Heavy Browsing", 0.75, s)

    def _rule_light_browsing(self, s):
        if s["window"] == "browser" and s["typing"] < self.t["medium_typing"]:
            return BehaviorResult("Light Browsing", 0.7, s)

    def _rule_posture_risk(self, s):
        if s["idle"] > 45 and s["typing"] > self.t["medium_typing"]:
            return BehaviorResult("Posture Risk", 0.7, s)

    def _rule_fatigued_activity(self, s):
        if (
            s["typing"] < self.t["low_typing"]
            and s["mouse"] < self.t["low_mouse"]
            and s["idle"] < self.t["idle"]
        ):
            return BehaviorResult("Fatigued Activity", 0.6, s)

    def _rule_idle(self, s):
        if s["typing"] == 0 and s["mouse"] == 0:
            return BehaviorResult("Idle", 0.6, s)
