class WeeklyReportGenerator:
    def generate(self, summary):
        if summary is None:
            return "No activity data available for this week."

        total = summary["total_focus"]
        deep_work = summary["deep_work"]
        deep_reading = summary["deep_reading"]
        focused_interaction = summary["focused_interaction"]
        breaks = summary["breaks"]
        avg_fatigue = summary["avg_fatigue"]
        insights = summary["insights"]

        # Build insights text
        insights_text = "\n".join(f"• {i}" for i in insights)

        return (
            f"Here’s your weekly wellbeing summary:\n\n"
            f"• Total focused minutes: **{total}**\n"
            f"• Deep work minutes: **{deep_work}**\n"
            f"• Deep reading minutes: **{deep_reading}**\n"
            f"• Focused interaction minutes: **{focused_interaction}**\n"
            f"• Breaks taken: **{breaks}**\n"
            f"• Average fatigue level: **{avg_fatigue:.1f} / 100**\n\n"
            f"Weekly Insights:\n{insights_text}\n\n"
            f"Keep building healthy habits — small improvements add up."
        )
