from PySide6.QtWidgets import QWidget
from PySide6.QtCore import QSize
from ui.pages.shared.fluent_card import FluentCard
from ui.animations import SparklineAnimator
from ui.core.card_registry import CardRegistry

DEFAULT_CARD_WIDTH = 320
LAPTOP_FULL_WIDTH = 680


class BehaviorCard(FluentCard):
    def __init__(self, height: int | None = None, fullWidthOnLaptop: bool = False, parent: QWidget | None = None):
        super().__init__(
            title="Behavior patterns",
            accent_color="#0A84FF",  # blue
            has_spark=True,
        )

        # ✅ REGISTER, don’t unregister
        CardRegistry.register(self)

        self.fullWidthOnLaptop = fullWidthOnLaptop

        if height is not None:
            self.setMinimumHeight(height)

        # Required so text wraps and FlowLayout can place cards side-by-side
        self.setFixedWidth(DEFAULT_CARD_WIDTH)

        self.setParent(parent)
        self.setProperty("fullWidthOnLaptop", fullWidthOnLaptop)

        self.update_value(
            "Recent focus, context switching, and deep work behavior will appear here."
        )

        # Internal trend buffer for sparkline
        self.behavior_trend = []

    def sizeHint(self) -> QSize:
        if self.fullWidthOnLaptop:
            return QSize(LAPTOP_FULL_WIDTH, self.minimumHeight())
        return QSize(DEFAULT_CARD_WIDTH, self.minimumHeight())

    def closeEvent(self, event):
        # ✅ Proper unregister on close
        CardRegistry.unregister(self)
        super().closeEvent(event)

    # ============================================================
    # ENGINE UPDATE HOOK (Smart Mode + AI Mode)
    # ============================================================
    def update_from_engine(self, behavior, fatigue, reason, trigger, next_break_seconds, session_start, monitoring):
        """
        Called every second by SmartModePage and AIModePage.
        Updates the behavior label + sparkline trend.
        """

        if behavior:
            self.update_value(str(behavior))

        behavior_map = {
            "Idle": 0,
            "Browsing": 1,
            "Focused": 2,
            "Deep Work": 3,
            "Distracted": 1,
            "Context Switching": 2,
        }

        numeric = behavior_map.get(str(behavior), 1)
        self.behavior_trend.append(numeric)
        self.behavior_trend = self.behavior_trend[-30:]

        if self.spark:
            SparklineAnimator(self.spark, "#0A84FF").animate(self.behavior_trend)
