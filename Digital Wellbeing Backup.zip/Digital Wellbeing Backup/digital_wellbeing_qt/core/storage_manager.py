# # core/storage_manager.py

# import os
# import sqlite3
# import json
# import time
# from datetime import datetime, date
# from pathlib import Path


# class StorageManager:
#     """
#     Premium local storage engine (SQLite)
#     - Behavior timeline
#     - Break events
#     - Daily summaries
#     - Personalization
#     - Settings
#     """

#     def __init__(self):
#         self.db_path = self._get_db_path()
#         self._ensure_database()

#     # ---------------------------------------------------------
#     # PATHS
#     # ---------------------------------------------------------
#     def _get_db_path(self):
#         appdata = Path(os.getenv("APPDATA"))
#         folder = appdata / "YourApp"
#         folder.mkdir(exist_ok=True)
#         return folder / "user_data.db"

#     # ---------------------------------------------------------
#     # DATABASE INIT
#     # ---------------------------------------------------------
#     def _ensure_database(self):
#         conn = sqlite3.connect(self.db_path)
#         c = conn.cursor()

#         # Behavior timeline (1 row per minute)
#         c.execute("""
#             CREATE TABLE IF NOT EXISTS behavior_log (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 timestamp INTEGER,
#                 behavior TEXT,
#                 fatigue REAL,
#                 window TEXT,
#                 typing REAL,
#                 mouse REAL,
#                 scroll REAL
#             )
#         """)

#         # Break events
#         c.execute("""
#             CREATE TABLE IF NOT EXISTS break_events (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 timestamp INTEGER,
#                 reason TEXT,
#                 behavior TEXT,
#                 fatigue REAL,
#                 interval_used REAL
#             )
#         """)

#         # Daily summaries
#         c.execute("""
#             CREATE TABLE IF NOT EXISTS daily_summary (
#                 date TEXT PRIMARY KEY,
#                 total_focus REAL,
#                 deep_work REAL,
#                 deep_reading REAL,
#                 focused_interaction REAL,
#                 breaks INTEGER,
#                 avg_fatigue REAL
#             )
#         """)

#         # Personalization (AI Mode)
#         c.execute("""
#             CREATE TABLE IF NOT EXISTS personalization (
#                 key TEXT PRIMARY KEY,
#                 value REAL
#             )
#         """)

#         # Settings
#         c.execute("""
#             CREATE TABLE IF NOT EXISTS settings (
#                 key TEXT PRIMARY KEY,
#                 value TEXT
#             )
#         """)

#         conn.commit()
#         conn.close()

#     # ---------------------------------------------------------
#     # WRITE FUNCTIONS
#     # ---------------------------------------------------------
#     def log_behavior(self, behavior, fatigue, window, typing, mouse, scroll):
#         conn = sqlite3.connect(self.db_path)
#         c = conn.cursor()
#         c.execute("""
#             INSERT INTO behavior_log (timestamp, behavior, fatigue, window, typing, mouse, scroll)
#             VALUES (?, ?, ?, ?, ?, ?, ?)
#         """, (int(time.time()), behavior, fatigue, window, typing, mouse, scroll))
#         conn.commit()
#         conn.close()

#     def log_break(self, reason, behavior, fatigue, interval_used):
#         conn = sqlite3.connect(self.db_path)
#         c = conn.cursor()
#         c.execute("""
#             INSERT INTO break_events (timestamp, reason, behavior, fatigue, interval_used)
#             VALUES (?, ?, ?, ?, ?)
#         """, (int(time.time()), reason, behavior, fatigue, interval_used))
#         conn.commit()
#         conn.close()

#     def save_daily_summary(self, summary_dict):
#         conn = sqlite3.connect(self.db_path)
#         c = conn.cursor()
#         c.execute("""
#             INSERT OR REPLACE INTO daily_summary
#             (date, total_focus, deep_work, deep_reading, focused_interaction, breaks, avg_fatigue)
#             VALUES (?, ?, ?, ?, ?, ?, ?)
#         """, (
#             summary_dict["date"],
#             summary_dict["total_focus"],
#             summary_dict["deep_work"],
#             summary_dict["deep_reading"],
#             summary_dict["focused_interaction"],
#             summary_dict["breaks"],
#             summary_dict["avg_fatigue"]
#         ))
#         conn.commit()
#         conn.close()

#     def save_personalization(self, key, value):
#         conn = sqlite3.connect(self.db_path)
#         c = conn.cursor()
#         c.execute("""
#             INSERT OR REPLACE INTO personalization (key, value)
#             VALUES (?, ?)
#         """, (key, value))
#         conn.commit()
#         conn.close()

#     def save_setting(self, key, value):
#         conn = sqlite3.connect(self.db_path)
#         c = conn.cursor()
#         c.execute("""
#             INSERT OR REPLACE INTO settings (key, value)
#             VALUES (?, ?)
#         """, (key, json.dumps(value)))
#         conn.commit()
#         conn.close()

#     # ---------------------------------------------------------
#     # READ FUNCTIONS
#     # ---------------------------------------------------------
#     def get_daily_summary(self, date_str):
#         conn = sqlite3.connect(self.db_path)
#         c = conn.cursor()
#         c.execute("SELECT * FROM daily_summary WHERE date = ?", (date_str,))
#         row = c.fetchone()
#         conn.close()
#         return row

#     def get_personalization(self, key):
#         conn = sqlite3.connect(self.db_path)
#         c = conn.cursor()
#         c.execute("SELECT value FROM personalization WHERE key = ?", (key,))
#         row = c.fetchone()
#         conn.close()
#         return row[0] if row else None

#     def get_setting(self, key):
#         conn = sqlite3.connect(self.db_path)
#         c = conn.cursor()
#         c.execute("SELECT value FROM settings WHERE key = ?", (key,))
#         row = c.fetchone()
#         conn.close()
#         return json.loads(row[0]) if row else None

#     # ---------------------------------------------------------
#     # AGGREGATION HELPERS
#     # ---------------------------------------------------------
#     def get_behavior_for_day(self, date_str):
#         start_ts = int(datetime.strptime(date_str, "%Y-%m-%d").timestamp())
#         end_ts = start_ts + 86400

#         conn = sqlite3.connect(self.db_path)
#         c = conn.cursor()
#         c.execute("""
#             SELECT timestamp, behavior, fatigue
#             FROM behavior_log
#             WHERE timestamp BETWEEN ? AND ?
#         """, (start_ts, end_ts))
#         rows = c.fetchall()
#         conn.close()
#         return rows

#     def get_breaks_for_day(self, date_str):
#         start_ts = int(datetime.strptime(date_str, "%Y-%m-%d").timestamp())
#         end_ts = start_ts + 86400

#         conn = sqlite3.connect(self.db_path)
#         c = conn.cursor()
#         c.execute("""
#             SELECT timestamp, reason, behavior, fatigue
#             FROM break_events
#             WHERE timestamp BETWEEN ? AND ?
#         """, (start_ts, end_ts))
#         rows = c.fetchall()
#         conn.close()
#         return rows














# Upgraded wtih ISO
# core/storage_manager.py

import os
import sqlite3
import json
from datetime import datetime, date, timedelta
from pathlib import Path


class StorageManager:
    """
    Premium local storage engine (SQLite)
    - Behavior events (clean behavior_log)
    - Fatigue events (fatigue_log)
    - Break events (break_log)
    - Suppression events (suppression_log)
    - Raw input activity (input_activity_log: window, typing, mouse, scroll)
    - Daily summaries
    - Personalization
    - Settings
    """

    def __init__(self):
        self.db_path = self._get_db_path()
        self._ensure_database()

    # ---------------------------------------------------------
    # MIGRATION SYSTEM
    # ---------------------------------------------------------
    def _run_migrations(self):
        conn = self._connect()
        c = conn.cursor()

        # Ensure schema_version table exists
        c.execute("""
            CREATE TABLE IF NOT EXISTS schema_version (
                version INTEGER
            )
        """)

        # Read current version
        c.execute("SELECT version FROM schema_version")
        row = c.fetchone()
        current_version = row[0] if row else 0

        # -----------------------------
        # MIGRATION 1:
        # Add fatigue_at_event to behavior_log
        # -----------------------------
        if current_version < 1:
            c.execute("PRAGMA table_info(behavior_log)")
            cols = [col[1] for col in c.fetchall()]
            if "fatigue_at_event" not in cols:
                c.execute("ALTER TABLE behavior_log ADD COLUMN fatigue_at_event REAL")

            current_version = 1
            c.execute("DELETE FROM schema_version")
            c.execute("INSERT INTO schema_version (version) VALUES (1)")
            conn.commit()

        # -----------------------------
        # MIGRATION 2:
        # Create new clean tables if missing
        # -----------------------------
        if current_version < 2:
            c.execute("""
                CREATE TABLE IF NOT EXISTS fatigue_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    fatigue REAL NOT NULL
                )
            """)

            c.execute("""
                CREATE TABLE IF NOT EXISTS break_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    reason TEXT NOT NULL,
                    behavior TEXT,
                    fatigue REAL,
                    interval_used REAL,
                    timing_quality TEXT
                )
            """)

            c.execute("""
                CREATE TABLE IF NOT EXISTS suppression_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    type TEXT NOT NULL,
                    is_away_reset INTEGER NOT NULL
                )
            """)

            c.execute("""
                CREATE TABLE IF NOT EXISTS input_activity_log (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT NOT NULL,
                    window TEXT,
                    typing REAL,
                    mouse REAL,
                    scroll REAL
                )
            """)

            current_version = 2
            c.execute("UPDATE schema_version SET version = 2")
            conn.commit()

        # -----------------------------
        # MIGRATION 3:
        # Convert UNIX timestamps → ISO timestamps
        # -----------------------------
        if current_version < 3:
            # Convert behavior_log
            c.execute("SELECT id, timestamp FROM behavior_log")
            rows = c.fetchall()
            for row_id, ts in rows:
                if isinstance(ts, int) or ts.isdigit():
                    iso = datetime.fromtimestamp(int(ts)).isoformat()
                    c.execute("UPDATE behavior_log SET timestamp = ? WHERE id = ?", (iso, row_id))

            # Convert break_events → break_log (legacy table)
            c.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='break_events'")
            if c.fetchone():
                c.execute("SELECT id, timestamp, reason, behavior, fatigue, interval_used FROM break_events")
                rows = c.fetchall()
                for row_id, ts, reason, behavior, fatigue, interval_used in rows:
                    iso = datetime.fromtimestamp(int(ts)).isoformat()
                    c.execute("""
                        INSERT INTO break_log (timestamp, reason, behavior, fatigue, interval_used, timing_quality)
                        VALUES (?, ?, ?, ?, ?, ?)
                    """, (iso, reason, behavior, fatigue, interval_used, "on_time"))

            current_version = 3
            c.execute("UPDATE schema_version SET version = 3")
            conn.commit()

        # -----------------------------
        # MIGRATION 4:
        # Move window/typing/mouse/scroll → input_activity_log
        # -----------------------------
        if current_version < 4:
            c.execute("PRAGMA table_info(behavior_log)")
            cols = [col[1] for col in c.fetchall()]

            if "window" in cols:
                c.execute("SELECT id, timestamp, window, typing, mouse, scroll FROM behavior_log")
                rows = c.fetchall()

                for row_id, ts, window, typing, mouse, scroll in rows:
                    c.execute("""
                        INSERT INTO input_activity_log (timestamp, window, typing, mouse, scroll)
                        VALUES (?, ?, ?, ?, ?)
                    """, (ts, window, typing, mouse, scroll))

                # Rebuild behavior_log without old columns
                c.execute("ALTER TABLE behavior_log RENAME TO behavior_log_old")

                c.execute("""
                    CREATE TABLE behavior_log (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp TEXT NOT NULL,
                        behavior TEXT NOT NULL,
                        duration INTEGER,
                        fatigue_at_event REAL
                    )
                """)

                c.execute("""
                    INSERT INTO behavior_log (timestamp, behavior, duration, fatigue_at_event)
                    SELECT timestamp, behavior, NULL, fatigue_at_event
                    FROM behavior_log_old
                """)

                c.execute("DROP TABLE behavior_log_old")

            current_version = 4
            c.execute("UPDATE schema_version SET version = 4")
            conn.commit()

        conn.close()


    # ---------------------------------------------------------
    # PATHS
    # ---------------------------------------------------------
    def _get_db_path(self):
        appdata = Path(os.getenv("APPDATA"))
        folder = appdata / "YourApp"
        folder.mkdir(exist_ok=True)
        return folder / "user_data.db"

    def _connect(self):
        return sqlite3.connect(self.db_path)

    # ---------------------------------------------------------
    # DATABASE INIT
    # ---------------------------------------------------------
    def _ensure_database(self):
        conn = self._connect()
        c = conn.cursor()

        # -------------------------------------------------
        # BEHAVIOR LOG (event-based, premium)
        # -------------------------------------------------
        c.execute("""
            CREATE TABLE IF NOT EXISTS behavior_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                behavior TEXT NOT NULL,
                duration INTEGER,
                fatigue_at_event REAL
            )
        """)

        # -------------------------------------------------
        # FATIGUE LOG (minute-based or periodic)
        # -------------------------------------------------
        c.execute("""
            CREATE TABLE IF NOT EXISTS fatigue_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                fatigue REAL NOT NULL
            )
        """)

        # -------------------------------------------------
        # BREAK LOG (clean, analytics-ready)
        # -------------------------------------------------
        c.execute("""
            CREATE TABLE IF NOT EXISTS break_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                reason TEXT NOT NULL,
                behavior TEXT,
                fatigue REAL,
                interval_used REAL,
                timing_quality TEXT
            )
        """)

        # -------------------------------------------------
        # SUPPRESSION LOG
        # -------------------------------------------------
        c.execute("""
            CREATE TABLE IF NOT EXISTS suppression_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                type TEXT NOT NULL,
                is_away_reset INTEGER NOT NULL
            )
        """)

        # -------------------------------------------------
        # INPUT ACTIVITY LOG (raw signals for Smart Mode)
        # -------------------------------------------------
        c.execute("""
            CREATE TABLE IF NOT EXISTS input_activity_log (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                timestamp TEXT NOT NULL,
                window TEXT,
                typing REAL,
                mouse REAL,
                scroll REAL
            )
        """)

        # -------------------------------------------------
        # DAILY SUMMARIES (unchanged)
        # -------------------------------------------------
        c.execute("""
            CREATE TABLE IF NOT EXISTS daily_summary (
                date TEXT PRIMARY KEY,
                total_focus REAL,
                deep_work REAL,
                deep_reading REAL,
                focused_interaction REAL,
                breaks INTEGER,
                avg_fatigue REAL
            )
        """)

        # -------------------------------------------------
        # PERSONALIZATION (AI Mode)
        # -------------------------------------------------
        c.execute("""
            CREATE TABLE IF NOT EXISTS personalization (
                key TEXT PRIMARY KEY,
                value REAL
            )
        """)

        # -------------------------------------------------
        # SETTINGS
        # -------------------------------------------------
        c.execute("""
            CREATE TABLE IF NOT EXISTS settings (
                key TEXT PRIMARY KEY,
                value TEXT
            )
        """)

        conn.commit()
        conn.close()

    # ---------------------------------------------------------
    # WRITE FUNCTIONS
    # ---------------------------------------------------------
    def log_behavior(self, behavior, fatigue, window, typing, mouse, scroll):
        """
        Legacy-compatible signature:
        - Still accepts window/typing/mouse/scroll
        - Writes:
          - a clean behavior event into behavior_log
          - raw input signals into input_activity_log
        """
        now = datetime.now().isoformat()

        conn = self._connect()
        c = conn.cursor()

        # Behavior event (duration can be inferred later; stored as NULL for now)
        c.execute("""
            INSERT INTO behavior_log (timestamp, behavior, duration, fatigue_at_event)
            VALUES (?, ?, ?, ?)
        """, (now, behavior, None, fatigue))

        # Raw input activity
        c.execute("""
            INSERT INTO input_activity_log (timestamp, window, typing, mouse, scroll)
            VALUES (?, ?, ?, ?, ?)
        """, (now, window, typing, mouse, scroll))

        conn.commit()
        conn.close()

    def log_fatigue(self, fatigue):
        """
        Logs a fatigue sample (e.g., every minute).
        """
        now = datetime.now().isoformat()
        conn = self._connect()
        c = conn.cursor()
        c.execute("""
            INSERT INTO fatigue_log (timestamp, fatigue)
            VALUES (?, ?)
        """, (now, float(fatigue)))
        conn.commit()
        conn.close()

    def log_break(self, reason, behavior, fatigue, interval_used):
        """
        Legacy-compatible signature:
        - Writes a rich break event into break_log
        - timing_quality can be refined later; default 'on_time' for now.
        """
        now = datetime.now().isoformat()
        timing_quality = "on_time"  # placeholder; can be computed by analytics later

        conn = self._connect()
        c = conn.cursor()
        c.execute("""
            INSERT INTO break_log (timestamp, reason, behavior, fatigue, interval_used, timing_quality)
            VALUES (?, ?, ?, ?, ?, ?)
        """, (now, reason, behavior, fatigue, interval_used, timing_quality))
        conn.commit()
        conn.close()

    def log_suppression(self, type, is_away_reset):
        """
        Logs a suppression event.
        """
        now = datetime.now().isoformat()
        conn = self._connect()
        c = conn.cursor()
        c.execute("""
            INSERT INTO suppression_log (timestamp, type, is_away_reset)
            VALUES (?, ?, ?)
        """, (now, type, int(bool(is_away_reset))))
        conn.commit()
        conn.close()

    def save_daily_summary(self, summary_dict):
        conn = self._connect()
        c = conn.cursor()
        c.execute("""
            INSERT OR REPLACE INTO daily_summary
            (date, total_focus, deep_work, deep_reading, focused_interaction, breaks, avg_fatigue)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """, (
            summary_dict["date"],
            summary_dict["total_focus"],
            summary_dict["deep_work"],
            summary_dict["deep_reading"],
            summary_dict["focused_interaction"],
            summary_dict["breaks"],
            summary_dict["avg_fatigue"]
        ))
        conn.commit()
        conn.close()

    def save_personalization(self, key, value):
        conn = self._connect()
        c = conn.cursor()
        c.execute("""
            INSERT OR REPLACE INTO personalization (key, value)
            VALUES (?, ?)
        """, (key, value))
        conn.commit()
        conn.close()

    def save_setting(self, key, value):
        conn = self._connect()
        c = conn.cursor()
        c.execute("""
            INSERT OR REPLACE INTO settings (key, value)
            VALUES (?, ?)
        """, (key, json.dumps(value)))
        conn.commit()
        conn.close()

    # ---------------------------------------------------------
    # READ FUNCTIONS
    # ---------------------------------------------------------
    def get_daily_summary(self, date_str):
        conn = self._connect()
        c = conn.cursor()
        c.execute("SELECT * FROM daily_summary WHERE date = ?", (date_str,))
        row = c.fetchone()
        conn.close()
        return row

    def get_personalization(self, key):
        conn = self._connect()
        c = conn.cursor()
        c.execute("SELECT value FROM personalization WHERE key = ?", (key,))
        row = c.fetchone()
        conn.close()
        return row[0] if row else None

    def get_setting(self, key):
        conn = self._connect()
        c = conn.cursor()
        c.execute("SELECT value FROM settings WHERE key = ?", (key,))
        row = c.fetchone()
        conn.close()
        return json.loads(row[0]) if row else None

    # ---------------------------------------------------------
    # AGGREGATION HELPERS (DAY-LEVEL)
    # ---------------------------------------------------------
    def _day_bounds_iso(self, date_str):
        """
        Returns (start_iso, end_iso) for the given date in local time.
        """
        start_dt = datetime.strptime(date_str, "%Y-%m-%d")
        end_dt = start_dt + timedelta(days=1)
        return start_dt.isoformat(), end_dt.isoformat()

    def get_behavior_for_day(self, date_str):
        """
        Returns behavior events for a given day from behavior_log.
        """
        start_iso, end_iso = self._day_bounds_iso(date_str)

        conn = self._connect()
        c = conn.cursor()
        c.execute("""
            SELECT timestamp, behavior, fatigue_at_event
            FROM behavior_log
            WHERE timestamp BETWEEN ? AND ?
            ORDER BY timestamp ASC
        """, (start_iso, end_iso))
        rows = c.fetchall()
        conn.close()
        return rows

    def get_breaks_for_day(self, date_str):
        """
        Returns break events for a given day from break_log.
        """
        start_iso, end_iso = self._day_bounds_iso(date_str)

        conn = self._connect()
        c = conn.cursor()
        c.execute("""
            SELECT timestamp, reason, behavior, fatigue
            FROM break_log
            WHERE timestamp BETWEEN ? AND ?
            ORDER BY timestamp ASC
        """, (start_iso, end_iso))
        rows = c.fetchall()
        conn.close()
        return rows

    # ---------------------------------------------------------
    # RANGE HELPERS FOR ANALYTICS ENGINE
    # ---------------------------------------------------------
    def get_behavior_events(self, start_dt: datetime, end_dt: datetime):
        conn = self._connect()
        c = conn.cursor()
        c.execute("""
            SELECT timestamp, behavior, duration, fatigue_at_event
            FROM behavior_log
            WHERE timestamp BETWEEN ? AND ?
            ORDER BY timestamp ASC
        """, (start_dt.isoformat(), end_dt.isoformat()))
        rows = c.fetchall()
        conn.close()
        return rows

    def get_fatigue_events(self, start_dt: datetime, end_dt: datetime):
        conn = self._connect()
        c = conn.cursor()
        c.execute("""
            SELECT timestamp, fatigue
            FROM fatigue_log
            WHERE timestamp BETWEEN ? AND ?
            ORDER BY timestamp ASC
        """, (start_dt.isoformat(), end_dt.isoformat()))
        rows = c.fetchall()
        conn.close()
        return rows

    def get_break_events(self, start_dt: datetime, end_dt: datetime):
        conn = self._connect()
        c = conn.cursor()
        c.execute("""
            SELECT timestamp, reason, behavior, fatigue, interval_used, timing_quality
            FROM break_log
            WHERE timestamp BETWEEN ? AND ?
            ORDER BY timestamp ASC
        """, (start_dt.isoformat(), end_dt.isoformat()))
        rows = c.fetchall()
        conn.close()
        return rows

    def get_suppression_events(self, start_dt: datetime, end_dt: datetime):
        conn = self._connect()
        c = conn.cursor()
        c.execute("""
            SELECT timestamp, type, is_away_reset
            FROM suppression_log
            WHERE timestamp BETWEEN ? AND ?
            ORDER BY timestamp ASC
        """, (start_dt.isoformat(), end_dt.isoformat()))
        rows = c.fetchall()
        conn.close()
        return rows

    def get_input_activity_events(self, start_dt: datetime, end_dt: datetime):
        """
        Optional helper for Smart Mode / advanced analytics.
        """
        conn = self._connect()
        c = conn.cursor()
        c.execute("""
            SELECT timestamp, window, typing, mouse, scroll
            FROM input_activity_log
            WHERE timestamp BETWEEN ? AND ?
            ORDER BY timestamp ASC
        """, (start_dt.isoformat(), end_dt.isoformat()))
        rows = c.fetchall()
        conn.close()
        return rows
