# import csv
# from datetime import datetime, timedelta
# from statistics import mean


# class AnalyticsEngine:
#     def __init__(self, csv_path="usage_log.csv"):
#         self.csv_path = csv_path

#     # ---------- LOW-LEVEL LOADING ----------

#     def _load_range(self, days_back: int):
#         today = datetime.now().date()
#         start = today - timedelta(days=days_back - 1)

#         entries = []
#         try:
#             with open(self.csv_path, "r") as f:
#                 reader = csv.DictReader(f)
#                 for row in reader:
#                     date = datetime.fromisoformat(row["date"]).date()
#                     if start <= date <= today:
#                         entries.append({
#                             "date": date,
#                             "active": float(row["active_minutes"])
#                         })
#         except FileNotFoundError:
#             return []

#         return entries

#     def _aggregate_daily(self, entries):
#         daily = {}
#         for e in entries:
#             daily.setdefault(e["date"], 0)
#             daily[e["date"]] += e["active"]
#         days = sorted(daily.keys())
#         values = [daily[d] for d in days]
#         return days, values, daily

#     # ---------- WEEKLY SUMMARY ----------

#     def weekly_summary(self):
#         entries = self._load_range(7)
#         if not entries:
#             return None

#         days, values, daily = self._aggregate_daily(entries)

#         avg = mean(values)
#         total = sum(values)
#         best_day = days[values.index(max(values))].strftime("%A")
#         worst_day = days[values.index(min(values))].strftime("%A")
#         trend = "up" if values[-1] > values[0] else "down"

#         return {
#             "avg": avg,
#             "total": total,
#             "best_day": best_day,
#             "worst_day": worst_day,
#             "trend": trend,
#             "daily": daily,
#         }

#     # ---------- MONTHLY SUMMARY ----------

#     def monthly_summary(self):
#         entries = self._load_range(30)
#         if not entries:
#             return None

#         days, values, daily = self._aggregate_daily(entries)

#         avg = mean(values)
#         total = sum(values)
#         best_day = days[values.index(max(values))].strftime("%A")
#         worst_day = days[values.index(min(values))].strftime("%A")

#         # weekly breakdown
#         weeks = []
#         for i in range(0, len(values), 7):
#             week_vals = values[i:i + 7]
#             if week_vals:
#                 weeks.append(sum(week_vals))

#         best_week = max(weeks) if weeks else 0
#         worst_week = min(weeks) if weeks else 0

#         trend = "up" if values[-1] > values[0] else "down"

#         diffs = []
#         for i in range(1, len(values)):
#             diffs.append(abs(values[i] - values[i - 1]))
#         consistency = max(0, 100 - mean(diffs)) if diffs else 100

#         return {
#             "avg": avg,
#             "total": total,
#             "best_day": best_day,
#             "worst_day": worst_day,
#             "best_week": best_week,
#             "worst_week": worst_week,
#             "trend": trend,
#             "consistency": consistency,
#             "daily": daily,
#         }

#     # ---------- AI INSIGHTS (LIGHTWEIGHT) ----------

#     def ai_insights(self):
#         entries = self._load_range(30)
#         if not entries:
#             return ["No activity data available yet."]

#         parsed = entries
#         insights = []

#         avg = mean([p["active"] for p in parsed])
#         insights.append(f"Your average active time per day is {avg:.1f} minutes.")

#         # best day of week
#         by_day = {}
#         for p in parsed:
#             day = p["date"].strftime("%A")
#             by_day.setdefault(day, []).append(p["active"])
#         best_day = max(by_day, key=lambda d: mean(by_day[d]))
#         insights.append(f"Your most productive day is typically {best_day}.")

#         # evening drop
#         evening = [p for p in parsed if p["date"].weekday() < 5 and p["date"].day == p["date"].day and p["date"]]
#         # (we’ll keep this simple: skip evening detail if messy)
#         # weekend pattern
#         weekend = [p for p in parsed if p["date"].weekday() >= 5]
#         if weekend:
#             avg_weekend = mean([p["active"] for p in weekend])
#             if avg_weekend < avg * 0.7:
#                 insights.append("You tend to be less active on weekends.")

#         # consistency
#         daily = {}
#         for p in parsed:
#             d = p["date"]
#             daily.setdefault(d, 0)
#             daily[d] += p["active"]
#         if len(daily) >= 5:
#             days = sorted(daily.keys())
#             vals = [daily[d] for d in days]
#             diffs = [abs(vals[i] - vals[i - 1]) for i in range(1, len(vals))]
#             consistency = max(0, 100 - mean(diffs))
#             insights.append(f"Your break consistency score is {consistency:.0f}/100.")

#         return insights

#     # ---------- HEATMAP DATA ----------

#     def heatmap_data(self):
#         # simple: day-of-week vs total active minutes
#         entries = self._load_range(30)
#         if not entries:
#             return None

#         by_dow = {i: 0 for i in range(7)}  # 0=Mon
#         for e in entries:
#             dow = e["date"].weekday()
#             by_dow[dow] += e["active"]

#         return by_dow

#     # ---------- BREAK QUALITY SCORE ----------
#     def break_quality_score(self):
#         """
#         Computes a 0–100 score based on:
#         - Break frequency
#         - Break timing (not too late)
#         - Fatigue recovery patterns
#         - Meeting-mode interruptions
#         - Consistency across days
#         """

#         entries = self._load_range(7)  # last 7 days
#         if not entries:
#             return None

#         # Aggregate daily totals
#         days, values, daily = self._aggregate_daily(entries)

#         # 1. Frequency score (ideal: 3–6 breaks/day)
#         freq_scores = []
#         for d in days:
#             # You can later replace this with real break count from your engine
#             active = daily[d]
#             est_breaks = max(1, active // 45)  # rough estimate
#             if 3 <= est_breaks <= 6:
#                 freq_scores.append(100)
#             else:
#                 freq_scores.append(max(0, 100 - abs(est_breaks - 4) * 20))

#         freq_score = mean(freq_scores)

#         # 2. Consistency score (similar to monthly logic)
#         diffs = [abs(values[i] - values[i - 1]) for i in range(1, len(values))]
#         consistency = max(0, 100 - mean(diffs)) if diffs else 100

#         # 3. Timing score (reward shorter days with more breaks)
#         timing_score = 100 if mean(values) < 120 else 70

#         # Final weighted score
#         final = (
#             freq_score * 0.45 +
#             consistency * 0.35 +
#             timing_score * 0.20
#         )

#         return {
#             "score": round(final),
#             "frequency": round(freq_score),
#             "consistency": round(consistency),
#             "timing": round(timing_score),
#         }



























# 5 
# upgraded 
# core/analytics_engine.py

from datetime import datetime
from typing import Dict, List, Any, Optional


class AnalyticsEngine:
    """
    Premium, behavior-aware analytics engine interface.

    This class is intentionally structured and future-proof:
    - You can back it with a local DB, JSON, CSV, or cloud sync later.
    - The UI (AnalyticsSuitePage) and ExportManager depend only on this API.
    - All methods return simple Python structures (dicts, lists, primitives).
    """

    def __init__(self):
        # In the future, you can inject a storage / repository here.
        # Example: self.store = SomeDataStore(...)
        pass

    # -------------------------------------------------
    # BEHAVIOR
    # -------------------------------------------------
    def behavior_distribution(self) -> Dict[str, float]:
        """
        Returns total time per behavior for the current period (e.g., today).
        Example: {"Reading": 120, "Coding": 90, "Watching": 45}
        """
        return {}

    def behavior_timeline(self) -> Dict[str, List[Any]]:
        """
        Returns a timeline of behaviors across the day.

        Expected structure:
        {
            "times": [datetime, datetime, ...],
            "behaviors": ["Reading", "Coding", ...]
        }
        """
        return {"times": [], "behaviors": []}

    def behavior_by_hour(self) -> Dict[int, Dict[str, float]]:
        """
        Returns behavior distribution by hour of day.

        Example:
        {
            9: {"Reading": 30, "Coding": 10},
            10: {"Reading": 15, "Watching": 20},
            ...
        }
        """
        return {}

    def longest_behavior_streak(self) -> Optional[Dict[str, Any]]:
        """
        Returns info about the longest continuous streak of a single behavior.

        Example:
        {
            "behavior": "Reading",
            "minutes": 42
        }

        Return None if no data.
        """
        return None

    # -------------------------------------------------
    # FATIGUE
    # -------------------------------------------------
    def fatigue_trend(self) -> Dict[str, List[Any]]:
        """
        Returns fatigue values over time.

        Expected structure:
        {
            "times": [datetime, datetime, ...],
            "fatigue": [0-100, 0-100, ...]
        }
        """
        return {"times": [], "fatigue": []}

    def fatigue_by_behavior(self) -> Dict[str, float]:
        """
        Returns average fatigue per behavior.

        Example:
        {
            "Reading": 35.2,
            "Coding": 62.7,
            "Watching": 28.1
        }
        """
        return {}

    def fatigue_recovery_after_breaks(self) -> Dict[str, List[Any]]:
        """
        Returns fatigue values around breaks (before/after).

        Expected structure:
        {
            "times": [datetime, ...],
            "fatigue": [0-100, ...]
        }
        """
        return {"times": [], "fatigue": []}

    def highest_fatigue_moment(self) -> Optional[Dict[str, Any]]:
        """
        Returns the highest fatigue moment.

        Example:
        {
            "time": datetime,
            "fatigue": 87.0
        }

        Return None if no data.
        """
        return None

    # -------------------------------------------------
    # BREAKS
    # -------------------------------------------------
    def break_reasons(self) -> Dict[str, int]:
        """
        Returns counts of break reasons.

        Example:
        {
            "Strain Risk": 5,
            "Fatigue Early": 3,
            "Interval Reached": 4
        }
        """
        return {}

    def break_timing_quality(self) -> Dict[str, int]:
        """
        Returns counts of break timing quality.

        Expected keys:
        - "early"
        - "on_time"
        - "late"

        Example:
        {
            "early": 2,
            "on_time": 6,
            "late": 1
        }
        """
        return {}

    def break_events_timeline(self) -> Dict[str, List[Any]]:
        """
        Returns timestamps of breaks.

        Expected structure:
        {
            "times": [datetime, datetime, ...]
        }
        """
        return {"times": []}

    def break_suppression_stats(self) -> Dict[str, int]:
        """
        Returns counts of break suppression by type.

        Example:
        {
            "Meeting": 4,
            "Watching": 2,
            "Gaming": 1
        }
        """
        return {}

    # -------------------------------------------------
    # SUPPRESSION
    # -------------------------------------------------
    def suppression_counts(self) -> Dict[str, int]:
        """
        Returns counts of suppression events by type.

        Example:
        {
            "Meeting": 10,
            "Watching": 6,
            "Gaming": 3
        }
        """
        return {}

    def away_resets_count(self) -> int:
        """
        Returns number of away-based resets.
        """
        return 0

    # -------------------------------------------------
    # TIME OF DAY (HEATMAPS)
    # -------------------------------------------------
    def behavior_heatmap(self) -> Dict[int, float]:
        """
        Returns behavior intensity by hour.

        Simple 1D heatmap structure:
        {
            hour (0-23): value,
            ...
        }
        """
        return {}

    def fatigue_heatmap(self) -> Dict[int, float]:
        """
        Returns fatigue intensity by hour.

        Same structure as behavior_heatmap.
        """
        return {}

    def break_heatmap(self) -> Dict[int, float]:
        """
        Returns break frequency by hour.

        Same structure as behavior_heatmap.
        """
        return {}

    def suppression_heatmap(self) -> Dict[int, float]:
        """
        Returns suppression intensity by hour.

        Same structure as behavior_heatmap.
        """
        return {}

    # -------------------------------------------------
    # WEEKLY / MONTHLY
    # -------------------------------------------------
    def weekly_behavior_summary(self) -> Optional[Dict[str, Any]]:
        """
        Returns a weekly summary with behavior, fatigue, breaks, suppression.

        Expected structure:
        {
            "distribution": {behavior: minutes},
            "fatigue_trend": {
                "days": [date, ...],
                "fatigue": [0-100, ...]
            },
            "break_consistency": 0-100,
            "suppression_counts": {type: count}
        }

        Return None if no data.
        """
        return None

    def monthly_behavior_summary(self) -> Optional[Dict[str, Any]]:
        """
        Same idea as weekly_behavior_summary, but for the month.
        """
        return None

    # -------------------------------------------------
    # AI INSIGHTS
    # -------------------------------------------------
    def ai_insights(self) -> List[str]:
        """
        Returns a list of short, warm, behavior-aware insights.

        Example:
        [
            "Your longest deep work streak this week was 42 minutes in Coding.",
            "Afternoon fatigue tends to rise after long Watching sessions."
        ]
        """
        # Placeholder so the UI shows something instead of being empty.
        return ["Analytics are setting up. Once you’ve used the app a bit more, you’ll see rich insights here."]

    # -------------------------------------------------
    # EXPORT AGGREGATION
    # -------------------------------------------------
    def export_all_data(self) -> Dict[str, Dict[str, Any]]:
        """
        Collects all key analytics into a single structure for export.

        This is what ExportManager uses to generate CSV / Excel / PDF.
        """
        weekly = self.weekly_behavior_summary() or {}
        monthly = self.monthly_behavior_summary() or {}

        return {
            "Behavior Distribution": self.behavior_distribution(),
            "Behavior Timeline": self.behavior_timeline(),
            "Fatigue Trend": self.fatigue_trend(),
            "Fatigue by Behavior": self.fatigue_by_behavior(),
            "Break Reasons": self.break_reasons(),
            "Break Timing": self.break_timing_quality(),
            "Break Suppression": self.break_suppression_stats(),
            "Suppression Counts": self.suppression_counts(),
            "Weekly Summary": weekly,
            "Monthly Summary": monthly,
            "AI Insights": {"insights": self.ai_insights()},
        }
