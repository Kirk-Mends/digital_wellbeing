from PySide6.QtWidgets import QWidget
from PySide6.QtCore import QSize
from ui.pages.shared.fluent_card import FluentCard
from ui.animations import ValueAnimator, SparklineAnimator
from ui.core.card_registry import CardRegistry

DEFAULT_CARD_WIDTH = 320
LAPTOP_FULL_WIDTH = 680


class NextBreakCard(FluentCard):
    def __init__(self, height: int | None = None, fullWidthOnLaptop: bool = False, parent: QWidget | None = None):
        super().__init__(
            title="Next recommended break",
            accent_color="#30D158",
            has_spark=True,
        )

        # ✅ FIXED
        CardRegistry.register(self)

        self.fullWidthOnLaptop = fullWidthOnLaptop

        if height is not None:
            self.setMinimumHeight(height)

        self.setFixedWidth(DEFAULT_CARD_WIDTH)
        self.setParent(parent)
        self.setProperty("fullWidthOnLaptop", fullWidthOnLaptop)

        self.update_value(
            "Your next ideal break window will appear here based on current load and recent activity."
        )

        self.break_trend = []
        self.last_seconds = None

    def sizeHint(self) -> QSize:
        if self.fullWidthOnLaptop:
            return QSize(LAPTOP_FULL_WIDTH, self.minimumHeight())
        return QSize(DEFAULT_CARD_WIDTH, self.minimumHeight())

    def closeEvent(self, event):
        CardRegistry.unregister(self)
        super().closeEvent(event)

    def update_from_engine(self, behavior, fatigue, reason, trigger, next_break_seconds, session_start, monitoring):

        if trigger:
            self.update_value("Break now")
            self.last_seconds = None
        else:
            if next_break_seconds != self.last_seconds:
                self.last_seconds = next_break_seconds
                ValueAnimator(
                    start_value=max(next_break_seconds + 1, 0),
                    end_value=max(next_break_seconds, 0),
                    duration=350,
                    callback=lambda v: self.update_value(f"{int(v)} sec")
                ).start()

        numeric = min(max(int(fatigue), 0), 100)
        self.break_trend.append(numeric)
        self.break_trend = self.break_trend[-30:]

        if self.spark:
            SparklineAnimator(self.spark, "#30D158").animate(self.break_trend)
