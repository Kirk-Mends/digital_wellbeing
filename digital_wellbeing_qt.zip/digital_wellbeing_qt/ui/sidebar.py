




# # new architectural version

# from PySide6.QtCore import Qt, QSize, QPropertyAnimation, QEasingCurve
# from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton
# from PySide6.QtGui import QIcon


# class Sidebar(QWidget):
#     def __init__(self, main_window):
#         super().__init__()
#         self.main = main_window

#         # Sidebar state
#         self.expanded_width = 200
#         self.collapsed_width = 56
#         self.is_expanded = True

#         self.setMinimumWidth(self.expanded_width)
#         self.setObjectName("Sidebar")

#         # -------------------------
#         # MAIN LAYOUT
#         # -------------------------
#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(0, 0, 0, 0)
#         layout.setSpacing(0)

#         # -------------------------
#         # HAMBURGER BUTTON
#         # -------------------------
#         self.btn_toggle = QPushButton()
#         self.btn_toggle.setIcon(QIcon("assets/icons/hamburger.svg"))
#         self.btn_toggle.setIconSize(QSize(20, 20))
#         self.btn_toggle.setObjectName("HamburgerButton")
#         self.btn_toggle.clicked.connect(self.toggle_sidebar)
#         self.btn_toggle.setCursor(Qt.PointingHandCursor)
#         layout.addWidget(self.btn_toggle)

#         # -------------------------
#         # NAVIGATION BUTTONS
#         # -------------------------
#         self.btn_dashboard = self.make_button(
#             "Dashboard", "assets/icons/dashboard.svg", self.main.show_dashboard
#         )
#         self.btn_smart = self.make_button(
#             "Smart Mode", "assets/icons/smart_mode.svg", self.main.show_smart
#         )
#         self.btn_ai = self.make_button(
#             "AI Mode", "assets/icons/ai_mode.svg", self.main.show_ai
#         )

#         layout.addWidget(self.btn_dashboard)
#         layout.addWidget(self.btn_smart)
#         layout.addWidget(self.btn_ai)

#         # -------------------------
#         # ANALYTICS SECTION
#         # -------------------------
#         self.btn_analytics = self.make_button(
#             "Analytics", "assets/icons/analytics.svg", self.main.show_analytics
#         )
#         self.btn_weekly = self.make_button(
#             "Weekly Analytics", "assets/icons/weekly_report.svg", self.main.show_weekly
#         )
#         self.btn_insights = self.make_button(
#             "AI Insights", "assets/icons/ai_mode.svg", self.main.show_insights
#         )
#         self.btn_weekly_report = self.make_button(
#             "Weekly Report", "assets/icons/weekly_report.svg", self.main.show_weekly_report
#         )
#         self.btn_monthly_report = self.make_button(
#             "Monthly Report", "assets/icons/monthly_report.svg", self.main.show_monthly_report
#         )

#         layout.addWidget(self.btn_analytics)
#         layout.addWidget(self.btn_weekly)
#         layout.addWidget(self.btn_insights)
#         layout.addWidget(self.btn_weekly_report)
#         layout.addWidget(self.btn_monthly_report)

#         layout.addStretch()

#         # -------------------------
#         # SETTINGS BUTTON
#         # -------------------------
#         self.btn_settings = self.make_button(
#             "Settings", "assets/icons/settings.svg", self.main.show_settings
#         )
#         layout.addWidget(self.btn_settings)

#         # -------------------------
#         # STORE BUTTONS FOR ACTIVE/HOVER LOGIC
#         # -------------------------
#         self.buttons = [
#             self.btn_dashboard,
#             self.btn_smart,
#             self.btn_ai,
#             self.btn_analytics,
#             self.btn_weekly,
#             self.btn_insights,
#             self.btn_weekly_report,
#             self.btn_monthly_report,
#             self.btn_settings
#         ]

#         # Store full text for collapse mode
#         for btn in self.buttons:
#             btn.setProperty("full_text", btn.text())

#     # -------------------------------------------------------
#     # CREATE A NAVIGATION BUTTON
#     # -------------------------------------------------------
#     def make_button(self, text, icon_path, callback):
#         btn = QPushButton(text)
#         btn.setIcon(QIcon(icon_path))
#         btn.setIconSize(QSize(20, 20))
#         btn.setCursor(Qt.PointingHandCursor)
#         btn.setObjectName("SidebarButton")

#         # Hover glow
#         btn.setProperty("hover", False)
#         btn.enterEvent = lambda e, b=btn: self.on_hover(b, True)
#         btn.leaveEvent = lambda e, b=btn: self.on_hover(b, False)

#         # Active highlight
#         btn.clicked.connect(lambda: self.set_active(btn, callback))

#         return btn

#     # -------------------------------------------------------
#     # HOVER EFFECT
#     # -------------------------------------------------------
#     def on_hover(self, btn, state):
#         btn.setProperty("hover", state)
#         btn.style().unpolish(btn)
#         btn.style().polish(btn)

#     # -------------------------------------------------------
#     # SET ACTIVE BUTTON (ACCENT BAR)
#     # -------------------------------------------------------
#     def set_active(self, btn, callback):
#         for b in self.buttons:
#             b.setProperty("active", False)
#             b.style().unpolish(b)
#             b.style().polish(b)

#         btn.setProperty("active", True)
#         btn.style().unpolish(btn)
#         btn.style().polish(btn)

#         callback()

#     # -------------------------------------------------------
#     # ANIMATE SIDEBAR WIDTH
#     # -------------------------------------------------------
#     def animate_width(self, start, end, duration=250):
#         self.anim = QPropertyAnimation(self, b"minimumWidth")
#         self.anim.setDuration(duration)
#         self.anim.setStartValue(start)
#         self.anim.setEndValue(end)
#         self.anim.setEasingCurve(QEasingCurve.InOutCubic)
#         self.anim.start()

#     # -------------------------------------------------------
#     # COLLAPSE / EXPAND SIDEBAR
#     # -------------------------------------------------------
#     def toggle_sidebar(self):
#         target_width = self.collapsed_width if self.is_expanded else self.expanded_width
#         self.is_expanded = not self.is_expanded

#         # Animate width
#         self.animate_width(self.width(), target_width)

#         # Hide/show text on buttons
#         for btn in self.buttons:
#             full_text = btn.property("full_text")
#             btn.setText(full_text if self.is_expanded else "")

#     # -------------------------------------------------------
#     # MEETING MODE HIGHLIGHT
#     # -------------------------------------------------------
#     def set_meeting_mode(self, active: bool):
#         # Highlight Smart Mode + AI Mode buttons during meetings
#         self.btn_smart.setProperty("meeting", active)
#         self.btn_ai.setProperty("meeting", active)

#         for btn in (self.btn_smart, self.btn_ai):
#             btn.style().unpolish(btn)
#             btn.style().polish(btn)










# from PySide6.QtCore import Qt, QSize, QPropertyAnimation, QEasingCurve
# from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QHBoxLayout, QLabel
# from PySide6.QtGui import QIcon


# # -------------------------------------------------------
# # PREMIUM SIDEBAR BUTTON (fixes alignment + hover + active)
# # -------------------------------------------------------
# class SidebarButton(QWidget):
#     def __init__(self, text, icon_path, callback, parent=None):
#         super().__init__(parent)

#         self.setObjectName("SidebarButton")
#         self.setAttribute(Qt.WA_StyledBackground, True)  # CRITICAL: allow QSS background

#         self.callback = callback
#         self.full_text = text

#         # Layout for icon + text (perfect left alignment)
#         layout = QHBoxLayout(self)
#         layout.setContentsMargins(18, 6, 12, 6)
#         layout.setSpacing(10)
#         layout.setAlignment(Qt.AlignLeft | Qt.AlignVCenter)

#         # Icon
#         self.icon_label = QLabel()
#         self.icon_label.setPixmap(QIcon(icon_path).pixmap(20, 20))
#         self.icon_label.setFixedSize(20, 20)
#         layout.addWidget(self.icon_label)

#         # Text
#         self.text_label = QLabel(text)
#         self.text_label.setObjectName("SidebarButtonText")
#         layout.addWidget(self.text_label)

#         # Mouse interactions
#         self.setMouseTracking(True)

#     # Hover
#     def enterEvent(self, event):
#         self.setProperty("hover", True)
#         self.style().unpolish(self)
#         self.style().polish(self)

#     def leaveEvent(self, event):
#         self.setProperty("hover", False)
#         self.style().unpolish(self)
#         self.style().polish(self)

#     # Click
#     def mousePressEvent(self, event):
#         self.callback()
#         self.parent().set_active(self)
#         super().mousePressEvent(event)

#     # Collapse/expand text
#     def set_collapsed(self, collapsed):
#         self.text_label.setText("" if collapsed else self.full_text)


# # -------------------------------------------------------
# # SIDEBAR
# # -------------------------------------------------------
# class Sidebar(QWidget):
#     def __init__(self, main_window):
#         super().__init__()
#         self.main = main_window

#         self.expanded_width = 200
#         self.collapsed_width = 56
#         self.is_expanded = True

#         self.setMinimumWidth(self.expanded_width)
#         self.setObjectName("Sidebar")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(0, 0, 0, 0)
#         layout.setSpacing(0)

#         # Hamburger button
#         self.btn_toggle = QPushButton()
#         self.btn_toggle.setIcon(QIcon("assets/icons/hamburger.svg"))
#         self.btn_toggle.setIconSize(QSize(20, 20))
#         self.btn_toggle.setObjectName("HamburgerButton")
#         self.btn_toggle.clicked.connect(self.toggle_sidebar)
#         self.btn_toggle.setCursor(Qt.PointingHandCursor)
#         layout.addWidget(self.btn_toggle)

#         # Navigation buttons
#         self.btn_dashboard = self.make_button("Dashboard", "assets/icons/dashboard.svg", self.main.show_dashboard)
#         self.btn_smart = self.make_button("Smart Mode", "assets/icons/smart_mode.svg", self.main.show_smart)
#         self.btn_ai = self.make_button("AI Mode", "assets/icons/ai_mode.svg", self.main.show_ai)

#         layout.addWidget(self.btn_dashboard)
#         layout.addWidget(self.btn_smart)
#         layout.addWidget(self.btn_ai)

#         # Analytics section
#         self.btn_analytics = self.make_button("Analytics", "assets/icons/analytics.svg", self.main.show_analytics)
#         self.btn_weekly = self.make_button("Weekly Analytics", "assets/icons/weekly_report.svg", self.main.show_weekly)
#         self.btn_insights = self.make_button("AI Insights", "assets/icons/ai_mode.svg", self.main.show_insights)
#         self.btn_weekly_report = self.make_button("Weekly Report", "assets/icons/weekly_report.svg", self.main.show_weekly_report)
#         self.btn_monthly_report = self.make_button("Monthly Report", "assets/icons/monthly_report.svg", self.main.show_monthly_report)

#         layout.addWidget(self.btn_analytics)
#         layout.addWidget(self.btn_weekly)
#         layout.addWidget(self.btn_insights)
#         layout.addWidget(self.btn_weekly_report)
#         layout.addWidget(self.btn_monthly_report)

#         layout.addStretch()

#         # Settings
#         self.btn_settings = self.make_button("Settings", "assets/icons/settings.svg", self.main.show_settings)
#         layout.addWidget(self.btn_settings)

#         # Store buttons
#         self.buttons = [
#             self.btn_dashboard,
#             self.btn_smart,
#             self.btn_ai,
#             self.btn_analytics,
#             self.btn_weekly,
#             self.btn_insights,
#             self.btn_weekly_report,
#             self.btn_monthly_report,
#             self.btn_settings
#         ]

#     # Create button
#     def make_button(self, text, icon_path, callback):
#         return SidebarButton(text, icon_path, callback, parent=self)

#     # Active state
#     def set_active(self, active_btn):
#         for btn in self.buttons:
#             btn.setProperty("active", btn is active_btn)
#             btn.style().unpolish(btn)
#             btn.style().polish(btn)

#     # Collapse/expand
#     def toggle_sidebar(self):
#         target_width = self.collapsed_width if self.is_expanded else self.expanded_width
#         self.is_expanded = not self.is_expanded

#         self.animate_width(self.width(), target_width)

#         for btn in self.buttons:
#             btn.set_collapsed(not self.is_expanded)

#     # Animation
#     def animate_width(self, start, end, duration=250):
#         self.anim = QPropertyAnimation(self, b"minimumWidth")
#         self.anim.setDuration(duration)
#         self.anim.setStartValue(start)
#         self.anim.setEndValue(end)
#         self.anim.setEasingCurve(QEasingCurve.InOutCubic)
#         self.anim.start()

#     # Meeting mode highlight
#     def set_meeting_mode(self, active: bool):
#         for btn in (self.btn_smart, self.btn_ai):
#             btn.setProperty("meeting", active)
#             btn.style().unpolish(btn)
#             btn.style().polish(btn)






# Better View

# from PySide6.QtCore import Qt, QSize, QPropertyAnimation, QEasingCurve
# from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton
# from PySide6.QtGui import QIcon


# class Sidebar(QWidget):
#     def __init__(self, main_window):
#         super().__init__()
#         self.main = main_window

#         self.expanded_width = 200
#         self.collapsed_width = 56
#         self.is_expanded = True

#         self.setMinimumWidth(self.expanded_width)
#         self.setObjectName("Sidebar")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(0, 0, 0, 0)
#         layout.setSpacing(0)

#         # Hamburger
#         self.btn_toggle = QPushButton()
#         self.btn_toggle.setIcon(QIcon("assets/icons/hamburger.svg"))
#         self.btn_toggle.setIconSize(QSize(20, 20))
#         self.btn_toggle.setObjectName("HamburgerButton")
#         self.btn_toggle.clicked.connect(self.toggle_sidebar)
#         self.btn_toggle.setCursor(Qt.PointingHandCursor)
#         layout.addWidget(self.btn_toggle)

#         # Navigation
#         self.btn_dashboard = self.make_button("Dashboard", "assets/icons/dashboard.svg", self.main.show_dashboard)
#         self.btn_smart = self.make_button("Smart Mode", "assets/icons/smart_mode.svg", self.main.show_smart)
#         self.btn_ai = self.make_button("AI Mode", "assets/icons/ai_mode.svg", self.main.show_ai)

#         layout.addWidget(self.btn_dashboard)
#         layout.addWidget(self.btn_smart)
#         layout.addWidget(self.btn_ai)

#         # Analytics
#         self.btn_analytics = self.make_button("Analytics", "assets/icons/analytics.svg", self.main.show_analytics)
#         self.btn_weekly = self.make_button("Weekly Analytics", "assets/icons/weekly_report.svg", self.main.show_weekly)
#         self.btn_insights = self.make_button("AI Insights", "assets/icons/ai_mode.svg", self.main.show_insights)
#         self.btn_weekly_report = self.make_button("Weekly Report", "assets/icons/weekly_report.svg", self.main.show_weekly_report)
#         self.btn_monthly_report = self.make_button("Monthly Report", "assets/icons/monthly_report.svg", self.main.show_monthly_report)

#         layout.addWidget(self.btn_analytics)
#         layout.addWidget(self.btn_weekly)
#         layout.addWidget(self.btn_insights)
#         layout.addWidget(self.btn_weekly_report)
#         layout.addWidget(self.btn_monthly_report)

#         layout.addStretch()

#         # Settings
#         self.btn_settings = self.make_button("Settings", "assets/icons/settings.svg", self.main.show_settings)
#         layout.addWidget(self.btn_settings)

#         # Store buttons
#         self.buttons = [
#             self.btn_dashboard,
#             self.btn_smart,
#             self.btn_ai,
#             self.btn_analytics,
#             self.btn_weekly,
#             self.btn_insights,
#             self.btn_weekly_report,
#             self.btn_monthly_report,
#             self.btn_settings
#         ]

#         for btn in self.buttons:
#             btn.setProperty("full_text", btn.text())


#     # -------------------------------------------------------
#     # CREATE BUTTON (your design, just fixed)
#     # -------------------------------------------------------
#     def make_button(self, text, icon_path, callback):
#         btn = QPushButton(text)
#         btn.setIcon(QIcon(icon_path))
#         btn.setIconSize(QSize(20, 20))
#         btn.setCursor(Qt.PointingHandCursor)
#         btn.setObjectName("SidebarButton")

#         # ⭐ FIX 1: allow QSS to paint hover/active background
#         btn.setAttribute(Qt.WA_StyledBackground, True)

#         # ⭐ FIX 2: force left alignment (matches your design)
#         btn.setStyleSheet("text-align: left; padding-left: 18px;")

#         # Hover
#         btn.setProperty("hover", False)
#         btn.enterEvent = lambda e, b=btn: self.on_hover(b, True)
#         btn.leaveEvent = lambda e, b=btn: self.on_hover(b, False)

#         # Active
#         btn.clicked.connect(lambda: self.set_active(btn, callback))

#         return btn


#     def on_hover(self, btn, state):
#         btn.setProperty("hover", state)
#         btn.style().unpolish(btn)
#         btn.style().polish(btn)


#     def set_active(self, btn, callback):
#         for b in self.buttons:
#             b.setProperty("active", False)
#             b.style().unpolish(b)
#             b.style().polish(b)

#         btn.setProperty("active", True)
#         btn.style().unpolish(btn)
#         btn.style().polish(btn)

#         callback()


#     def animate_width(self, start, end, duration=250):
#         self.anim = QPropertyAnimation(self, b"minimumWidth")
#         self.anim.setDuration(duration)
#         self.anim.setStartValue(start)
#         self.anim.setEndValue(end)
#         self.anim.setEasingCurve(QEasingCurve.InOutCubic)
#         self.anim.start()


#     def toggle_sidebar(self):
#         target_width = self.collapsed_width if self.is_expanded else self.expanded_width
#         self.is_expanded = not self.is_expanded

#         self.animate_width(self.width(), target_width)

#         for btn in self.buttons:
#             full_text = btn.property("full_text")
#             btn.setText(full_text if self.is_expanded else "")


#     def set_meeting_mode(self, active: bool):
#         self.btn_smart.setProperty("meeting", active)
#         self.btn_ai.setProperty("meeting", active)

#         for btn in (self.btn_smart, self.btn_ai):
#             btn.style().unpolish(btn)
#             btn.style().polish(btn)























# Better View but not that better

# from PySide6.QtCore import Qt, QSize, QPropertyAnimation, QEasingCurve
# from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton
# from PySide6.QtGui import QIcon


# class Sidebar(QWidget):
#     def __init__(self, main_window):
#         super().__init__()
#         self.main = main_window

#         self.expanded_width = 200
#         self.collapsed_width = 56
#         self.is_expanded = True

#         self.setMinimumWidth(self.expanded_width)
#         self.setObjectName("Sidebar")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(0, 0, 0, 0)
#         layout.setSpacing(0)

#         # Hamburger
#         self.btn_toggle = QPushButton()
#         self.btn_toggle.setIcon(QIcon("assets/icons/hamburger.svg"))
#         self.btn_toggle.setIconSize(QSize(20, 20))
#         self.btn_toggle.setObjectName("HamburgerButton")
#         self.btn_toggle.clicked.connect(self.toggle_sidebar)
#         self.btn_toggle.setCursor(Qt.PointingHandCursor)
#         layout.addWidget(self.btn_toggle)

#         # Navigation
#         self.btn_dashboard = self.make_button("Dashboard", "assets/icons/dashboard.svg", self.main.show_dashboard)
#         self.btn_smart = self.make_button("Smart Mode", "assets/icons/smart_mode.svg", self.main.show_smart)
#         self.btn_ai = self.make_button("AI Mode", "assets/icons/ai_mode.svg", self.main.show_ai)

#         layout.addWidget(self.btn_dashboard)
#         layout.addWidget(self.btn_smart)
#         layout.addWidget(self.btn_ai)

#         # Analytics
#         self.btn_analytics = self.make_button("Analytics", "assets/icons/analytics.svg", self.main.show_analytics)
#         self.btn_weekly = self.make_button("Weekly Analytics", "assets/icons/weekly_report.svg", self.main.show_weekly)
#         self.btn_insights = self.make_button("AI Insights", "assets/icons/ai_mode.svg", self.main.show_insights)
#         self.btn_weekly_report = self.make_button("Weekly Report", "assets/icons/weekly_report.svg", self.main.show_weekly_report)
#         self.btn_monthly_report = self.make_button("Monthly Report", "assets/icons/monthly_report.svg", self.main.show_monthly_report)

#         layout.addWidget(self.btn_analytics)
#         layout.addWidget(self.btn_weekly)
#         layout.addWidget(self.btn_insights)
#         layout.addWidget(self.btn_weekly_report)
#         layout.addWidget(self.btn_monthly_report)

#         layout.addStretch()

#         # Settings
#         self.btn_settings = self.make_button("Settings", "assets/icons/settings.svg", self.main.show_settings)
#         layout.addWidget(self.btn_settings)

#         # Store buttons
#         self.buttons = [
#             self.btn_dashboard,
#             self.btn_smart,
#             self.btn_ai,
#             self.btn_analytics,
#             self.btn_weekly,
#             self.btn_insights,
#             self.btn_weekly_report,
#             self.btn_monthly_report,
#             self.btn_settings
#         ]

#         for btn in self.buttons:
#             btn.setProperty("full_text", btn.text())


#     # -------------------------------------------------------
#     # CREATE BUTTON (your design, just fixed)
#     # -------------------------------------------------------
#     def make_button(self, text, icon_path, callback):
#         btn = QPushButton(text)
#         btn.setIcon(QIcon(icon_path))
#         btn.setIconSize(QSize(22, 22))
#         btn.setCursor(Qt.PointingHandCursor)
#         btn.setObjectName("SidebarButton")

#         # ⭐ FIX 1: allow QSS to paint hover/active background
#         # btn.setAttribute(Qt.WA_StyledBackground, True)
#         # btn.setAutoFillBackground(True)

#         # ⭐ FIX 2: force left alignment (matches your design)
#         #btn.setStyleSheet("text-align: left; padding-left: 18px;")
#         # btn.setStyleSheet("""
#         #     text-align: left; 
#         #     padding-left: 20px;   /* bigger left anchor */
#         #     padding-top: 12px; /* bigger button height */ 
#         #     padding-bottom: 12px; /* bigger button height */ 
#         # """)                                             

#         # btn.setStyleSheet(""" 
#         #     background-color: transparent;
#         #     /* border: 8px; */
#         #     text-align: left; 
#         #     padding-left: 13px; 
#         #     padding-top: 6px; 
#         #     padding-bottom: 6px; 
#         #     font-weight: 520; /* bold text */ 
#         # """)
        
#         # # Hover
#         # btn.setProperty("hover", False)
#         # btn.enterEvent = lambda e, b=btn: self.on_hover(b, True)
#         # btn.leaveEvent = lambda e, b=btn: self.on_hover(b, False)

#         # Active
#         btn.clicked.connect(lambda: self.set_active(btn, callback))

#         return btn


#     def on_hover(self, btn, state):
#         btn.setProperty("hover", state)
#         btn.style().unpolish(btn)
#         btn.style().polish(btn)


#     def set_active(self, btn, callback):
#         for b in self.buttons:
#             b.setProperty("active", False)
#             b.style().unpolish(b)
#             b.style().polish(b)

#         btn.setProperty("active", True)
#         btn.style().unpolish(btn)
#         btn.style().polish(btn)

#         callback()


#     def animate_width(self, start, end, duration=250):
#         self.anim = QPropertyAnimation(self, b"minimumWidth")
#         self.anim.setDuration(duration)
#         self.anim.setStartValue(start)
#         self.anim.setEndValue(end)
#         self.anim.setEasingCurve(QEasingCurve.InOutCubic)
#         self.anim.start()


#     def toggle_sidebar(self):
#         target_width = self.collapsed_width if self.is_expanded else self.expanded_width
#         self.is_expanded = not self.is_expanded

#         self.animate_width(self.width(), target_width)

#         for btn in self.buttons:
#             full_text = btn.property("full_text")
#             btn.setText(full_text if self.is_expanded else "")


#     def set_meeting_mode(self, active: bool):
#         self.btn_smart.setProperty("meeting", active)
#         self.btn_ai.setProperty("meeting", active)

#         for btn in (self.btn_smart, self.btn_ai):
#             btn.style().unpolish(btn)
#             btn.style().polish(btn)
















# from PySide6.QtCore import Qt, QSize, QPropertyAnimation, QEasingCurve
# from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton
# from PySide6.QtGui import QIcon


# class Sidebar(QWidget):
#     def __init__(self, main_window):
#         super().__init__()
#         self.main = main_window

#         # Sidebar state
#         self.expanded_width = 200
#         self.collapsed_width = 56
#         self.is_expanded = True

#         self.setMinimumWidth(self.expanded_width)
#         self.setObjectName("Sidebar")

#         # -------------------------
#         # MAIN LAYOUT
#         # -------------------------
#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(0, 0, 0, 0)
#         layout.setSpacing(0)

#         # -------------------------
#         # HAMBURGER BUTTON
#         # -------------------------
#         self.btn_toggle = QPushButton()
#         self.btn_toggle.setIcon(QIcon("assets/icons/hamburger.svg"))
#         self.btn_toggle.setIconSize(QSize(20, 20))
#         self.btn_toggle.setObjectName("HamburgerButton")
#         self.btn_toggle.setCursor(Qt.PointingHandCursor)
#         self.btn_toggle.clicked.connect(self.toggle_sidebar)
#         layout.addWidget(self.btn_toggle)

#         # -------------------------
#         # NAVIGATION BUTTONS
#         # -------------------------
#         self.btn_dashboard = self.make_button(
#             "Dashboard", "assets/icons/dashboard.svg", self.main.show_dashboard
#         )
#         self.btn_smart = self.make_button(
#             "Smart Mode", "assets/icons/smart_mode.svg", self.main.show_smart
#         )
#         self.btn_ai = self.make_button(
#             "AI Mode", "assets/icons/ai_mode.svg", self.main.show_ai
#         )

#         layout.addWidget(self.btn_dashboard)
#         layout.addWidget(self.btn_smart)
#         layout.addWidget(self.btn_ai)

#         # -------------------------
#         # ANALYTICS SECTION
#         # -------------------------
#         self.btn_analytics = self.make_button(
#             "Analytics", "assets/icons/analytics.svg", self.main.show_analytics
#         )
#         self.btn_weekly = self.make_button(
#             "Weekly Analytics", "assets/icons/weekly_report.svg", self.main.show_weekly
#         )
#         self.btn_insights = self.make_button(
#             "AI Insights", "assets/icons/ai_mode.svg", self.main.show_insights
#         )
#         self.btn_weekly_report = self.make_button(
#             "Weekly Report", "assets/icons/weekly_report.svg", self.main.show_weekly_report
#         )
#         self.btn_monthly_report = self.make_button(
#             "Monthly Report", "assets/icons/monthly_report.svg", self.main.show_monthly_report
#         )

#         layout.addWidget(self.btn_analytics)
#         layout.addWidget(self.btn_weekly)
#         layout.addWidget(self.btn_insights)
#         layout.addWidget(self.btn_weekly_report)
#         layout.addWidget(self.btn_monthly_report)

#         layout.addStretch()

#         # -------------------------
#         # SETTINGS BUTTON
#         # -------------------------
#         self.btn_settings = self.make_button(
#             "Settings", "assets/icons/settings.svg", self.main.show_settings
#         )
#         layout.addWidget(self.btn_settings)

#         # -------------------------
#         # STORE BUTTONS FOR ACTIVE LOGIC
#         # -------------------------
#         self.buttons = [
#             self.btn_dashboard,
#             self.btn_smart,
#             self.btn_ai,
#             self.btn_analytics,
#             self.btn_weekly,
#             self.btn_insights,
#             self.btn_weekly_report,
#             self.btn_monthly_report,
#             self.btn_settings
#         ]

#         # Store full text for collapse mode
#         for btn in self.buttons:
#             btn.setProperty("full_text", btn.text())

#     # -------------------------------------------------------
#     # CREATE A NAVIGATION BUTTON
#     # -------------------------------------------------------
#     def make_button(self, text, icon_path, callback):
#         btn = QPushButton(text)
#         btn.setIcon(QIcon(icon_path))
#         btn.setIconSize(QSize(20, 20))
#         btn.setCursor(Qt.PointingHandCursor)
#         btn.setObjectName("SidebarButton")

#         # No hover properties
#         # No enterEvent / leaveEvent
#         # No inline styles

#         btn.clicked.connect(lambda: self.set_active(btn, callback))
#         return btn

#     # -------------------------------------------------------
#     # SET ACTIVE BUTTON (ACCENT BAR)
#     # -------------------------------------------------------
#     def set_active(self, btn, callback):
#         for b in self.buttons:
#             b.setProperty("active", False)
#             b.style().unpolish(b)
#             b.style().polish(b)

#         btn.setProperty("active", True)
#         btn.style().unpolish(btn)
#         btn.style().polish(btn)

#         callback()

#     # -------------------------------------------------------
#     # ANIMATE SIDEBAR WIDTH
#     # -------------------------------------------------------
#     def animate_width(self, start, end, duration=250):
#         self.anim = QPropertyAnimation(self, b"minimumWidth")
#         self.anim.setDuration(duration)
#         self.anim.setStartValue(start)
#         self.anim.setEndValue(end)
#         self.anim.setEasingCurve(QEasingCurve.InOutCubic)
#         self.anim.start()

#     # -------------------------------------------------------
#     # COLLAPSE / EXPAND SIDEBAR
#     # -------------------------------------------------------
#     def toggle_sidebar(self):
#         target_width = self.collapsed_width if self.is_expanded else self.expanded_width
#         self.is_expanded = not self.is_expanded

#         # Animate width
#         self.animate_width(self.width(), target_width)

#         # Hide/show text on buttons
#         for btn in self.buttons:
#             full_text = btn.property("full_text")
#             btn.setText(full_text if self.is_expanded else "")

#     # -------------------------------------------------------
#     # MEETING MODE HIGHLIGHT
#     # -------------------------------------------------------
#     def set_meeting_mode(self, active: bool):
#         self.btn_smart.setProperty("meeting", active)
#         self.btn_ai.setProperty("meeting", active)

#         for btn in (self.btn_smart, self.btn_ai):
#             btn.style().unpolish(btn)
#             btn.style().polish(btn)

















# from PySide6.QtCore import Qt, QSize, QPropertyAnimation, QEasingCurve
# from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton
# from PySide6.QtGui import QIcon


# class Sidebar(QWidget):
#     def __init__(self, main_window):
#         super().__init__()
#         self.main = main_window

#         # Sidebar state
#         self.expanded_width = 200
#         self.collapsed_width = 56
#         self.is_expanded = True

#         self.setMinimumWidth(self.expanded_width)
#         self.setObjectName("Sidebar")

#         # -------------------------
#         # MAIN LAYOUT
#         # -------------------------
#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(0, 0, 0, 0)
#         layout.setSpacing(8)

#         # -------------------------
#         # HAMBURGER BUTTON
#         # -------------------------
#         self.btn_toggle = QPushButton()
#         self.btn_toggle.setIcon(QIcon("assets/icons/hamburger.svg"))
#         self.btn_toggle.setIconSize(QSize(20, 20))
#         self.btn_toggle.setObjectName("HamburgerButton")
#         self.btn_toggle.setCursor(Qt.PointingHandCursor)
#         self.btn_toggle.clicked.connect(self.toggle_sidebar)
#         layout.addWidget(self.btn_toggle)

#         # -------------------------
#         # NAVIGATION BUTTONS
#         # -------------------------
#         self.btn_dashboard = self.make_button(
#             "Dashboard", "assets/icons/dashboard.svg", self.main.show_dashboard
#         )
#         self.btn_smart = self.make_button(
#             "Smart Mode", "assets/icons/smart_mode.svg", self.main.show_smart
#         )
#         self.btn_ai = self.make_button(
#             "AI Mode", "assets/icons/ai_mode.svg", self.main.show_ai
#         )

#         self.section_main = self.make_section([
#             self.btn_dashboard,
#             self.btn_smart,
#             self.btn_ai
#         ])
#         layout.addWidget(self.section_main)

#         # -------------------------
#         # ANALYTICS SECTION
#         # -------------------------
#         self.btn_analytics = self.make_button(
#             "Analytics", "assets/icons/analytics.svg", self.main.show_analytics
#         )
#         self.btn_weekly = self.make_button(
#             "Weekly Analytics", "assets/icons/weekly_report.svg", self.main.show_weekly
#         )
#         self.btn_insights = self.make_button(
#             "AI Insights", "assets/icons/ai_mode.svg", self.main.show_insights
#         )
#         self.btn_weekly_report = self.make_button(
#             "Weekly Report", "assets/icons/weekly_report.svg", self.main.show_weekly_report
#         )
#         self.btn_monthly_report = self.make_button(
#             "Monthly Report", "assets/icons/monthly_report.svg", self.main.show_monthly_report
#         )

#         self.section_analytics = self.make_section([
#             self.btn_analytics,
#             self.btn_weekly,
#             self.btn_insights,
#             self.btn_weekly_report,
#             self.btn_monthly_report
#         ])
#         layout.addWidget(self.section_analytics)

#         layout.addStretch()

#         # -------------------------
#         # SETTINGS BUTTON
#         # -------------------------
#         self.btn_settings = self.make_button(
#             "Settings", "assets/icons/settings.svg", self.main.show_settings
#         )
#         self.section_settings = self.make_section([self.btn_settings])
#         layout.addWidget(self.section_settings)

#         # -------------------------
#         # STORE BUTTONS FOR ACTIVE LOGIC
#         # -------------------------
#         self.buttons = [
#             self.btn_dashboard,
#             self.btn_smart,
#             self.btn_ai,
#             self.btn_analytics,
#             self.btn_weekly,
#             self.btn_insights,
#             self.btn_weekly_report,
#             self.btn_monthly_report,
#             self.btn_settings
#         ]

#         # Store full text for collapse mode
#         for btn in self.buttons:
#             btn.setProperty("full_text", btn.text())

        
#     # -------------------------------------------------------
#     # CREATE A NAVIGATION BUTTON
#     # -------------------------------------------------------
#     def make_button(self, text, icon_path, callback):
#         btn = QPushButton(text)
#         btn.setIcon(QIcon(icon_path))
#         btn.setIconSize(QSize(20, 20))
#         btn.setCursor(Qt.PointingHandCursor)
#         btn.setObjectName("SidebarButton")

#         btn.clicked.connect(lambda: self.set_active(btn, callback))
#         return btn

#     # -------------------------------------------------------
#     # CREATE A SECTION BOX
#     # -------------------------------------------------------
#     def make_section(self, buttons):
#         container = QWidget()
#         container.setObjectName("SidebarSection")

#         v = QVBoxLayout(container)
#         v.setContentsMargins(6, 6, 6, 6)
#         v.setSpacing(4)

#         for b in buttons:
#             v.addWidget(b)

#         return container

#     # -------------------------------------------------------
#     # SET ACTIVE BUTTON (ACCENT BAR)
#     # -------------------------------------------------------
#     def set_active(self, btn, callback):
#         for b in self.buttons:
#             b.setProperty("active", False)
#             b.style().unpolish(b)
#             b.style().polish(b)

#         btn.setProperty("active", True)
#         btn.style().unpolish(btn)
#         btn.style().polish(btn)

#         callback()

#     # -------------------------------------------------------
#     # ANIMATE SIDEBAR WIDTH
#     # -------------------------------------------------------
#     def animate_width(self, start, end, duration=250):
#         self.anim = QPropertyAnimation(self, b"minimumWidth")
#         self.anim.setDuration(duration)
#         self.anim.setStartValue(start)
#         self.anim.setEndValue(end)
#         self.anim.setEasingCurve(QEasingCurve.InOutCubic)
#         self.anim.start()

#     # -------------------------------------------------------
#     # COLLAPSE / EXPAND SIDEBAR
#     # -------------------------------------------------------
#     def toggle_sidebar(self):
#         target_width = self.collapsed_width if self.is_expanded else self.expanded_width
#         self.is_expanded = not self.is_expanded

#         self.animate_width(self.width(), target_width)

#         for btn in self.buttons:
#             full_text = btn.property("full_text")
#             btn.setText(full_text if self.is_expanded else "")

#     # -------------------------------------------------------
#     # MEETING MODE HIGHLIGHT
#     # -------------------------------------------------------
#     def set_meeting_mode(self, active: bool):
#         self.btn_smart.setProperty("meeting", active)
#         self.btn_ai.setProperty("meeting", active)

#         for btn in (self.btn_smart, self.btn_ai):
#             btn.style().unpolish(btn)
#             btn.style().polish(btn)













from PySide6.QtCore import Qt, QSize, QPropertyAnimation, QEasingCurve
from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QGraphicsBlurEffect
from PySide6.QtGui import QIcon


def apply_sidebar_blur(sidebar):
    blur = QGraphicsBlurEffect(sidebar)
    blur.setBlurRadius(18)
    sidebar.setGraphicsEffect(blur)


class Sidebar(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main = main_window

        # Sidebar state
        self.expanded_width = 200
        self.collapsed_width = 56
        self.is_expanded = True

        self.setMinimumWidth(self.expanded_width)
        self.setObjectName("Sidebar")

        # Apply blur only for Light + Blue themes
        if self.main.current_theme in ("light", "blue"):
            apply_sidebar_blur(self)

        # -------------------------
        # MAIN LAYOUT
        # -------------------------
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(8)

        # -------------------------
        # HAMBURGER BUTTON
        # -------------------------
        self.btn_toggle = QPushButton()
        self.btn_toggle.setIcon(QIcon("assets/icons/hamburger.svg"))
        self.btn_toggle.setIconSize(QSize(20, 20))
        self.btn_toggle.setObjectName("HamburgerButton")
        self.btn_toggle.setCursor(Qt.PointingHandCursor)
        self.btn_toggle.clicked.connect(self.toggle_sidebar)
        layout.addWidget(self.btn_toggle)

        # -------------------------
        # NAVIGATION BUTTONS
        # -------------------------
        self.btn_dashboard = self.make_button(
            "Dashboard", "assets/icons/dashboard.svg", self.main.show_dashboard
        )
        self.btn_smart = self.make_button(
            "Smart Mode", "assets/icons/smart_mode.svg", self.main.show_smart
        )
        self.btn_ai = self.make_button(
            "AI Mode", "assets/icons/ai_mode.svg", self.main.show_ai
        )

        self.section_main = self.make_section([
            self.btn_dashboard,
            self.btn_smart,
            self.btn_ai
        ])
        layout.addWidget(self.section_main)

        # -------------------------
        # ANALYTICS SECTION
        # -------------------------
        self.btn_analytics = self.make_button(
            "Analytics", "assets/icons/analytics.svg", self.main.show_analytics
        )
        self.btn_weekly = self.make_button(
            "Weekly Analytics", "assets/icons/weekly_report.svg", self.main.show_weekly
        )
        self.btn_insights = self.make_button(
            "AI Insights", "assets/icons/ai_mode.svg", self.main.show_insights
        )
        self.btn_weekly_report = self.make_button(
            "Weekly Report", "assets/icons/weekly_report.svg", self.main.show_weekly_report
        )
        self.btn_monthly_report = self.make_button(
            "Monthly Report", "assets/icons/monthly_report.svg", self.main.show_monthly_report
        )

        self.section_analytics = self.make_section([
            self.btn_analytics,
            self.btn_weekly,
            self.btn_insights,
            self.btn_weekly_report,
            self.btn_monthly_report
        ])
        layout.addWidget(self.section_analytics)

        layout.addStretch()

        # -------------------------
        # SETTINGS BUTTON
        # -------------------------
        self.btn_settings = self.make_button(
            "Settings", "assets/icons/settings.svg", self.main.show_settings
        )
        self.section_settings = self.make_section([self.btn_settings])
        layout.addWidget(self.section_settings)

        # -------------------------
        # STORE BUTTONS FOR ACTIVE LOGIC
        # -------------------------
        self.buttons = [
            self.btn_dashboard,
            self.btn_smart,
            self.btn_ai,
            self.btn_analytics,
            self.btn_weekly,
            self.btn_insights,
            self.btn_weekly_report,
            self.btn_monthly_report,
            self.btn_settings
        ]

        # Store full text for collapse mode
        for btn in self.buttons:
            btn.setProperty("full_text", btn.text())

    # -------------------------------------------------------
    # CREATE A NAVIGATION BUTTON
    # -------------------------------------------------------
    def make_button(self, text, icon_path, callback):
        btn = QPushButton(text)
        btn.setIcon(QIcon(icon_path))
        btn.setIconSize(QSize(20, 20))
        btn.setCursor(Qt.PointingHandCursor)
        btn.setObjectName("SidebarButton")

        btn.clicked.connect(lambda: self.set_active(btn, callback))
        return btn

    # -------------------------------------------------------
    # CREATE A SECTION BOX
    # -------------------------------------------------------
    def make_section(self, buttons):
        container = QWidget()
        container.setObjectName("SidebarSection")

        v = QVBoxLayout(container)
        v.setContentsMargins(6, 6, 6, 6)
        v.setSpacing(4)

        for b in buttons:
            v.addWidget(b)

        return container

    # -------------------------------------------------------
    # SET ACTIVE BUTTON
    # -------------------------------------------------------
    def set_active(self, btn, callback):
        for b in self.buttons:
            b.setProperty("active", False)
            b.style().unpolish(b)
            b.style().polish(b)

        btn.setProperty("active", True)
        btn.style().unpolish(btn)
        btn.style().polish(btn)

        callback()

    # -------------------------------------------------------
    # ANIMATE SIDEBAR WIDTH
    # -------------------------------------------------------
    def animate_width(self, start, end, duration=250):
        self.anim = QPropertyAnimation(self, b"minimumWidth")
        self.anim.setDuration(duration)
        self.anim.setStartValue(start)
        self.anim.setEndValue(end)
        self.anim.setEasingCurve(QEasingCurve.InOutCubic)
        self.anim.start()

    # -------------------------------------------------------
    # COLLAPSE / EXPAND SIDEBAR
    # -------------------------------------------------------
    def toggle_sidebar(self):
        target_width = self.collapsed_width if self.is_expanded else self.expanded_width
        self.is_expanded = not self.is_expanded

        self.animate_width(self.width(), target_width)

        for btn in self.buttons:
            full_text = btn.property("full_text")
            btn.setText(full_text if self.is_expanded else "")
