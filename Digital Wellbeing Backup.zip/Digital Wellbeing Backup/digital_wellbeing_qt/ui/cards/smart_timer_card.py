from PySide6.QtWidgets import QWidget
from PySide6.QtCore import QSize
from ui.pages.shared.fluent_card import FluentCard
from ui.animations import ValueAnimator, SparklineAnimator
from ui.core.card_registry import CardRegistry
import time


DEFAULT_CARD_WIDTH = 320
LAPTOP_FULL_WIDTH = 680


class SmartTimerCard(FluentCard):
    def __init__(self, height: int | None = None, fullWidthOnLaptop: bool = False, parent: QWidget | None = None):
        super().__init__(
            title="Smart session timer",
            accent_color="#0FB5A9",  # brand teal
            has_spark=True,
        )

        # 🔹 REGISTER WITH REGISTRY
        CardRegistry.register(self)

        self.fullWidthOnLaptop = fullWidthOnLaptop

        if height is not None:
            self.setMinimumHeight(height)

        self.setFixedWidth(DEFAULT_CARD_WIDTH)

        self.setParent(parent)
        self.setProperty("fullWidthOnLaptop", fullWidthOnLaptop)

        self.update_value("00:00")

        self.timer_trend = []
        self.last_seconds = None

    def sizeHint(self) -> QSize:
        if self.fullWidthOnLaptop:
            return QSize(LAPTOP_FULL_WIDTH, self.minimumHeight())
        return QSize(DEFAULT_CARD_WIDTH, self.minimumHeight())

    def closeEvent(self, event):
        CardRegistry.unregister(self)
        super().closeEvent(event)

    def update_from_engine(self, behavior, fatigue, reason, trigger, next_break_seconds, session_start, monitoring):
        if not monitoring or not session_start:
            self.update_value("00:00")
            return

        elapsed = int(time.time() - session_start)

        if elapsed != self.last_seconds:
            self.last_seconds = elapsed
            minutes = elapsed // 60
            seconds = elapsed % 60
            formatted = f"{minutes:02d}:{seconds:02d}"

            ValueAnimator(
                start_value=max(elapsed - 1, 0),
                end_value=elapsed,
                duration=300,
                callback=lambda v: self.update_value(formatted)
            ).start()

        numeric = min(max(int(fatigue), 0), 100)
        self.timer_trend.append(numeric)
        self.timer_trend = self.timer_trend[-30:]

        if self.spark:
            SparklineAnimator(self.spark, "#0FB5A9").animate(self.timer_trend)
