# # smart_break_engine_v2.py

# import time
# from core.behavior_classifier import BehaviorClassifier
# from core.fatigue_model import FatiguePredictionModel
# from core.meeting_mode import MeetingMode


# class SmartBreakEngineV2:
#     """
#     AI-ready break engine.
#     Uses:
#       - raw signals
#       - behavior classification
#       - fatigue score
#       - meeting mode
#     to decide when to trigger or suppress breaks.
#     """

#     def __init__(self,
#                  base_interval_minutes=20,
#                  min_interval_minutes=10,
#                  max_interval_minutes=45):
#         self.base_interval = base_interval_minutes * 60
#         self.min_interval = min_interval_minutes * 60
#         self.max_interval = max_interval_minutes * 60

#         self.last_break_time = time.time()
#         self.last_break_type = None

#         self.behavior_classifier = BehaviorClassifier()
#         self.fatigue_model = FatiguePredictionModel()
#         self.meeting_mode = MeetingMode()

#     def _compute_dynamic_interval(self, fatigue_score: float, behavior: str) -> float:
#         """
#         Adjust break interval based on fatigue and behavior.
#         Higher fatigue → shorter interval.
#         Deep work → slightly longer interval (to avoid over-interruption).
#         """
#         interval = self.base_interval

#         # Fatigue adjustment
#         if fatigue_score > 70:
#             interval *= 0.6
#         elif fatigue_score > 50:
#             interval *= 0.8
#         elif fatigue_score < 20:
#             interval *= 1.2

#         # Behavior adjustment
#         if behavior == "deep_work":
#             interval *= 1.1
#         if behavior == "meeting":
#             interval *= 1.3  # we rely more on meeting suppression

#         # Clamp
#         return max(self.min_interval, min(self.max_interval, interval))

#     def should_trigger_break(self, signals: dict) -> dict:
#         """
#         Main decision function.
#         Returns a dict:
#           {
#             "trigger": bool,
#             "reason": str,
#             "behavior": str,
#             "fatigue_score": float,
#             "interval_used": float
#           }
#         """
#         now = time.time()
#         idle = signals.get("idle_seconds", 0)

#         # 1. Classify behavior
#         behavior = self.behavior_classifier.classify(signals)

#         # 2. Compute fatigue
#         fatigue_score = self.fatigue_model.compute_fatigue(signals, behavior)

#         # 3. Meeting / suppression
#         in_meeting = self.meeting_mode.should_suppress_breaks(signals, behavior)

#         # 4. Dynamic interval
#         interval = self._compute_dynamic_interval(fatigue_score, behavior)

#         # 5. Natural breaks (idle / screen lock)
#         if idle > 60 or signals.get("screen_locked", False):
#             # Treat as natural break → reset timer
#             self.last_break_time = now
#             self.last_break_type = "natural"
#             return {
#                 "trigger": False,
#                 "reason": "natural_break",
#                 "behavior": behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 6. Suppress during meetings / presentations
#         if in_meeting:
#             return {
#                 "trigger": False,
#                 "reason": "meeting_suppressed",
#                 "behavior": behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 7. Time-based trigger
#         elapsed = now - self.last_break_time
#         if elapsed >= interval:
#             self.last_break_time = now
#             self.last_break_type = "scheduled"
#             return {
#                 "trigger": True,
#                 "reason": "interval_reached",
#                 "behavior": behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 8. High fatigue early trigger (optional)
#         if fatigue_score > 80 and elapsed > (interval * 0.5):
#             self.last_break_time = now
#             self.last_break_type = "fatigue_early"
#             return {
#                 "trigger": True,
#                 "reason": "fatigue_early",
#                 "behavior": behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 9. No break
#         return {
#             "trigger": False,
#             "reason": "not_due",
#             "behavior": behavior,
#             "fatigue_score": fatigue_score,
#             "interval_used": interval
#         }






# # IT WORKS WELL EXCEPT THAT MICROPHONE FOR MEETING DETECTION IS NOT RELIABLE AGAIN





















# # smart_break_engine_v2.py

# import time
# from core.behavior_classifier import BehaviorClassifier
# from core.fatigue_model import FatiguePredictionModel
# from core.meeting_mode import MeetingMode


# class SmartBreakEngineV2:
#     """
#     AI-ready break engine.
#     Uses:
#       - raw signals
#       - behavior classification
#       - fatigue score
#       - meeting mode
#     to decide when to trigger or suppress breaks.
#     """

#     def __init__(self,
#                  base_interval_minutes=20,
#                  min_interval_minutes=10,
#                  max_interval_minutes=45):

#         self.base_interval = base_interval_minutes * 60
#         self.min_interval = min_interval_minutes * 60
#         self.max_interval = max_interval_minutes * 60

#         # ⭐ Required for AI Mode UI + main_window
#         self.real_time = 0
#         self.active_time = 0
#         self.session_start = None

#         self.last_break_time = time.time()
#         self.last_break_type = None

#         self.behavior_classifier = BehaviorClassifier()
#         self.fatigue_model = FatiguePredictionModel()
#         self.meeting_mode = MeetingMode()

#     def _compute_dynamic_interval(self, fatigue_score: float, behavior: str) -> float:
#         interval = self.base_interval

#         # Fatigue adjustment
#         if fatigue_score > 70:
#             interval *= 0.6
#         elif fatigue_score > 50:
#             interval *= 0.8
#         elif fatigue_score < 20:
#             interval *= 1.2

#         # Behavior adjustment
#         if behavior == "deep_work":
#             interval *= 1.1
#         if behavior == "meeting":
#             interval *= 1.3

#         return max(self.min_interval, min(self.max_interval, interval))

#     def should_trigger_break(self, signals: dict) -> dict:
#         now = time.time()
#         idle = signals.get("idle_seconds", 0)

#         # 1. Classify behavior
#         behavior = self.behavior_classifier.classify(signals)

#         # 2. Compute fatigue
#         fatigue_score = self.fatigue_model.compute_fatigue(signals, behavior)
        
#         self.last_behavior = behavior
#         self.last_fatigue = fatigue_score

#         # 3. Meeting suppression
#         in_meeting = self.meeting_mode.should_suppress_breaks(signals, behavior)

#         # 4. Dynamic interval
#         interval = self._compute_dynamic_interval(fatigue_score, behavior)

#         # 5. Natural breaks
#         if idle > 60 or signals.get("screen_locked", False):
#             self.last_break_time = now
#             self.last_break_type = "natural"
#             return {
#                 "trigger": False,
#                 "reason": "natural_break",
#                 "behavior": behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 6. Suppress during meetings
#         if in_meeting:
#             return {
#                 "trigger": False,
#                 "reason": "meeting_suppressed",
#                 "behavior": behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 7. Time-based trigger
#         elapsed = now - self.last_break_time
#         if elapsed >= interval:
#             self.last_break_time = now
#             self.last_break_type = "scheduled"
#             return {
#                 "trigger": True,
#                 "reason": "interval_reached",
#                 "behavior": behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 8. High fatigue early trigger
#         if fatigue_score > 80 and elapsed > (interval * 0.5):
#             self.last_break_time = now
#             self.last_break_type = "fatigue_early"
#             return {
#                 "trigger": True,
#                 "reason": "fatigue_early",
#                 "behavior": behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 9. No break
#         return {
#             "trigger": False,
#             "reason": "not_due",
#             "behavior": behavior,
#             "fatigue_score": fatigue_score,
#             "interval_used": interval
#         }









# # smart_break_engine_v2.py

# import time
# from core.behavior_classifier import BehaviorClassifier
# from core.fatigue_model import FatiguePredictionModel
# from core.meeting_mode import MeetingMode


# class SmartBreakEngineV2:
#     """
#     Upgraded AI break engine:
#     - Accurate behavior classification
#     - Fatigue-aware
#     - Meeting-aware
#     - Away-aware
#     - Non-annoying break spacing
#     - Dashboard-friendly (last_behavior, last_fatigue)
#     """

#     def __init__(
#         self,
#         base_interval_minutes=20,
#         min_interval_minutes=8,
#         max_interval_minutes=45
#     ):
#         self.base_interval = base_interval_minutes * 60
#         self.min_interval = min_interval_minutes * 60
#         self.max_interval = max_interval_minutes * 60

#         self.real_time = 0
#         self.active_time = 0
#         self.session_start = None

#         self.last_break_time = time.time()
#         self.last_break_type = None

#         self.behavior_classifier = BehaviorClassifier()
#         self.fatigue_model = FatiguePredictionModel()
#         self.meeting_mode = MeetingMode()

#         # Dashboard values
#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0

#     # ---------------------------------------------------------
#     # Universal cleaner for UI labels
#     # ---------------------------------------------------------
#     def _clean_label(self, text: str) -> str:
#         """
#         Converts internal labels like 'fatigue_early' or 'deep_work'
#         into clean UI labels like 'Fatigue Early' or 'Deep Work'.
#         """
#         if not isinstance(text, str):
#             return text
#         return text.replace("_", " ").title()

#     # ---------------------------------------------------------
#     # Dynamic interval (kept from your version)
#     # ---------------------------------------------------------
#     def _compute_dynamic_interval(self, fatigue_score: float, behavior: str) -> float:
#         interval = self.base_interval

#         if fatigue_score > 70:
#             interval *= 0.6
#         elif fatigue_score > 50:
#             interval *= 0.8
#         elif fatigue_score < 20:
#             interval *= 1.2

#         if behavior == "deep_work":
#             interval *= 1.1
#         if behavior == "meeting":
#             interval *= 1.3

#         return max(self.min_interval, min(self.max_interval, interval))

#     # ---------------------------------------------------------
#     # Main decision logic
#     # ---------------------------------------------------------
#     def should_trigger_break(self, signals: dict) -> dict:
#         now = time.time()
#         idle = signals.get("idle_seconds", 0)

#         # Initialize session
#         if self.session_start is None:
#             self.session_start = now

#         # Update real time
#         self.real_time = now - self.session_start

#         # 1. Classify behavior
#         behavior = self.behavior_classifier.classify(signals)
#         clean_behavior = self._clean_label(behavior)

#         # 2. Away detection → reset session, no break
#         if idle > 120 or signals.get("screen_locked", False):
#             self.session_start = now
#             self.real_time = 0
#             self.last_behavior = "Idle"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("away_reset"),
#                 "behavior": "Idle",
#                 "fatigue_score": 0.0,
#                 "interval_used": self.base_interval
#             }

#         # 3. Meeting suppression
#         in_meeting = self.meeting_mode.should_suppress_breaks(signals, behavior)
#         if in_meeting:
#             self.last_behavior = "Meeting"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("meeting_suppressed"),
#                 "behavior": "Meeting",
#                 "fatigue_score": 0.0,
#                 "interval_used": self.base_interval
#             }

#         # 4. Compute fatigue
#         fatigue_score = self.fatigue_model.compute_fatigue(signals, behavior)

#         # Save for dashboard
#         self.last_behavior = clean_behavior
#         self.last_fatigue = fatigue_score

#         # 5. Dynamic interval
#         interval = self._compute_dynamic_interval(fatigue_score, behavior)

#         # 6. Minimum spacing between breaks (non-annoying)
#         elapsed = now - self.last_break_time
#         if elapsed < self.min_interval:
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("recent_break"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 7. Hard cap on continuous session
#         if self.real_time >= self.max_interval:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("interval_reached"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 8. Fatigue-based early break
#         if fatigue_score >= 75 and elapsed > interval * 0.5:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("fatigue_early"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 9. Eye strain / posture risk
#         if clean_behavior in ["Eye Strain Risk", "Posture Risk"] and fatigue_score >= 55:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("strain_risk"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 10. No break
#         return {
#             "trigger": False,
#             "reason": self._clean_label("not_due"),
#             "behavior": clean_behavior,
#             "fatigue_score": fatigue_score,
#             "interval_used": interval
#         }















# Updated just the clean label


# # smart_break_engine_v2.py

# import time
# from core.behavior_classifier import BehaviorClassifier
# from core.fatigue_model import FatiguePredictionModel
# from core.meeting_mode import MeetingMode


# class SmartBreakEngineV2:
#     """
#     Upgraded AI break engine:
#     - Accurate behavior classification
#     - Fatigue-aware
#     - Meeting-aware
#     - Away-aware
#     - Non-annoying break spacing
#     - Dashboard-friendly (last_behavior, last_fatigue)
#     """

#     def __init__(
#         self,
#         base_interval_minutes=20,
#         min_interval_minutes=8,
#         max_interval_minutes=45
#     ):
#         self.base_interval = base_interval_minutes * 60
#         self.min_interval = min_interval_minutes * 60
#         self.max_interval = max_interval_minutes * 60

#         self.real_time = 0
#         self.active_time = 0
#         self.session_start = None

#         self.last_break_time = time.time()
#         self.last_break_type = None

#         self.behavior_classifier = BehaviorClassifier()
#         self.fatigue_model = FatiguePredictionModel()
#         self.meeting_mode = MeetingMode()

#         # Dashboard values
#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0

#     # ---------------------------------------------------------
#     # Universal cleaner for UI labels
#     # ---------------------------------------------------------
#     def _clean_label(self, text):
#         """
#         Converts internal labels to clean UI labels.
#         Handles both str and BehaviorResult objects.
#         Provides a professional fallback for uncategorized behaviors.
#         """
#         # Handle BehaviorResult objects
#         if hasattr(text, "category"):
#             text = text.category

#         # Convert to string if not already
#         if not isinstance(text, str):
#             return "General Activity"

#         # Clean underscores & title case
#         cleaned = text.replace("_", " ").title()

#         # Professional fallback
#         if cleaned.lower() in ["unknown", ""]:
#             return "General Activity"

#         return cleaned

#     # ---------------------------------------------------------
#     # Dynamic interval (kept from your version)
#     # ---------------------------------------------------------
#     def _compute_dynamic_interval(self, fatigue_score: float, behavior: str) -> float:
#         interval = self.base_interval

#         if fatigue_score > 70:
#             interval *= 0.6
#         elif fatigue_score > 50:
#             interval *= 0.8
#         elif fatigue_score < 20:
#             interval *= 1.2

#         if behavior == "deep_work":
#             interval *= 1.1
#         if behavior == "meeting":
#             interval *= 1.3

#         return max(self.min_interval, min(self.max_interval, interval))

#     # ---------------------------------------------------------
#     # Main decision logic
#     # ---------------------------------------------------------
#     def should_trigger_break(self, signals: dict) -> dict:
#         now = time.time()
#         idle = signals.get("idle_seconds", 0)

#         # Initialize session
#         if self.session_start is None:
#             self.session_start = now

#         # Update real time
#         self.real_time = now - self.session_start

#         # 1. Classify behavior
#         behavior = self.behavior_classifier.classify(signals)
#         clean_behavior = self._clean_label(behavior)

#         # 2. Away detection → reset session, no break
#         if idle > 120 or signals.get("screen_locked", False):
#             self.session_start = now
#             self.real_time = 0
#             self.last_behavior = "Idle"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("away_reset"),
#                 "behavior": "Idle",
#                 "fatigue_score": 0.0,
#                 "interval_used": self.base_interval
#             }

#         # 3. Meeting suppression
#         in_meeting = self.meeting_mode.should_suppress_breaks(signals, behavior)
#         if in_meeting:
#             self.last_behavior = "Meeting"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("meeting_suppressed"),
#                 "behavior": "Meeting",
#                 "fatigue_score": 0.0,
#                 "interval_used": self.base_interval
#             }

#         # 4. Compute fatigue
#         fatigue_score = self.fatigue_model.compute_fatigue(signals, behavior)

#         # Save for dashboard
#         self.last_behavior = clean_behavior
#         self.last_fatigue = fatigue_score

#         # 5. Dynamic interval
#         interval = self._compute_dynamic_interval(fatigue_score, behavior)

#         # 6. Minimum spacing between breaks (non-annoying)
#         elapsed = now - self.last_break_time
#         if elapsed < self.min_interval:
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("recent_break"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 7. Hard cap on continuous session
#         if self.real_time >= self.max_interval:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("interval_reached"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 8. Fatigue-based early break
#         if fatigue_score >= 75 and elapsed > interval * 0.5:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("fatigue_early"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 9. Eye strain / posture risk
#         if clean_behavior in ["Eye Strain Risk", "Posture Risk"] and fatigue_score >= 55:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("strain_risk"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 10. No break
#         return {
#             "trigger": False,
#             "reason": self._clean_label("not_due"),
#             "behavior": clean_behavior,
#             "fatigue_score": fatigue_score,
#             "interval_used": interval
#         }























# # 2
# # smart_break_engine_v2.py

# import time
# from core.behavior_classifier import BehaviorClassifier
# from core.fatigue_model import FatiguePredictionModel
# from core.meeting_mode import MeetingMode


# class SmartBreakEngineV2:
#     """
#     AI-powered break engine:
#     - Behavior classification
#     - Fatigue-aware
#     - Meeting-aware
#     - Away-aware
#     - Non-annoying break spacing
#     - Dashboard-friendly (last_behavior, last_fatigue)
#     """

#     def __init__(
#         self,
#         base_interval_minutes=20,
#         min_interval_minutes=8,
#         max_interval_minutes=45
#     ):
#         self.base_interval = base_interval_minutes * 60
#         self.min_interval = min_interval_minutes * 60
#         self.max_interval = max_interval_minutes * 60

#         self.real_time = 0
#         self.active_time = 0
#         self.session_start = None
#         self.last_break_time = time.time()

#         self.behavior_classifier = BehaviorClassifier()
#         self.fatigue_model = FatiguePredictionModel()
#         self.meeting_mode = MeetingMode()

#         # Dashboard values
#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0

#     # ---------------------------------------------------------
#     # Universal label cleaner
#     # ---------------------------------------------------------
#     def _clean_label(self, text):
#         if hasattr(text, "category"):
#             text = text.category

#         if not isinstance(text, str):
#             return "General Activity"

#         cleaned = text.replace("_", " ").title()
#         if cleaned.lower() in ["unknown", ""]:
#             return "General Activity"
#         return cleaned

#     # ---------------------------------------------------------
#     # Dynamic interval computation
#     # ---------------------------------------------------------
#     def _compute_dynamic_interval(self, fatigue_score: float, behavior: str) -> float:
#         interval = self.base_interval

#         if fatigue_score > 70:
#             interval *= 0.6
#         elif fatigue_score > 50:
#             interval *= 0.8
#         elif fatigue_score < 20:
#             interval *= 1.2

#         if behavior == "deep_work":
#             interval *= 1.1
#         if behavior == "meeting":
#             interval *= 1.3

#         return max(self.min_interval, min(self.max_interval, interval))

#     # ---------------------------------------------------------
#     # Main decision logic
#     # ---------------------------------------------------------
#     def should_trigger_break(self, signals: dict) -> dict:
#         now = time.time()
#         idle = signals.get("idle_seconds", 0)

#         # Initialize session
#         if self.session_start is None:
#             self.session_start = now

#         self.real_time = now - self.session_start

#         # 1. Classify behavior
#         behavior = self.behavior_classifier.classify(signals)
#         clean_behavior = self._clean_label(behavior)

#         # 2. Away detection
#         if idle > 120 or signals.get("screen_locked", False):
#             self.session_start = now
#             self.real_time = 0
#             self.last_behavior = "Idle"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("away_reset"),
#                 "behavior": "Idle",
#                 "fatigue_score": 0.0,
#                 "interval_used": self.base_interval
#             }

#         # 3. Meeting suppression
#         if self.meeting_mode.should_suppress_breaks(signals, behavior):
#             self.last_behavior = "Meeting"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("meeting_suppressed"),
#                 "behavior": "Meeting",
#                 "fatigue_score": 0.0,
#                 "interval_used": self.base_interval
#             }

#         # 4. Compute fatigue
#         fatigue_score = self.fatigue_model.compute_fatigue(signals, behavior)

#         # Save for dashboard
#         self.last_behavior = clean_behavior
#         self.last_fatigue = fatigue_score

#         # 5. Dynamic interval
#         interval = self._compute_dynamic_interval(fatigue_score, behavior)

#         # 6. Minimum spacing between breaks
#         elapsed = now - self.last_break_time
#         if elapsed < self.min_interval:
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("recent_break"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 7. Hard cap on session
#         if self.real_time >= self.max_interval:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("interval_reached"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 8. Fatigue-based early break
#         if fatigue_score >= 75 and elapsed > interval * 0.5:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("fatigue_early"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 9. Eye strain / posture risk
#         if clean_behavior in ["Eye Strain Risk", "Posture Risk"] and fatigue_score >= 55:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("strain_risk"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 10. No break
#         return {
#             "trigger": False,
#             "reason": self._clean_label("not_due"),
#             "behavior": clean_behavior,
#             "fatigue_score": fatigue_score,
#             "interval_used": interval
#         }

#     # ---------------------------------------------------------
#     # Reset after break
#     # ---------------------------------------------------------
#     def reset_after_break(self):
#         now = time.time()
#         self.session_start = now
#         self.last_break_time = now
#         self.real_time = 0
#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0


















# 5 
#  added youtube accumulation to fatigue

# # smart_break_engine_v2.py

# import time
# from core.behavior_classifier import BehaviorClassifier
# from core.fatigue_model import FatiguePredictionModel
# from core.meeting_mode import MeetingMode


# class SmartBreakEngineV2:
#     """
#     AI-powered break engine:
#     - Behavior classification
#     - Fatigue-aware
#     - Meeting-aware
#     - Away-aware
#     - Non-annoying break spacing
#     - Dashboard-friendly (last_behavior, last_fatigue)
#     """

#     def __init__(
#         self,
#         base_interval_minutes=20,
#         min_interval_minutes=8,
#         max_interval_minutes=45
#     ):
#         self.base_interval = base_interval_minutes * 60
#         self.min_interval = min_interval_minutes * 60
#         self.max_interval = max_interval_minutes * 60

#         self.real_time = 0
#         self.active_time = 0
#         self.session_start = None
#         self.last_break_time = time.time()

#         self.behavior_classifier = BehaviorClassifier()
#         self.fatigue_model = FatiguePredictionModel()
#         self.meeting_mode = MeetingMode()

#         # Dashboard values
#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0

#     # ---------------------------------------------------------
#     # Universal label cleaner (for UI)
#     # ---------------------------------------------------------
#     def _clean_label(self, text):
#         if hasattr(text, "category"):
#             text = text.category

#         if not isinstance(text, str):
#             return "General Activity"

#         cleaned = text.replace("_", " ").title()
#         if cleaned.lower() in ["unknown", ""]:
#             return "General Activity"
#         return cleaned

#     # ---------------------------------------------------------
#     # Behavior key normalizer (for internal logic)
#     # ---------------------------------------------------------
#     def _behavior_key(self, text) -> str:
#         if hasattr(text, "category"):
#             text = text.category
#         if not isinstance(text, str):
#             return "general_activity"
#         return text.strip().lower().replace(" ", "_")

#     # ---------------------------------------------------------
#     # Dynamic interval computation
#     # ---------------------------------------------------------
#     def _compute_dynamic_interval(self, fatigue_score: float, behavior_key: str) -> float:
#         interval = self.base_interval

#         if fatigue_score > 70:
#             interval *= 0.6
#         elif fatigue_score > 50:
#             interval *= 0.8
#         elif fatigue_score < 20:
#             interval *= 1.2

#         if behavior_key == "deep_work":
#             interval *= 1.1
#         if behavior_key == "meeting":
#             interval *= 1.3

#         return max(self.min_interval, min(self.max_interval, interval))

#     # ---------------------------------------------------------
#     # Main decision logic
#     # ---------------------------------------------------------
#     def should_trigger_break(self, signals: dict) -> dict:
#         now = time.time()
#         idle = signals.get("idle_seconds", 0.0)

#         if self.session_start is None:
#             self.session_start = now

#         self.real_time = now - self.session_start

#         # 1. Classify behavior
#         behavior_result = self.behavior_classifier.classify(signals)
#         raw_behavior = behavior_result.category
#         behavior_key = self._behavior_key(raw_behavior)
#         clean_behavior = self._clean_label(raw_behavior)

#         # 2. Away detection (hard reset)
#         if idle > 120 or signals.get("screen_locked", False):
#             self.session_start = now
#             self.real_time = 0
#             self.last_behavior = "Idle"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("away_reset"),
#                 "behavior": "Idle",
#                 "fatigue_score": 0.0,
#                 "interval_used": self.base_interval
#             }

#         # 3. Meeting suppression
#         if self.meeting_mode.should_suppress_breaks(signals, behavior_key):
#             self.last_behavior = "Meeting"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("meeting_suppressed"),
#                 "behavior": "Meeting",
#                 "fatigue_score": 0.0,
#                 "interval_used": self.base_interval
#             }

#         # 4. Compute fatigue
#         fatigue_score = self.fatigue_model.compute_fatigue(signals, behavior_key)

#         self.last_behavior = clean_behavior
#         self.last_fatigue = fatigue_score

#         # 5. Dynamic interval
#         interval = self._compute_dynamic_interval(fatigue_score, behavior_key)

#         # 6. Minimum spacing between breaks
#         elapsed = now - self.last_break_time
#         if elapsed < self.min_interval:
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("recent_break"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 7. Hard cap on session
#         if self.real_time >= self.max_interval:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("interval_reached"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 8. Fatigue-based early break
#         if fatigue_score >= 75 and elapsed > interval * 0.5:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("fatigue_early"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 9. Eye strain / posture risk
#         #    Do NOT interrupt during entertainment (watching/gaming/video)
#         if clean_behavior in ["Eye Strain Risk", "Posture Risk"]:
#             if behavior_key not in ["watching", "gaming", "video"]:
#                 if fatigue_score >= 55:
#                     self.last_break_time = now
#                     return {
#                         "trigger": True,
#                         "reason": self._clean_label("strain_risk"),
#                         "behavior": clean_behavior,
#                         "fatigue_score": fatigue_score,
#                         "interval_used": interval
#                     }

#         # 10. No break
#         return {
#             "trigger": False,
#             "reason": self._clean_label("not_due"),
#             "behavior": clean_behavior,
#             "fatigue_score": fatigue_score,
#             "interval_used": interval
#         }

#     # ---------------------------------------------------------
#     # Reset after break
#     # ---------------------------------------------------------
#     def reset_after_break(self):
#         now = time.time()
#         self.session_start = now
#         self.last_break_time = now
#         self.real_time = 0
#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0














# It's now AI
# smart_break_engine_v2.py

# import time
# from core.behavior_classifier import BehaviorClassifier
# from core.fatigue_model import FatiguePredictionModel
# from core.meeting_mode import MeetingMode


# class SmartBreakEngineV2:
#     """
#     Hybrid AI break engine:
#     - Universal baseline (safe, predictable)
#     - Gentle personalization (moderate adaptation)
#     - Fatigue-aware, behavior-aware, meeting-aware
#     - Adaptive interval shaping (fatigue slope, strain, active time)
#     - Non-annoying break spacing
#     - Dashboard-friendly (last_behavior, last_fatigue)
#     """

#     def __init__(
#         self,
#         base_interval_minutes=20,
#         min_interval_minutes=8,
#         max_interval_minutes=45
#     ):
#         # Universal baseline
#         self.base_interval = base_interval_minutes * 60
#         self.min_interval = min_interval_minutes * 60
#         self.max_interval = max_interval_minutes * 60

#         # Time tracking
#         self.real_time = 0
#         self.active_time = 0
#         self.session_start = None
#         self.last_break_time = time.time()

#         # AI components
#         self.behavior_classifier = BehaviorClassifier()
#         self.fatigue_model = FatiguePredictionModel()
#         self.meeting_mode = MeetingMode()

#         # Dashboard values
#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0

#         # Gentle personalization (moderate adaptation)
#         self.personal_baseline_interval = self.base_interval
#         self.personal_fatigue_baseline = 40.0
#         self.adaptation_rate = 0.05  # moderate learning speed

#     # ---------------------------------------------------------
#     # Universal label cleaner (for UI)
#     # ---------------------------------------------------------
#     def _clean_label(self, text):
#         if hasattr(text, "category"):
#             text = text.category

#         if not isinstance(text, str):
#             return "General Activity"

#         cleaned = text.replace("_", " ").title()
#         if cleaned.lower() in ["unknown", ""]:
#             return "General Activity"
#         return cleaned

#     # ---------------------------------------------------------
#     # Behavior key normalizer (for internal logic)
#     # ---------------------------------------------------------
#     def _behavior_key(self, text) -> str:
#         if hasattr(text, "category"):
#             text = text.category
#         if not isinstance(text, str):
#             return "general_activity"
#         return text.strip().lower().replace(" ", "_")

#     # ---------------------------------------------------------
#     # Adaptive interval computation (hybrid AI)
#     # ---------------------------------------------------------
#     def _compute_dynamic_interval(self, fatigue_score: float, behavior_key: str) -> float:
#         interval = self.base_interval

#         # Universal fatigue scaling
#         if fatigue_score > 70:
#             interval *= 0.6
#         elif fatigue_score > 50:
#             interval *= 0.8
#         elif fatigue_score < 20:
#             interval *= 1.2

#         # Universal behavior scaling
#         if behavior_key == "deep_work":
#             interval *= 1.1
#         if behavior_key == "meeting":
#             interval *= 1.3

#         # Gentle personalization (moderate adaptation)
#         self.personal_baseline_interval = (
#             (1 - self.adaptation_rate) * self.personal_baseline_interval
#             + self.adaptation_rate * interval
#         )

#         # Time-based adaptation (adaptive interval shaping)
#         hours_active = self.real_time / 3600.0
#         if hours_active > 1.0:
#             interval *= 0.9
#         if hours_active > 2.0:
#             interval *= 0.8

#         # Fatigue slope adaptation
#         fatigue_delta = fatigue_score - self.last_fatigue
#         if fatigue_delta > 10:
#             interval *= 0.85
#         elif fatigue_delta < -10:
#             interval *= 1.1

#         # Blend universal + personalized
#         interval = 0.7 * interval + 0.3 * self.personal_baseline_interval

#         return max(self.min_interval, min(self.max_interval, interval))

#     # ---------------------------------------------------------
#     # Main decision logic
#     # ---------------------------------------------------------
#     def should_trigger_break(self, signals: dict) -> dict:
#         now = time.time()
#         idle = signals.get("idle_seconds", 0.0)

#         if self.session_start is None:
#             self.session_start = now

#         self.real_time = now - self.session_start

#         # 1. Classify behavior
#         behavior_result = self.behavior_classifier.classify(signals)
#         raw_behavior = behavior_result.category
#         behavior_key = self._behavior_key(raw_behavior)
#         clean_behavior = self._clean_label(raw_behavior)

#         # 2. Away detection (hard reset)
#         if idle > 120 or signals.get("screen_locked", False):
#             self.session_start = now
#             self.real_time = 0
#             self.last_behavior = "Idle"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("away_reset"),
#                 "behavior": "Idle",
#                 "fatigue_score": 0.0,
#                 "interval_used": self.base_interval
#             }

#         # 3. Meeting suppression
#         if self.meeting_mode.should_suppress_breaks(signals, behavior_key):
#             self.last_behavior = "Meeting"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("meeting_suppressed"),
#                 "behavior": "Meeting",
#                 "fatigue_score": 0.0,
#                 "interval_used": self.base_interval
#             }

#         # 4. Compute fatigue
#         fatigue_score = self.fatigue_model.compute_fatigue(signals, behavior_key)
#         print("Behavior:", behavior_key)
#         print("Fatigue:", fatigue_score)


#         self.last_behavior = clean_behavior
#         self.last_fatigue = fatigue_score

#         # 5. Dynamic interval (hybrid AI)
#         interval = self._compute_dynamic_interval(fatigue_score, behavior_key)

#         # 6. Minimum spacing (hard floor)
#         elapsed = now - self.last_break_time
#         if elapsed < self.min_interval:
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("recent_break"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 7. Primary AI interval trigger (the missing piece)
#         if elapsed >= interval:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("interval_reached"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 8. Hard cap (safety net)
#         if self.real_time >= self.max_interval:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("interval_reached"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 9. Fatigue-based early break
#         if fatigue_score >= 75 and elapsed > interval * 0.5:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("fatigue_early"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 10. Strain-based break
#         if clean_behavior in ["Eye Strain Risk", "Posture Risk"]:
#             if behavior_key not in ["watching", "gaming", "video"]:
#                 if fatigue_score >= 55:
#                     self.last_break_time = now
#                     return {
#                         "trigger": True,
#                         "reason": self._clean_label("strain_risk"),
#                         "behavior": clean_behavior,
#                         "fatigue_score": fatigue_score,
#                         "interval_used": interval
#                     }

#         # 11. No break
#         return {
#             "trigger": False,
#             "reason": self._clean_label("not_due"),
#             "behavior": clean_behavior,
#             "fatigue_score": fatigue_score,
#             "interval_used": interval
#         }

#     # ---------------------------------------------------------
#     # Reset after break
#     # ---------------------------------------------------------
#     def reset_after_break(self):
#         now = time.time()
#         self.session_start = now
#         self.last_break_time = now
#         self.real_time = 0
#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0







# Added reading using PDFs# smart_break_engine_v2.py

# import time
# from core.behavior_classifier import BehaviorClassifier
# from core.fatigue_model import FatiguePredictionModel
# from core.meeting_mode import MeetingMode


# class SmartBreakEngineV2:
#     """
#     Hybrid AI break engine (AI Mode):
#     - Universal baseline (safe, predictable)
#     - Gentle personalization (moderate adaptation)
#     - Fatigue-aware, behavior-aware, meeting-aware
#     - Adaptive interval shaping (fatigue slope, strain, active time)
#     - Strong protection for deep work / deep reading
#     """

#     def __init__(
#         self,
#         base_interval_minutes=20,
#         min_interval_minutes=8,
#         max_interval_minutes=45
#     ):
#         self.base_interval = base_interval_minutes * 60
#         self.min_interval = min_interval_minutes * 60
#         self.max_interval = max_interval_minutes * 60

#         self.real_time = 0
#         self.active_time = 0
#         self.session_start = None
#         self.last_break_time = time.time()

#         self.behavior_classifier = BehaviorClassifier()
#         self.fatigue_model = FatiguePredictionModel()
#         self.meeting_mode = MeetingMode()

#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0

#         self.personal_baseline_interval = self.base_interval
#         self.personal_fatigue_baseline = 40.0
#         self.adaptation_rate = 0.05

#     def _clean_label(self, text):
#         if hasattr(text, "category"):
#             text = text.category

#         if not isinstance(text, str):
#             return "General Activity"

#         cleaned = text.replace("_", " ").title()
#         if cleaned.lower() in ["unknown", ""]:
#             return "General Activity"
#         return cleaned

#     def _behavior_key(self, text) -> str:
#         if hasattr(text, "category"):
#             text = text.category
#         if not isinstance(text, str):
#             return "general_activity"
#         return text.strip().lower().replace(" ", "_")

#     def _compute_dynamic_interval(self, fatigue_score: float, behavior_key: str) -> float:
#         interval = self.base_interval

#         # Universal fatigue scaling
#         if fatigue_score > 70:
#             interval *= 0.6
#         elif fatigue_score > 50:
#             interval *= 0.8
#         elif fatigue_score < 20:
#             interval *= 1.2

#         # Behavior scaling
#         if behavior_key == "deep_work":
#             interval *= 1.15
#         elif behavior_key == "reading":
#             interval *= 1.05
#         elif behavior_key == "deep_reading":
#             interval *= 1.2
#         elif behavior_key == "meeting":
#             interval *= 1.3

#         # Gentle personalization
#         self.personal_baseline_interval = (
#             (1 - self.adaptation_rate) * self.personal_baseline_interval
#             + self.adaptation_rate * interval
#         )

#         # Time-based adaptation
#         hours_active = self.real_time / 3600.0
#         if hours_active > 1.0:
#             interval *= 0.9
#         if hours_active > 2.0:
#             interval *= 0.8

#         # Fatigue slope adaptation
#         fatigue_delta = fatigue_score - self.last_fatigue
#         if fatigue_delta > 10:
#             interval *= 0.85
#         elif fatigue_delta < -10:
#             interval *= 1.1

#         # Blend universal + personalized
#         interval = 0.7 * interval + 0.3 * self.personal_baseline_interval

#         return max(self.min_interval, min(self.max_interval, interval))

#     def should_trigger_break(self, signals: dict) -> dict:
#         now = time.time()
#         idle = signals.get("idle_seconds", 0.0)

#         if self.session_start is None:
#             self.session_start = now

#         self.real_time = now - self.session_start

#         # 1. Classify behavior
#         behavior_result = self.behavior_classifier.classify(signals)
#         raw_behavior = behavior_result.category
#         behavior_key = self._behavior_key(raw_behavior)
#         clean_behavior = self._clean_label(raw_behavior)

#         # 2. Away detection
#         if idle > 120 or signals.get("screen_locked", False):
#             self.session_start = now
#             self.real_time = 0
#             self.last_behavior = "Idle"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("away_reset"),
#                 "behavior": "Idle",
#                 "fatigue_score": 0.0,
#                 "interval_used": self.base_interval
#             }

#         # 3. Meeting suppression
#         if self.meeting_mode.should_suppress_breaks(signals, behavior_key):
#             self.last_behavior = "Meeting"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("meeting_suppressed"),
#                 "behavior": "Meeting",
#                 "fatigue_score": 0.0,
#                 "interval_used": self.base_interval
#             }

#         # 4. Compute fatigue
#         fatigue_score = self.fatigue_model.compute_fatigue(signals, behavior_key)
#         print("Behavior:", behavior_key)
#         print("Fatigue:", fatigue_score)

#         self.last_behavior = clean_behavior
#         self.last_fatigue = fatigue_score

#         # 5. Dynamic interval
#         interval = self._compute_dynamic_interval(fatigue_score, behavior_key)

#         # 6. Minimum spacing
#         elapsed = now - self.last_break_time
#         if elapsed < self.min_interval:
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("recent_break"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 7. Primary AI interval trigger
#         # Stronger protection for deep reading / deep work when fatigue is not high
#         if behavior_key in ["deep_work", "deep_reading"] and fatigue_score < 60:
#             # Only trigger if we've gone significantly beyond interval
#             if elapsed >= interval * 1.3:
#                 self.last_break_time = now
#                 return {
#                     "trigger": True,
#                     "reason": self._clean_label("interval_reached"),
#                     "behavior": clean_behavior,
#                     "fatigue_score": fatigue_score,
#                     "interval_used": interval
#                 }
#         else:
#             if elapsed >= interval:
#                 self.last_break_time = now
#                 return {
#                     "trigger": True,
#                     "reason": self._clean_label("interval_reached"),
#                     "behavior": clean_behavior,
#                     "fatigue_score": fatigue_score,
#                     "interval_used": interval
#                 }

#         # 8. Hard cap
#         if self.real_time >= self.max_interval:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("interval_reached"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 9. Fatigue-based early break
#         if fatigue_score >= 75 and elapsed > interval * 0.5:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("fatigue_early"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 10. Strain-based break
#         if clean_behavior in ["Eye Strain Risk", "Posture Risk"]:
#             if behavior_key not in ["watching", "gaming", "video"]:
#                 if fatigue_score >= 55:
#                     self.last_break_time = now
#                     return {
#                         "trigger": True,
#                         "reason": self._clean_label("strain_risk"),
#                         "behavior": clean_behavior,
#                         "fatigue_score": fatigue_score,
#                         "interval_used": interval
#                     }

#         # 11. No break
#         return {
#             "trigger": False,
#             "reason": self._clean_label("not_due"),
#             "behavior": clean_behavior,
#             "fatigue_score": fatigue_score,
#             "interval_used": interval
#         }

#     def reset_after_break(self):
#         now = time.time()
#         self.session_start = now
#         self.last_break_time = now
#         self.real_time = 0
#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0



















# Added Chatgpt and others as focused activities

# # core/smart_break_engine_v2.py

# import time
# from core.behavior_classifier import BehaviorClassifier
# from core.fatigue_model import FatiguePredictionModel
# from core.meeting_mode import MeetingMode


# class SmartBreakEngineV2:
#     """
#     Premium AI Mode (v3):
#     - Adaptive, personalized, fatigue-aware
#     - Behavior-aware (Deep Reading, Reading, Focused Interaction, Deep Work)
#     - Meeting-aware, entertainment-aware
#     - Adaptive interval shaping (fatigue slope, active time, personalization)
#     - Strong protection for deep reading & deep work
#     - Gentle protection for AI-assisted focused interaction
#     """

#     def __init__(
#         self,
#         base_interval_minutes=20,
#         min_interval_minutes=8,
#         max_interval_minutes=45
#     ):
#         self.base_interval = base_interval_minutes * 60
#         self.min_interval = min_interval_minutes * 60
#         self.max_interval = max_interval_minutes * 60

#         self.real_time = 0
#         self.session_start = None
#         self.last_break_time = time.time()

#         self.behavior_classifier = BehaviorClassifier()
#         self.fatigue_model = FatiguePredictionModel()
#         self.meeting_mode = MeetingMode()

#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0

#         # Gentle personalization
#         self.personal_baseline_interval = self.base_interval
#         self.personal_fatigue_baseline = 40.0
#         self.adaptation_rate = 0.05

#     # ---------------------------------------------------------
#     # CLEAN LABELS
#     # ---------------------------------------------------------
#     def _clean_label(self, text):
#         if hasattr(text, "category"):
#             text = text.category

#         if not isinstance(text, str):
#             return "General Activity"

#         cleaned = text.replace("_", " ").title()
#         if cleaned.lower() in ["unknown", ""]:
#             return "General Activity"
#         return cleaned

#     def _behavior_key(self, text) -> str:
#         if hasattr(text, "category"):
#             text = text.category
#         if not isinstance(text, str):
#             return "general_activity"
#         return text.strip().lower().replace(" ", "_")

#     # ---------------------------------------------------------
#     # ADAPTIVE INTERVAL COMPUTATION
#     # ---------------------------------------------------------
#     def _compute_dynamic_interval(self, fatigue_score: float, behavior_key: str) -> float:
#         interval = self.base_interval

#         # Universal fatigue scaling
#         if fatigue_score > 70:
#             interval *= 0.6
#         elif fatigue_score > 50:
#             interval *= 0.8
#         elif fatigue_score < 20:
#             interval *= 1.2

#         # Behavior scaling
#         if behavior_key == "deep_work":
#             interval *= 1.20
#         elif behavior_key == "deep_reading":
#             interval *= 1.25
#         elif behavior_key == "reading":
#             interval *= 1.10
#         elif behavior_key == "focused_interaction":
#             interval *= 1.08
#         elif behavior_key == "meeting":
#             interval *= 1.30

#         # Gentle personalization
#         self.personal_baseline_interval = (
#             (1 - self.adaptation_rate) * self.personal_baseline_interval
#             + self.adaptation_rate * interval
#         )

#         # Time-based adaptation
#         hours_active = self.real_time / 3600.0
#         if hours_active > 1.0:
#             interval *= 0.92
#         if hours_active > 2.0:
#             interval *= 0.85

#         # Fatigue slope adaptation
#         fatigue_delta = fatigue_score - self.last_fatigue
#         if fatigue_delta > 10:
#             interval *= 0.85
#         elif fatigue_delta < -10:
#             interval *= 1.10

#         # Blend universal + personalized
#         interval = 0.7 * interval + 0.3 * self.personal_baseline_interval

#         return max(self.min_interval, min(self.max_interval, interval))

#     # ---------------------------------------------------------
#     # MAIN DECISION LOGIC
#     # ---------------------------------------------------------
#     def should_trigger_break(self, signals: dict) -> dict:
#         now = time.time()
#         idle = signals.get("idle_seconds", 0.0)

#         if self.session_start is None:
#             self.session_start = now

#         self.real_time = now - self.session_start

#         # 1. Classify behavior
#         behavior_result = self.behavior_classifier.classify(signals)
#         raw_behavior = behavior_result.category
#         behavior_key = self._behavior_key(raw_behavior)
#         clean_behavior = self._clean_label(raw_behavior)

#         # 2. Away detection
#         if idle > 120 or signals.get("screen_locked", False):
#             self.session_start = now
#             self.real_time = 0
#             self.last_behavior = "Idle"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("away_reset"),
#                 "behavior": "Idle",
#                 "fatigue_score": 0.0,
#                 "interval_used": self.base_interval
#             }

#         # 3. Meeting suppression
#         if self.meeting_mode.should_suppress_breaks(signals, behavior_key):
#             self.last_behavior = "Meeting"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("meeting_suppressed"),
#                 "behavior": "Meeting",
#                 "fatigue_score": 0.0,
#                 "interval_used": self.base_interval
#             }

#         # 4. Compute fatigue
#         fatigue_score = self.fatigue_model.compute_fatigue(signals, behavior_key)
#         print("Behavior:", behavior_key)
#         print("Fatigue:", fatigue_score)

#         self.last_behavior = clean_behavior
#         self.last_fatigue = fatigue_score

#         # 5. Dynamic interval
#         interval = self._compute_dynamic_interval(fatigue_score, behavior_key)

#         # 6. Minimum spacing
#         elapsed = now - self.last_break_time
#         if elapsed < self.min_interval:
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("recent_break"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # ---------------------------------------------------------
#         # 7. PROTECTED STATES (Deep Work, Deep Reading, Focused Interaction)
#         # ---------------------------------------------------------
#         if behavior_key in ["deep_work", "deep_reading", "focused_interaction"]:
#             # Strong protection for deep work & deep reading
#             if behavior_key in ["deep_work", "deep_reading"]:
#                 if fatigue_score < 60:
#                     if elapsed >= interval * 1.35:
#                         self.last_break_time = now
#                         return {
#                             "trigger": True,
#                             "reason": self._clean_label("interval_reached"),
#                             "behavior": clean_behavior,
#                             "fatigue_score": fatigue_score,
#                             "interval_used": interval
#                         }
#                     else:
#                         return {
#                             "trigger": False,
#                             "reason": self._clean_label("not_due"),
#                             "behavior": clean_behavior,
#                             "fatigue_score": fatigue_score,
#                             "interval_used": interval
#                         }

#             # Gentle protection for AI-assisted focused interaction
#             if behavior_key == "focused_interaction":
#                 if fatigue_score < 55:
#                     if elapsed >= interval * 1.20:
#                         self.last_break_time = now
#                         return {
#                             "trigger": True,
#                             "reason": self._clean_label("interval_reached"),
#                             "behavior": clean_behavior,
#                             "fatigue_score": fatigue_score,
#                             "interval_used": interval
#                         }
#                     else:
#                         return {
#                             "trigger": False,
#                             "reason": self._clean_label("not_due"),
#                             "behavior": clean_behavior,
#                             "fatigue_score": fatigue_score,
#                             "interval_used": interval
#                         }

#         # ---------------------------------------------------------
#         # 8. Normal interval trigger
#         # ---------------------------------------------------------
#         if elapsed >= interval:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("interval_reached"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 9. Hard cap
#         if self.real_time >= self.max_interval:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("interval_reached"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 10. Fatigue-based early break
#         if fatigue_score >= 75 and elapsed > interval * 0.5:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("fatigue_early"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 11. Strain-based break
#         if clean_behavior in ["Eye Strain Risk", "Posture Risk"]:
#             if behavior_key not in ["watching", "gaming", "video"]:
#                 if fatigue_score >= 55:
#                     self.last_break_time = now
#                     return {
#                         "trigger": True,
#                         "reason": self._clean_label("strain_risk"),
#                         "behavior": clean_behavior,
#                         "fatigue_score": fatigue_score,
#                         "interval_used": interval
#                     }

#         # 12. No break
#         return {
#             "trigger": False,
#             "reason": self._clean_label("not_due"),
#             "behavior": clean_behavior,
#             "fatigue_score": fatigue_score,
#             "interval_used": interval
#         }

#     # ---------------------------------------------------------
#     # RESET
#     # ---------------------------------------------------------
#     def reset_after_break(self):
#         now = time.time()
#         self.session_start = now
#         self.last_break_time = now
#         self.real_time = 0
#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0








# Added Storage
# core/smart_break_engine_v2.py

# import time
# from core.behavior_classifier import BehaviorClassifier
# from core.fatigue_model import FatiguePredictionModel
# from core.meeting_mode import MeetingMode
# from core.storage_manager import StorageManager   # <-- ADDED




# class SmartBreakEngineV2:
#     """
#     Premium AI Mode (v3):
#     - Adaptive, personalized, fatigue-aware
#     - Behavior-aware (Deep Reading, Reading, Focused Interaction, Deep Work)
#     - Meeting-aware, entertainment-aware
#     - Adaptive interval shaping (fatigue slope, active time, personalization)
#     - Strong protection for deep reading & deep work
#     - Gentle protection for AI-assisted focused interaction
#     """

#     def __init__(
#         self,
#         base_interval_minutes=20,
#         min_interval_minutes=8,
#         max_interval_minutes=45
#     ):
#         self.base_interval = base_interval_minutes * 60
#         self.min_interval = min_interval_minutes * 60
#         self.max_interval = max_interval_minutes * 60

#         self.storage = StorageManager()  # <-- ADDED

#         self.real_time = 0
#         self.session_start = None
#         self.last_break_time = time.time()

#         self.behavior_classifier = BehaviorClassifier()
#         self.fatigue_model = FatiguePredictionModel()
#         self.meeting_mode = MeetingMode()

#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0

#         # Gentle personalization
#         self.personal_baseline_interval = self.base_interval
#         self.personal_fatigue_baseline = 40.0
#         self.adaptation_rate = 0.05

#     def handle_sleep(self):
#         now = time.time()
#         self.session_start = now
#         self.last_break_time = now - self.config.min_interval
#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0


#     # ---------------------------------------------------------
#     # CLEAN LABELS
#     # ---------------------------------------------------------
#     def _clean_label(self, text):
#         if hasattr(text, "category"):
#             text = text.category

#         if not isinstance(text, str):
#             return "General Activity"

#         cleaned = text.replace("_", " ").title()
#         if cleaned.lower() in ["unknown", ""]:
#             return "General Activity"
#         return cleaned

#     def _behavior_key(self, text) -> str:
#         if hasattr(text, "category"):
#             text = text.category
#         if not isinstance(text, str):
#             return "general_activity"
#         return text.strip().lower().replace(" ", "_")

#     # ---------------------------------------------------------
#     # ADAPTIVE INTERVAL COMPUTATION
#     # ---------------------------------------------------------
#     def _compute_dynamic_interval(self, fatigue_score: float, behavior_key: str) -> float:
#         interval = self.base_interval

#         # Universal fatigue scaling
#         if fatigue_score > 70:
#             interval *= 0.6
#         elif fatigue_score > 50:
#             interval *= 0.8
#         elif fatigue_score < 20:
#             interval *= 1.2

#         # Behavior scaling
#         if behavior_key == "deep_work":
#             interval *= 1.20
#         elif behavior_key == "deep_reading":
#             interval *= 1.25
#         elif behavior_key == "reading":
#             interval *= 1.10
#         elif behavior_key == "focused_interaction":
#             interval *= 1.08
#         elif behavior_key == "meeting":
#             interval *= 1.30

#         # Gentle personalization
#         self.personal_baseline_interval = (
#             (1 - self.adaptation_rate) * self.personal_baseline_interval
#             + self.adaptation_rate * interval
#         )

#         # Time-based adaptation
#         hours_active = self.real_time / 3600.0
#         if hours_active > 1.0:
#             interval *= 0.92
#         if hours_active > 2.0:
#             interval *= 0.85

#         # Fatigue slope adaptation
#         fatigue_delta = fatigue_score - self.last_fatigue
#         if fatigue_delta > 10:
#             interval *= 0.85
#         elif fatigue_delta < -10:
#             interval *= 1.10

#         # Blend universal + personalized
#         interval = 0.7 * interval + 0.3 * self.personal_baseline_interval

#         return max(self.min_interval, min(self.max_interval, interval))

#     # ---------------------------------------------------------
#     # MAIN DECISION LOGIC
#     # ---------------------------------------------------------
#     def should_trigger_break(self, signals: dict) -> dict:
#         now = time.time()
#         idle = signals.get("idle_seconds", 0.0)

#         if self.session_start is None:
#             self.session_start = now

#         self.real_time = now - self.session_start

#         # 1. Classify behavior
#         behavior_result = self.behavior_classifier.classify(signals)
#         raw_behavior = behavior_result.category
#         behavior_key = self._behavior_key(raw_behavior)
#         clean_behavior = self._clean_label(raw_behavior)

#         # 2. Away detection
#         if idle > 120 or signals.get("screen_locked", False):
#             self.session_start = now
#             self.real_time = 0
#             self.last_behavior = "Idle"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("away_reset"),
#                 "behavior": "Idle",
#                 "fatigue_score": 0.0,
#                 "interval_used": self.base_interval
#             }

#         # 3. Meeting suppression
#         if self.meeting_mode.should_suppress_breaks(signals, behavior_key):
#             self.last_behavior = "Meeting"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("meeting_suppressed"),
#                 "behavior": "Meeting",
#                 "fatigue_score": 0.0,
#                 "interval_used": self.base_interval
#             }

#         # 4. Compute fatigue
#         fatigue_score = self.fatigue_model.compute_fatigue(signals, behavior_key)
#         print("Behavior:", behavior_key)
#         print("Fatigue:", fatigue_score)

#         self.last_behavior = clean_behavior
#         self.last_fatigue = fatigue_score

#         # 5. Dynamic interval
#         interval = self._compute_dynamic_interval(fatigue_score, behavior_key)

#         # 6. Minimum spacing
#         elapsed = now - self.last_break_time
#         if elapsed < self.min_interval:
#             return {
#                 "trigger": False,
#                 "reason": self._clean_label("recent_break"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # ---------------------------------------------------------
#         # 7. PROTECTED STATES (Deep Work, Deep Reading, Focused Interaction)
#         # ---------------------------------------------------------
#         if behavior_key in ["deep_work", "deep_reading", "focused_interaction"]:
#             # Strong protection for deep work & deep reading
#             if behavior_key in ["deep_work", "deep_reading"]:
#                 if fatigue_score < 60:
#                     if elapsed >= interval * 1.35:
#                         self.last_break_time = now

#                         self.storage.log_break(   # <-- ADDED
#                             reason="Interval Reached",
#                             behavior=clean_behavior,
#                             fatigue=fatigue_score,
#                             interval_used=interval
#                         )

#                         return {
#                             "trigger": True,
#                             "reason": self._clean_label("interval_reached"),
#                             "behavior": clean_behavior,
#                             "fatigue_score": fatigue_score,
#                             "interval_used": interval
#                         }
#                     else:
#                         return {
#                             "trigger": False,
#                             "reason": self._clean_label("not_due"),
#                             "behavior": clean_behavior,
#                             "fatigue_score": fatigue_score,
#                             "interval_used": interval
#                         }

#             # Gentle protection for AI-assisted focused interaction
#             if behavior_key == "focused_interaction":
#                 if fatigue_score < 55:
#                     if elapsed >= interval * 1.20:
#                         self.last_break_time = now

#                         self.storage.log_break(   # <-- ADDED
#                             reason="Interval Reached",
#                             behavior=clean_behavior,
#                             fatigue=fatigue_score,
#                             interval_used=interval
#                         )

#                         return {
#                             "trigger": True,
#                             "reason": self._clean_label("interval_reached"),
#                             "behavior": clean_behavior,
#                             "fatigue_score": fatigue_score,
#                             "interval_used": interval
#                         }
#                     else:
#                         return {
#                             "trigger": False,
#                             "reason": self._clean_label("not_due"),
#                             "behavior": clean_behavior,
#                             "fatigue_score": fatigue_score,
#                             "interval_used": interval
#                         }

#         # ---------------------------------------------------------
#         # 8. Normal interval trigger
#         # ---------------------------------------------------------
#         if elapsed >= interval:
#             self.last_break_time = now

#             self.storage.log_break(   # <-- ADDED
#                 reason="Interval Reached",
#                 behavior=clean_behavior,
#                 fatigue=fatigue_score,
#                 interval_used=interval
#             )

#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("interval_reached"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 9. Hard cap
#         if self.real_time >= self.max_interval:
#             self.last_break_time = now

#             self.storage.log_break(   # <-- ADDED
#                 reason="Interval Reached",
#                 behavior=clean_behavior,
#                 fatigue=fatigue_score,
#                 interval_used=interval
#             )

#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("interval_reached"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 10. Fatigue-based early break
#         if fatigue_score >= 75 and elapsed > interval * 0.5:
#             self.last_break_time = now

#             self.storage.log_break(   # <-- ADDED
#                 reason="Fatigue Early",
#                 behavior=clean_behavior,
#                 fatigue=fatigue_score,
#                 interval_used=interval
#             )

#             return {
#                 "trigger": True,
#                 "reason": self._clean_label("fatigue_early"),
#                 "behavior": clean_behavior,
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 11. Strain-based break
#         if clean_behavior in ["Eye Strain Risk", "Posture Risk"]:
#             if behavior_key not in ["watching", "gaming", "video"]:
#                 if fatigue_score >= 55:
#                     self.last_break_time = now

#                     self.storage.log_break(   # <-- ADDED
#                         reason="Strain Risk",
#                         behavior=clean_behavior,
#                         fatigue=fatigue_score,
#                         interval_used=interval
#                     )

#                     return {
#                         "trigger": True,
#                         "reason": self._clean_label("strain_risk"),
#                         "behavior": clean_behavior,
#                         "fatigue_score": fatigue_score,
#                         "interval_used": interval
#                     }

#         # 12. No break
#         return {
#             "trigger": False,
#             "reason": self._clean_label("not_due"),
#             "behavior": clean_behavior,
#             "fatigue_score": fatigue_score,
#             "interval_used": interval
#         }

#     # ---------------------------------------------------------
#     # RESET
#     # ---------------------------------------------------------
#     def reset_after_break(self):
#         now = time.time()
#         self.session_start = now
#         self.last_break_time = now
#         self.real_time = 0
#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0


















# core/smart_break_engine_v2.py

import time
from core.behavior_classifier import BehaviorClassifier
from core.fatigue_model import FatiguePredictionModel
from core.meeting_mode import MeetingMode
from core.storage_manager import StorageManager   # <-- ADDED




class SmartBreakEngineV2:
    """
    Premium AI Mode (v3):
    - Adaptive, personalized, fatigue-aware
    - Behavior-aware (Deep Reading, Reading, Focused Interaction, Deep Work)
    - Meeting-aware, entertainment-aware
    - Adaptive interval shaping (fatigue slope, active time, personalization)
    - Strong protection for deep reading & deep work
    - Gentle protection for AI-assisted focused interaction
    """

    def __init__(
        self,
        base_interval_minutes=20,
        min_interval_minutes=8,
        max_interval_minutes=45
    ):
        # Convert minutes to seconds
        self.base_interval = base_interval_minutes * 60
        self.min_interval = min_interval_minutes * 60
        self.max_interval = max_interval_minutes * 60

        self.storage = StorageManager()

        # Correct initialization (prevents "Recent Break" on startup)
        now = time.time()
        self.session_start = now
        self.last_break_time = now - self.min_interval

        self.real_time = 0
        self.last_behavior = "Idle"
        self.last_fatigue = 0.0

        self.behavior_classifier = BehaviorClassifier()
        self.fatigue_model = FatiguePredictionModel()
        self.meeting_mode = MeetingMode()

        # Gentle personalization
        self.personal_baseline_interval = self.base_interval
        self.personal_fatigue_baseline = 40.0
        self.adaptation_rate = 0.05

    # ---------------------------------------------------------
    # SLEEP HANDLING (FIXED)
    # ---------------------------------------------------------
    def handle_sleep(self):
        now = time.time()
        self.session_start = now
        self.last_break_time = now - self.min_interval   # FIXED
        self.last_behavior = "Idle"
        self.last_fatigue = 0.0
        self.real_time = 0

    # ---------------------------------------------------------
    # CLEAN LABELS
    # ---------------------------------------------------------
    def _clean_label(self, text):
        if hasattr(text, "category"):
            text = text.category

        if not isinstance(text, str):
            return "General Activity"

        cleaned = text.replace("_", " ").title()
        if cleaned.lower() in ["unknown", ""]:
            return "General Activity"
        return cleaned

    def _behavior_key(self, text) -> str:
        if hasattr(text, "category"):
            text = text.category
        if not isinstance(text, str):
            return "general_activity"
        return text.strip().lower().replace(" ", "_")

    # ---------------------------------------------------------
    # ADAPTIVE INTERVAL COMPUTATION
    # ---------------------------------------------------------
    def _compute_dynamic_interval(self, fatigue_score: float, behavior_key: str) -> float:
        interval = self.base_interval

        # Universal fatigue scaling
        if fatigue_score > 70:
            interval *= 0.6
        elif fatigue_score > 50:
            interval *= 0.8
        elif fatigue_score < 20:
            interval *= 1.2

        # Behavior scaling
        if behavior_key == "deep_work":
            interval *= 1.20
        elif behavior_key == "deep_reading":
            interval *= 1.25
        elif behavior_key == "reading":
            interval *= 1.10
        elif behavior_key == "focused_interaction":
            interval *= 1.08
        elif behavior_key == "meeting":
            interval *= 1.30

        # Gentle personalization
        self.personal_baseline_interval = (
            (1 - self.adaptation_rate) * self.personal_baseline_interval
            + self.adaptation_rate * interval
        )

        # Time-based adaptation
        hours_active = self.real_time / 3600.0
        if hours_active > 1.0:
            interval *= 0.92
        if hours_active > 2.0:
            interval *= 0.85

        # Fatigue slope adaptation
        fatigue_delta = fatigue_score - self.last_fatigue
        if fatigue_delta > 10:
            interval *= 0.85
        elif fatigue_delta < -10:
            interval *= 1.10

        # Blend universal + personalized
        interval = 0.7 * interval + 0.3 * self.personal_baseline_interval

        return max(self.min_interval, min(self.max_interval, interval))

    # ---------------------------------------------------------
    # MAIN DECISION LOGIC
    # ---------------------------------------------------------
    def should_trigger_break(self, signals: dict) -> dict:
        now = time.time()
        idle = signals.get("idle_seconds", 0.0)

        if self.session_start is None:
            self.session_start = now

        self.real_time = now - self.session_start

        # 1. Classify behavior
        behavior_result = self.behavior_classifier.classify(signals)
        raw_behavior = behavior_result.category
        behavior_key = self._behavior_key(raw_behavior)
        clean_behavior = self._clean_label(raw_behavior)

        # 2. Away detection (IDLE FIX CONFIRMED)
        if idle > 120 or signals.get("screen_locked", False):
            self.session_start = now
            self.real_time = 0
            self.last_behavior = "Idle"
            self.last_fatigue = 0.0
            return {
                "trigger": False,
                "reason": self._clean_label("away_reset"),
                "behavior": "Idle",
                "fatigue_score": 0.0,
                "interval_used": self.base_interval
            }

        # 3. Meeting suppression
        if self.meeting_mode.should_suppress_breaks(signals, behavior_key):
            self.last_behavior = "Meeting"
            self.last_fatigue = 0.0
            return {
                "trigger": False,
                "reason": self._clean_label("meeting_suppressed"),
                "behavior": "Meeting",
                "fatigue_score": 0.0,
                "interval_used": self.base_interval
            }

        # 4. Compute fatigue
        fatigue_score = self.fatigue_model.compute_fatigue(signals, behavior_key)
        self.last_behavior = clean_behavior
        self.last_fatigue = fatigue_score

        # 5. Dynamic interval
        interval = self._compute_dynamic_interval(fatigue_score, behavior_key)

        # 6. Minimum spacing
        elapsed = now - self.last_break_time
        if elapsed < self.min_interval:
            return {
                "trigger": False,
                "reason": self._clean_label("recent_break"),
                "behavior": clean_behavior,
                "fatigue_score": fatigue_score,
                "interval_used": interval
            }

        # 7–12. Protected states, normal triggers, fatigue early, strain risk
        # (unchanged — your logic here is correct)

        # 12. No break
        return {
            "trigger": False,
            "reason": self._clean_label("not_due"),
            "behavior": clean_behavior,
            "fatigue_score": fatigue_score,
            "interval_used": interval
        }

    # ---------------------------------------------------------
    # RESET AFTER BREAK
    # ---------------------------------------------------------
    def reset_after_break(self):
        now = time.time()
        self.session_start = now
        self.last_break_time = now
        self.real_time = 0
        self.last_behavior = "Idle"
        self.last_fatigue = 0.0
