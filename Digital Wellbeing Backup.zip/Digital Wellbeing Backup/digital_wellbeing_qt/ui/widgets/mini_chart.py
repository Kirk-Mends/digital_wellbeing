# import pyqtgraph as pg
# from PySide6.QtWidgets import QWidget, QVBoxLayout
# from PySide6.QtCore import Qt


# class MiniChart(QWidget):
#     def __init__(self, parent=None):
#         super().__init__(parent)

#         self.setObjectName("MiniChart")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(0, 0, 0, 0)

#         # PyQtGraph plot widget
#         self.plot = pg.PlotWidget()
#         self.plot.setBackground(None)  # transparent for acrylic
#         self.plot.setMenuEnabled(False)
#         self.plot.hideButtons()
#         self.plot.showGrid(x=False, y=False)

#         # Remove axes
#         self.plot.getAxis("left").setVisible(False)
#         self.plot.getAxis("bottom").setVisible(False)

#         # Smooth line
#         self.curve = self.plot.plot(
#             [],
#             [],
#             pen=pg.mkPen(color=(0, 120, 215), width=2),
#             antialias=True
#         )

#         layout.addWidget(self.plot)

#     # -------------------------
#     # UPDATE CHART DATA
#     # -------------------------
#     def update_data(self, x_values, y_values):
#         self.curve.setData(x_values, y_values)



















# import pyqtgraph as pg
# from PySide6.QtWidgets import QWidget, QVBoxLayout
# from PySide6.QtCore import Qt


# class MiniChart(QWidget):
#     def __init__(self, parent=None):
#         super().__init__(parent)

#         self.setObjectName("MiniChart")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(0, 0, 0, 0)

#         # PyQtGraph plot widget
#         self.plot = pg.PlotWidget()
#         self.plot.setBackground(None)  # transparent for acrylic
#         self.plot.setMenuEnabled(False)
#         self.plot.hideButtons()
#         self.plot.showGrid(x=False, y=False)

#         # Remove axes
#         self.plot.getAxis("left").setVisible(False)
#         self.plot.getAxis("bottom").setVisible(False)

#         # Data storage
#         self.x = []
#         self.y = []
#         self.max_points = 40  # smooth sparkline length

#         # Smooth line
#         self.curve = self.plot.plot(
#             [],
#             [],
#             pen=pg.mkPen(color=(0, 120, 215), width=2),
#             antialias=True
#         )

#         layout.addWidget(self.plot)

#     # -------------------------
#     # ADD A NEW POINT
#     # -------------------------
#     def add_point(self, value):
#         if value is None:
#             return

#         self.y.append(float(value))
#         self.x.append(len(self.y))

#         if len(self.y) > self.max_points:
#             self.y.pop(0)
#             self.x.pop(0)

#         self.curve.setData(self.x, self.y)

#     # -------------------------
#     # OPTIONAL: SET LINE COLOR
#     # -------------------------
#     def set_color(self, r, g, b):
#         self.curve.setPen(pg.mkPen(color=(r, g, b), width=2))























# import pyqtgraph as pg
# from PySide6.QtWidgets import QWidget, QVBoxLayout


# class MiniChart(QWidget):
#     def __init__(self, parent=None):
#         super().__init__(parent)

#         self.setObjectName("MiniChart")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(0, 0, 0, 0)

#         # Plot widget
#         self.plot = pg.PlotWidget()
#         self.plot.setBackground(None)
#         self.plot.setMenuEnabled(False)
#         self.plot.hideButtons()
#         self.plot.showGrid(x=False, y=False)

#         # Hide axes
#         self.plot.getAxis("left").setVisible(False)
#         self.plot.getAxis("bottom").setVisible(False)

#         # Data
#         self.values = []
#         self.max_points = 60  # smoother longer trend

#         # Curve
#         self.curve = self.plot.plot(
#             [],
#             [],
#             pen=pg.mkPen(color=(0, 120, 215), width=2),
#             antialias=True
#         )

#         layout.addWidget(self.plot)

#     # -----------------------------------
#     # ADD POINT (FIXED SMOOTH LOGIC)
#     # -----------------------------------
#     def add_point(self, value):
#         if value is None:
#             return

#         value = float(value)

#         self.values.append(value)

#         if len(self.values) > self.max_points:
#             self.values.pop(0)

#         x_values = list(range(len(self.values)))

#         self.curve.setData(x_values, self.values)

#         # Auto-scale Y nicely
#         if len(self.values) > 1:
#             self.plot.setYRange(min(self.values), max(self.values), padding=0.3)

#     # -----------------------------------
#     # OPTIONAL: CHANGE LINE COLOR
#     # -----------------------------------
#     def set_color(self, r, g, b):
#         self.curve.setPen(pg.mkPen(color=(r, g, b), width=2))











# 5 
# upgrade for dashboard

# ui/widgets/mini_chart.py
# ui/widgets/mini_chart.py

import pyqtgraph as pg
from PySide6.QtWidgets import QWidget, QVBoxLayout
from PySide6.QtCore import QTimer, QEasingCurve


class MiniChart(QWidget):
    """
    Premium mini sparkline chart with:
      - smooth anti-aliased line
      - soft glow
      - gradient fill
      - easing animation (compatible with all PySide6 versions)
      - no axes or borders
    """

    def __init__(self, color="#4A90E2"):
        super().__init__()

        self.data = []
        self.max_points = 40
        self.color = color

        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)

        # Create plot
        self.plot = pg.PlotWidget()
        self.plot.setBackground(None)
        self.plot.setFixedHeight(70)

        # Remove axes
        self.plot.hideAxis("left")
        self.plot.hideAxis("bottom")

        # Premium line style
        pen = pg.mkPen(color, width=2, cosmetic=True)
        self.curve = self.plot.plot([], pen=pen)

        # Glow effect (second line behind)
        glow_pen = pg.mkPen(color, width=8, cosmetic=True)
        glow_pen.setColor(pg.mkColor(color).lighter(150))
        self.glow = self.plot.plot([], pen=glow_pen)

        # Gradient fill under line
        self.fill_bottom = pg.PlotCurveItem([], pen=None)
        self.fill = pg.FillBetweenItem(
            self.curve,
            self.fill_bottom,
            brush=pg.mkBrush(pg.mkColor(color).lighter(180))
        )
        self.plot.addItem(self.fill)

        layout.addWidget(self.plot)

        # Animation timer
        self.anim_timer = QTimer()
        self.anim_timer.setInterval(16)  # ~60 FPS
        self.anim_timer.timeout.connect(self.animate_step)

        self.anim_progress = 0
        self.anim_start = []
        self.anim_end = []

    # ---------------------------------------------------------
    # Add a new point with animation
    # ---------------------------------------------------------
    def add_point(self, value):
        # Convert to float to avoid string math errors
        try:
            value = float(value)
        except:
            return  # ignore invalid values

        self.data.append(value)
        if len(self.data) > self.max_points:
            self.data.pop(0)

        # Prepare animation
        ydata = self.curve.getData()[1]
        self.anim_start = ydata.tolist() if ydata is not None else []
        self.anim_end = self.data.copy()
        self.anim_progress = 0

        self.anim_timer.start()

    # ---------------------------------------------------------
    # Animation step (fixed for all PySide6 versions)
    # ---------------------------------------------------------
    def animate_step(self):
        if not self.anim_start:
            self.anim_start = [0] * len(self.anim_end)

        self.anim_progress += 0.08
        if self.anim_progress >= 1:
            self.anim_progress = 1
            self.anim_timer.stop()

        # FIXED easing curve (works on all PySide6 versions)
        easing = QEasingCurve(QEasingCurve.OutCubic)
        eased = easing.valueForProgress(self.anim_progress)

        # Interpolate values
        interp = []
        for i in range(len(self.anim_end)):
            start = self.anim_start[i] if i < len(self.anim_start) else self.anim_end[i]
            end = self.anim_end[i]
            interp.append(start + (end - start) * eased)

        # Update curves
        x = list(range(len(interp)))
        self.curve.setData(x, interp)
        self.glow.setData(x, interp)

        # Update fill baseline
        self.fill_bottom.setData(x, [0] * len(interp))
