# class Reminder:
#     def send_break_message(self):
#         print("\nYou've been active for a while. Consider taking a short break.\n")

# The code below uses the plyer library to send a desktop notification instead of printing a message to the console. This allows for a more user-friendly reminder that can be seen even if the user is not actively looking at the console.
# from plyer import notification

# class Reminder:
#     def send_break_message(self):
#         notification.notify(
#             title="Break Reminder",
#             message="You've been active for a while. Consider taking a short break.",
#             timeout=5
#         )



# from winotify import Notification, audio

# class Reminder:
#     def send_break_message(self):
#         toast = Notification(
#             app_id="Digital Wellbeing Assistant",
#             title="Break Reminder",
#             msg="You've been active for a while. Consider taking a short break.",
#             duration="long",
#             icon="icon.png"   # <-- correct way to set icon
#             #icon="icon.ico"
#         )
        
#         toast.set_audio(audio.Reminder, loop=False)

#         toast.add_actions(label="Snooze 2 min", launch="python snooze_2.py")
#         toast.add_actions(label="Snooze 3 min", launch="python snooze_3.py")
#         toast.add_actions(label="Open Analytics", launch="python app.py --analytics")
#         toast.add_actions(label="Dismiss", launch="")

#         toast.show()




# import os
# import sys
# from winotify import Notification, audio

# def resource_path(relative_path):
#     """
#     Get absolute path to resource, works for dev and for PyInstaller.
#     """
#     if hasattr(sys, '_MEIPASS'):
#         # Running inside PyInstaller bundle
#         return os.path.join(sys._MEIPASS, relative_path)
#     # Running normally (python app.py)
#     return os.path.join(os.path.abspath("."), relative_path)


# class Reminder:
#     def send_break_message(self):
#         # Correctly locate icon for both Python and EXE
#         icon_path = resource_path("icon.png")

#         toast = Notification(
#             app_id="Digital Wellbeing Assistant",
#             title="Break Reminder",
#             msg="You've been active for a while. Consider taking a short break.",
#             duration="long",
#             icon=icon_path
#         )

#         toast.set_audio(audio.Reminder, loop=False)

#         toast.add_actions(label="Snooze 2 min", launch="python snooze_2.py")
#         toast.add_actions(label="Snooze 3 min", launch="python snooze_3.py")
#         toast.add_actions(label="Open Analytics", launch="python app.py --analytics")
#         toast.add_actions(label="Dismiss", launch="")

#         toast.show()










# import os
# import sys
# os.system("")  # ensure process is toast-capable on Windows

# from winotify import Notification, audio
# from settings import SettingsManager

# settings = SettingsManager()


# def resource_path(relative_path: str) -> str:
#     """
#     Get absolute path to resource, works for dev and for PyInstaller.
#     """
#     if hasattr(sys, "_MEIPASS"):
#         return os.path.join(sys._MEIPASS, relative_path)
#     return os.path.join(os.path.abspath("."), relative_path)


# class Reminder:
#     def send_break_message(self):
#         icon_path = resource_path("icon.png")

#         toast = Notification(
#             app_id="Digital Wellbeing Assistant",
#             title="Break Reminder",
#             msg="You've been active for a while. Consider taking a short break.",
#             duration="long",
#             icon=icon_path,
#         )

#         if settings.get("sound_on"):
#             toast.set_audio(audio.Reminder, loop=False)
#         else:
#             toast.set_audio(None)

#         toast.add_actions(label="Snooze 2 min", launch="python snooze_2.py")
#         toast.add_actions(label="Snooze 3 min", launch="python snooze_3.py")
#         toast.add_actions(label="Open Analytics", launch="python app.py --analytics")
#         toast.add_actions(label="Dismiss", launch="")

#         toast.show()



# import os
# import sys
# os.system("")  # ensures Windows toast compatibility

# from winotify import Notification, audio
# from settings import SettingsManager

# settings = SettingsManager()


# def resource_path(relative_path):
#     if hasattr(sys, "_MEIPASS"):
#         return os.path.join(sys._MEIPASS, relative_path)
#     return os.path.join(os.path.abspath("."), relative_path)


# class Reminder:
#     def send_break_message(self):
#         icon_path = resource_path("icon.png")

#         toast = Notification(
#             app_id="Digital Wellbeing Assistant",
#             title="Break Reminder",
#             msg="You've been active for a while. Consider taking a short break.",
#             duration="long",
#             icon=icon_path
#         )

#         if settings.get("sound_on"):
#             toast.set_audio(audio.Reminder, loop=False)
#         else:
#             toast.set_audio(None)

#         toast.add_actions(label="Snooze 2 min", launch="python snooze_2.py")
#         toast.add_actions(label="Snooze 3 min", launch="python snooze_3.py")
#         toast.add_actions(label="Open Analytics", launch="python app.py --analytics")
#         toast.add_actions(label="Dismiss", launch="")

#         toast.show()











# # reminder.py
# import os
# import sys
# import time
# import traceback
# import tkinter as tk
# from tkinter import messagebox

# # ensure Windows console compatibility (keeps your original line)
# os.system("")

# # Try to import winotify; if unavailable we'll fall back to messagebox
# try:
#     from winotify import Notification, audio
#     WINOTIFY_AVAILABLE = True
# except Exception:
#     WINOTIFY_AVAILABLE = False

# from settings import SettingsManager

# settings = SettingsManager()


# def resource_path(relative_path):
#     if hasattr(sys, "_MEIPASS"):
#         return os.path.join(sys._MEIPASS, relative_path)
#     return os.path.join(os.path.abspath("."), relative_path)


# class Reminder:
#     def __init__(self, min_interval_seconds=5):
#         """
#         min_interval_seconds: minimum seconds between notifications to avoid
#         spawning many processes in a short time.
#         """
#         self.min_interval = float(min_interval_seconds)
#         self._last_toast = 0.0

#     def _show_toast(self, title, msg, icon_path=None):
#         """
#         Build and show a Windows toast using winotify.
#         This method may raise OSError if the system cannot create a process.
#         """
#         if not WINOTIFY_AVAILABLE:
#             raise RuntimeError("winotify not available")

#         toast = Notification(
#             app_id="Digital Wellbeing Assistant",
#             title=title,
#             msg=msg,
#             duration="long",
#             icon=icon_path
#         )

#         # sound setting from global settings manager
#         if settings.get("sound_on"):
#             try:
#                 toast.set_audio(audio.Reminder, loop=False)
#             except Exception:
#                 # if audio constant not available or fails, ignore
#                 pass
#         else:
#             try:
#                 toast.set_audio(None)
#             except Exception:
#                 pass

#         # Keep the same actions you had; these launch external scripts when clicked.
#         # Note: launching external scripts will create processes when the action is used.
#         try:
#             toast.add_actions(label="Snooze 2 min", launch="python snooze_2.py")
#             toast.add_actions(label="Snooze 3 min", launch="python snooze_3.py")
#             toast.add_actions(label="Open Analytics", launch="python app.py --analytics")
#             toast.add_actions(label="Dismiss", launch="")
#         except Exception:
#             # If adding actions fails for any reason, continue without actions
#             pass

#         # This call spawns a PowerShell process internally
#         toast.show()

#     def send_break_message(self):
#         """
#         Public method to send a break reminder. Throttles repeated calls,
#         tries winotify first, falls back to tkinter.messagebox on failure.
#         """
#         now = time.time()
#         if now - self._last_toast < self.min_interval:
#             return

#         title = "Break Reminder"
#         msg = "You've been active for a while. Consider taking a short break."
#         icon_path = resource_path("icon.png")

#         try:
#             if WINOTIFY_AVAILABLE:
#                 try:
#                     self._show_toast(title, msg, icon_path)
#                 except OSError:
#                     # Likely system resource / CreateProcess failure; fallback to messagebox
#                     try:
#                         root = tk._default_root
#                         if root:
#                             messagebox.showinfo(title, msg, parent=root)
#                         else:
#                             tmp = tk.Tk()
#                             tmp.withdraw()
#                             messagebox.showinfo(title, msg, parent=tmp)
#                             tmp.destroy()
#                     except Exception:
#                         print("Reminder fallback:", title, msg)
#                         traceback.print_exc()
#                 except Exception:
#                     # Any other winotify error -> fallback
#                     try:
#                         root = tk._default_root
#                         if root:
#                             messagebox.showinfo(title, msg, parent=root)
#                         else:
#                             tmp = tk.Tk()
#                             tmp.withdraw()
#                             messagebox.showinfo(title, msg, parent=tmp)
#                             tmp.destroy()
#                     except Exception:
#                         print("Reminder fallback:", title, msg)
#                         traceback.print_exc()
#             else:
#                 # winotify not available: use messagebox
#                 root = tk._default_root
#                 if root:
#                     messagebox.showinfo(title, msg, parent=root)
#                 else:
#                     tmp = tk.Tk()
#                     tmp.withdraw()
#                     messagebox.showinfo(title, msg, parent=tmp)
#                     tmp.destroy()
#         finally:
#             # update last toast time even if fallback used, to avoid rapid repeats
#             self._last_toast = time.time()







# import os
# import sys
# import time
# import traceback
# import tkinter as tk
# from tkinter import messagebox

# from ui.widgets.toast import Toast

# # Try to import winotify
# try:
#     from winotify import Notification, audio
#     WINOTIFY_AVAILABLE = True
# except Exception:
#     WINOTIFY_AVAILABLE = False

# from core.settings import SettingsManager

# settings = SettingsManager()


# def resource_path(relative_path):
#     if hasattr(sys, "_MEIPASS"):
#         return os.path.join(sys._MEIPASS, relative_path)
#     return os.path.join(os.path.abspath("."), relative_path)


# class Reminder:
#     def __init__(self, main_window, min_interval_seconds=5):
#         self.main_window = main_window
#         self.min_interval = float(min_interval_seconds)
#         self._last_toast = 0.0
#         self.break_count = 0


#     def _show_winotify(self, title, msg, icon_path=None):
#         if not WINOTIFY_AVAILABLE:
#             raise RuntimeError("winotify not available")

#         toast = Notification(
#             app_id="Digital Wellbeing Assistant",
#             title=title,
#             msg=msg,
#             duration="long",
#             icon=icon_path
#         )

#         if settings.get("sound_on"):
#             try:
#                 toast.set_audio(audio.Reminder, loop=False)
#             except Exception:
#                 pass
#         else:
#             try:
#                 toast.set_audio(None)
#             except Exception:
#                 pass

#         try:
#             toast.add_actions(label="Snooze 2 min", launch="python snooze_2.py")
#             toast.add_actions(label="Snooze 3 min", launch="python snooze_3.py")
#             toast.add_actions(label="Open Analytics", launch="python app.py --analytics")
#             toast.add_actions(label="Dismiss", launch="")
#         except Exception:
#             pass

#         toast.show()

#     def send_break_message(self, custom_message=None):
#         now = time.time()
#         self.break_count += 1

#         if now - self._last_toast < self.min_interval:
#             return

#         # AI or default message
#         message = custom_message or "Time for a break!"

#         # -------------------------
#         # 1. Fluent Toast (always)
#         # -------------------------
#         toast = Toast(message, parent=self.main_window)
#         toast.show_toast()

#         # -------------------------
#         # 2. Winotify (optional)
#         # -------------------------
#         title = "Break Reminder"
#         msg = custom_message if custom_message else \
#             "You've been active for a while. Consider taking a short break."
#         icon_path = resource_path("icon.png")

#         try:
#             if WINOTIFY_AVAILABLE:
#                 self._show_winotify(title, msg, icon_path)
#             else:
#                 raise RuntimeError("winotify not available")
#         except Exception:
#             # -------------------------
#             # 3. Fallback: messagebox
#             # -------------------------
#             try:
#                 root = tk._default_root
#                 if root:
#                     messagebox.showinfo(title, msg, parent=root)
#                 else:
#                     tmp = tk.Tk()
#                     tmp.withdraw()
#                     messagebox.showinfo(title, msg, parent=tmp)
#                     tmp.destroy()
#             except Exception:
#                 print("Reminder fallback:", title, msg)
#                 traceback.print_exc()

#         finally:
#             self._last_toast = time.time()















# # 2

# # reminder.py

# import os
# import sys
# import time
# import traceback
# import random
# import tkinter as tk
# from tkinter import messagebox

# from ui.widgets.toast import Toast
# from core.settings import SettingsManager
# from core.ai_reminder_messages import AIMessageGenerator

# # Try to import winotify
# try:
#     from winotify import Notification, audio
#     WINOTIFY_AVAILABLE = True
# except Exception:
#     WINOTIFY_AVAILABLE = False

# settings = SettingsManager()


# def resource_path(relative_path):
#     if hasattr(sys, "_MEIPASS"):
#         return os.path.join(sys._MEIPASS, relative_path)
#     return os.path.join(os.path.abspath("."), relative_path)


# class Reminder:
#     SMART_MESSAGES = [
#         "Time to stretch your legs!",
#         "Take a quick breather.",
#         "Stand up and move around for a bit.",
#         "A short break helps your focus!",
#         "Relax your eyes for a moment."
#     ]

#     def __init__(self, main_window, min_interval_seconds=5):
#         self.main_window = main_window
#         self.min_interval = float(min_interval_seconds)
#         self._last_toast = 0.0
#         self.break_count = 0
#         self.ai_generator = AIMessageGenerator()

#     def _show_winotify(self, title, msg, icon_path=None):
#         if not WINOTIFY_AVAILABLE:
#             raise RuntimeError("winotify not available")

#         toast = Notification(
#             app_id="Digital Wellbeing Assistant",
#             title=title,
#             msg=msg,
#             duration="long",
#             icon=icon_path
#         )

#         if settings.get("sound_on"):
#             try:
#                 toast.set_audio(audio.Reminder, loop=False)
#             except Exception:
#                 pass
#         else:
#             try:
#                 toast.set_audio(None)
#             except Exception:
#                 pass

#         try:
#             toast.add_actions(label="Snooze 2 min", launch="python snooze_2.py")
#             toast.add_actions(label="Snooze 3 min", launch="python snooze_3.py")
#             toast.add_actions(label="Open Analytics", launch="python app.py --analytics")
#             toast.add_actions(label="Dismiss", launch="")
#         except Exception:
#             pass

#         toast.show()

#     def send_break_message(self, custom_message=None):
#         now = time.time()
#         self.break_count += 1

#         # Rate limit
#         if now - self._last_toast < self.min_interval:
#             return

#         # Determine message
#         if custom_message:
#             message = custom_message  # AI mode
#         else:
#             # Smart mode: pick random message
#             message = random.choice(self.SMART_MESSAGES)

#         # -------------------------
#         # 1. Fluent Toast (always)
#         # -------------------------
#         toast = Toast(message, parent=self.main_window)
#         toast.show_toast()

#         # -------------------------
#         # 2. Winotify (optional)
#         # -------------------------
#         title = "Break Reminder"
#         msg = message
#         icon_path = resource_path("icon.png")

#         try:
#             if WINOTIFY_AVAILABLE:
#                 self._show_winotify(title, msg, icon_path)
#         except Exception:
#             # -------------------------
#             # 3. Fallback: Tkinter messagebox
#             # -------------------------
#             try:
#                 root = tk._default_root
#                 if root:
#                     messagebox.showinfo(title, msg, parent=root)
#                 else:
#                     tmp = tk.Tk()
#                     tmp.withdraw()
#                     messagebox.showinfo(title, msg, parent=tmp)
#                     tmp.destroy()
#             except Exception:
#                 print("Reminder fallback:", title, msg)
#                 traceback.print_exc()
#         finally:
#             self._last_toast = time.time()










# 2.1
# # reminder.py

# import os
# import sys
# import time
# import traceback
# import tkinter as tk
# from tkinter import messagebox

# from PySide6.QtCore import Qt, QTimer
# from PySide6.QtWidgets import QLabel, QWidget, QVBoxLayout

# from ui.widgets.toast import Toast  # existing toast fallback

# # Try to import winotify
# try:
#     from winotify import Notification, audio
#     WINOTIFY_AVAILABLE = True
# except Exception:
#     WINOTIFY_AVAILABLE = False

# from core.settings import SettingsManager

# settings = SettingsManager()


# def resource_path(relative_path):
#     """Get absolute path for PyInstaller or local."""
#     if hasattr(sys, "_MEIPASS"):
#         return os.path.join(sys._MEIPASS, relative_path)
#     return os.path.join(os.path.abspath("."), relative_path)


# class AnimatedToast(QWidget):
#     """Custom animated toast for in-app notifications using GIFs."""
#     def __init__(self, message, gif_path=None, parent=None, duration=5000):
#         super().__init__(parent)
#         self.setWindowFlags(self.windowFlags() |
#                             Qt.FramelessWindowHint |
#                             Qt.WindowStaysOnTopHint |
#                             Qt.Tool)
#         self.setAttribute(Qt.WA_TranslucentBackground)

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(10, 10, 10, 10)

#         # Message label
#         self.label = QLabel(message)
#         self.label.setStyleSheet("color: white; font-size: 16px; font-weight: bold;")
#         self.label.setWordWrap(True)
#         layout.addWidget(self.label)

#         # Animated GIF
#         self.movie = None
#         if gif_path and os.path.exists(gif_path):
#             from PySide6.QtGui import QMovie
#             self.movie = QMovie(gif_path)
#             self.gif_label = QLabel()
#             self.gif_label.setMovie(self.movie)
#             layout.addWidget(self.gif_label)
#             self.movie.start()

#         # Auto-close timer
#         QTimer.singleShot(duration, self.close)
#         self.show()


# class Reminder:
#     """Central break reminder handler supporting AI & Smart modes with animation."""
#     def __init__(self, main_window, min_interval_seconds=5):
#         self.main_window = main_window
#         self.min_interval = float(min_interval_seconds)
#         self._last_toast = 0.0
#         self.break_count = 0

#     # -------------------------
#     # WINOTIFY NOTIFICATION
#     # -------------------------
#     def _show_winotify(self, title, msg, icon_path=None):
#         if not WINOTIFY_AVAILABLE:
#             return

#         toast = Notification(
#             app_id="Digital Wellbeing Assistant",
#             title=title,
#             msg=msg,
#             duration="long",
#             icon=icon_path
#         )

#         if settings.get("sound_on"):
#             try:
#                 toast.set_audio(audio.Reminder, loop=False)
#             except Exception:
#                 pass
#         else:
#             try:
#                 toast.set_audio(None)
#             except Exception:
#                 pass

#         try:
#             toast.add_actions(label="Snooze 2 min", launch="python snooze_2.py")
#             toast.add_actions(label="Snooze 3 min", launch="python snooze_3.py")
#             toast.add_actions(label="Open Analytics", launch="python app.py --analytics")
#             toast.add_actions(label="Dismiss", launch="")
#         except Exception:
#             pass

#         toast.show()

#     # -------------------------
#     # SEND BREAK MESSAGE
#     # -------------------------
#     def send_break_message(self, custom_message=None, gif_path=None):
#         """Send a break reminder with optional animation and custom text."""
#         now = time.time()
#         self.break_count += 1

#         if now - self._last_toast < self.min_interval:
#             return

#         # -------------------------
#         # 1. Determine message text
#         # -------------------------
#         if not custom_message:
#             # Smart Mode default messages
#             if self.main_window.pages.currentWidget() == self.main_window.smart_page:
#                 custom_message = "Time for a micro-break! Stretch and relax."
#             # AI Mode dynamic messages
#             elif self.main_window.pages.currentWidget() == self.main_window.ai_page:
#                 behavior = getattr(self.main_window.ai_engine, "last_behavior", "Idle")
#                 fatigue = getattr(self.main_window.ai_engine, "last_fatigue", 0)
#                 if fatigue > 75:
#                     custom_message = f"High fatigue detected! Take a longer break now."
#                 elif behavior.lower() in ["deep_work", "coding"]:
#                     custom_message = "Deep focus session ongoing. Consider a micro-break."
#                 else:
#                     custom_message = "It's time to take a short break."
#             else:
#                 custom_message = "Time for a break!"

#         # -------------------------
#         # 2. In-App animated toast
#         # -------------------------
#         try:
#             toast_widget = AnimatedToast(
#                 message=custom_message,
#                 gif_path=gif_path,
#                 parent=self.main_window,
#                 duration=5000
#             )
#         except Exception:
#             # fallback to simple toast
#             toast = Toast(custom_message, parent=self.main_window)
#             toast.show_toast()

#         # -------------------------
#         # 3. System notification (winotify)
#         # -------------------------
#         title = "Break Reminder"
#         msg = custom_message
#         icon_path = resource_path("assets/icons/icon.png")
#         try:
#             if WINOTIFY_AVAILABLE:
#                 self._show_winotify(title, msg, icon_path)
#         except Exception:
#             # -------------------------
#             # 4. Fallback: Tkinter messagebox
#             # -------------------------
#             try:
#                 root = tk._default_root
#                 if root:
#                     messagebox.showinfo(title, msg, parent=root)
#                 else:
#                     tmp = tk.Tk()
#                     tmp.withdraw()
#                     messagebox.showinfo(title, msg, parent=tmp)
#                     tmp.destroy()
#             except Exception:
#                 print("Reminder fallback:", title, msg)
#                 traceback.print_exc()

#         finally:
#             self._last_toast = time.time()





















# 5
# upgraded Completely

# reminder.py — Premium, behavior-aware, warm-tone break reminders

import os
import sys
import time
import traceback
import tkinter as tk
from tkinter import messagebox

from PySide6.QtCore import Qt, QTimer
from PySide6.QtWidgets import QLabel, QWidget, QVBoxLayout

from ui.widgets.toast import Toast  # fallback toast

# Try to import winotify
try:
    from winotify import Notification, audio
    WINOTIFY_AVAILABLE = True
except Exception:
    WINOTIFY_AVAILABLE = False

from core.settings import SettingsManager
settings = SettingsManager()


def resource_path(relative_path):
    """Get absolute path for PyInstaller or local."""
    if hasattr(sys, "_MEIPASS"):
        return os.path.join(sys._MEIPASS, relative_path)
    return os.path.join(os.path.abspath("."), relative_path)


class AnimatedToast(QWidget):
    """Custom animated toast for in-app notifications using GIFs."""
    def __init__(self, message, gif_path=None, parent=None, duration=5000):
        super().__init__(parent)
        self.setWindowFlags(self.windowFlags() |
                            Qt.FramelessWindowHint |
                            Qt.WindowStaysOnTopHint |
                            Qt.Tool)
        self.setAttribute(Qt.WA_TranslucentBackground)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(10, 10, 10, 10)

        # Message label
        self.label = QLabel(message)
        self.label.setStyleSheet("color: white; font-size: 16px; font-weight: bold;")
        self.label.setWordWrap(True)
        layout.addWidget(self.label)

        # Animated GIF
        self.movie = None
        if gif_path and os.path.exists(gif_path):
            from PySide6.QtGui import QMovie
            self.movie = QMovie(gif_path)
            self.gif_label = QLabel()
            self.gif_label.setMovie(self.movie)
            layout.addWidget(self.gif_label)
            self.movie.start()

        # Auto-close timer
        QTimer.singleShot(duration, self.close)
        self.show()


class Reminder:
    """Premium break reminder handler for Smart Mode & AI Mode."""
    def __init__(self, main_window, min_interval_seconds=5):
        self.main_window = main_window
        self.min_interval = float(min_interval_seconds)
        self._last_toast = 0.0
        self.break_count = 0

    # ---------------------------------------------------------
    # WINOTIFY NOTIFICATION (clean, no snooze)
    # ---------------------------------------------------------
    def _show_winotify(self, title, msg, icon_path=None):
        if not WINOTIFY_AVAILABLE:
            return

        toast = Notification(
            app_id="Digital Wellbeing Assistant",
            title=title,
            msg=msg,
            duration="long",
            icon=icon_path
        )

        # Sound
        if settings.get("sound_on"):
            try:
                toast.set_audio(audio.Reminder, loop=False)
            except Exception:
                pass
        else:
            try:
                toast.set_audio(None)
            except Exception:
                pass

        # Clean actions (no snooze, no analytics)
        try:
            toast.add_actions(label="Skip this break", launch="python skip_break.py")
            toast.add_actions(label="Open Insights", launch="python app.py --insights")
        except Exception:
            pass

        toast.show()

    # ---------------------------------------------------------
    # SEND BREAK MESSAGE (behavior-aware, warm tone)
    # ---------------------------------------------------------
    def send_break_message(self, engine_output: dict, gif_path=None):
        """
        engine_output must contain:
        - behavior (clean label)
        - reason (clean label)
        - message (warm tone)
        - interval_used
        - last_break_time (from engine)
        """
        now = time.time()
        if now - self._last_toast < self.min_interval:
            return

        self.break_count += 1

        # Extract engine output
        behavior = engine_output.get("behavior", "Activity")
        reason = engine_output.get("reason", "")
        message = engine_output.get("message", "Take a moment to pause.")
        interval_used = engine_output.get("interval_used", 20 * 60)
        last_break_time = engine_output.get("last_break_time", now)

        # Time until next break
        elapsed = now - last_break_time
        remaining = max(0, int((interval_used - elapsed) / 60))
        next_break_text = f"Next break in {remaining} minutes." if remaining > 0 else ""

        # Premium headline
        headline = f"{behavior} — {reason}" if reason else behavior

        # Final popup text
        popup_text = f"{headline}\n{message}\n{next_break_text}".strip()

        # ---------------------------------------------------------
        # In-App animated toast
        # ---------------------------------------------------------
        try:
            AnimatedToast(
                message=popup_text,
                gif_path=gif_path,
                parent=self.main_window,
                duration=6000
            )
        except Exception:
            # fallback
            toast = Toast(popup_text, parent=self.main_window)
            toast.show_toast()

        # ---------------------------------------------------------
        # System notification (winotify)
        # ---------------------------------------------------------
        try:
            if WINOTIFY_AVAILABLE:
                icon_path = resource_path("assets/icons/icon.png")
                self._show_winotify("Break Reminder", popup_text, icon_path)
        except Exception:
            # Fallback: Tkinter messagebox
            try:
                root = tk._default_root
                if root:
                    messagebox.showinfo("Break Reminder", popup_text, parent=root)
                else:
                    tmp = tk.Tk()
                    tmp.withdraw()
                    messagebox.showinfo("Break Reminder", popup_text, parent=tmp)
                    tmp.destroy()
            except Exception:
                print("Reminder fallback:", popup_text)
                traceback.print_exc()

        finally:
            self._last_toast = time.time()
