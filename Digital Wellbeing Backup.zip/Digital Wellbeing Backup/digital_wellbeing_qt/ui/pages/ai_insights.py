# import csv
# from datetime import datetime, timedelta
# from statistics import mean

# from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QFrame, QHBoxLayout
# from PySide6.QtCore import Qt


# class AIInsightsPage(QWidget):
#     def __init__(self):
#         super().__init__()
#         self.setObjectName("AIInsightsPage")

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         # Title
#         title = QLabel("AI Insights")
#         title.setObjectName("PageTitle")
#         layout.addWidget(title)

#         # Container for insight cards
#         self.insight_container = QVBoxLayout()
#         layout.addLayout(self.insight_container)

#         # Load insights immediately
#         self.generate_insights()

#     # -------------------------
#     # CREATE A CARD
#     # -------------------------
#     def make_card(self, text):
#         frame = QFrame()
#         frame.setObjectName("InsightCard")

#         v = QVBoxLayout(frame)
#         v.setContentsMargins(16, 16, 16, 16)

#         label = QLabel(text)
#         label.setWordWrap(True)
#         label.setObjectName("InsightText")

#         v.addWidget(label)
#         return frame

#     # -------------------------
#     # LOAD DATA + GENERATE INSIGHTS
#     # -------------------------
#     def generate_insights(self):
#         insights = []

#         # Load usage log
#         data = self.load_usage()

#         if not data:
#             insights.append("No activity data available yet.")
#         else:
#             insights.extend(self.analyze_usage(data))

#         # Clear old cards
#         while self.insight_container.count():
#             item = self.insight_container.takeAt(0)
#             if item.widget():
#                 item.widget().deleteLater()

#         # Add new cards
#         for text in insights:
#             self.insight_container.addWidget(self.make_card(text))

#     # -------------------------
#     # LOAD CSV
#     # -------------------------
#     def load_usage(self):
#         try:
#             with open("usage_log.csv", "r") as f:
#                 reader = csv.DictReader(f)
#                 return list(reader)
#         except FileNotFoundError:
#             return []

#     # -------------------------
#     # ANALYSIS LOGIC
#     # -------------------------
#     def analyze_usage(self, rows):
#         insights = []

#         # Convert rows
#         parsed = []
#         for r in rows:
#             try:
#                 parsed.append({
#                     "date": datetime.fromisoformat(r["date"]),
#                     "active": float(r["active_minutes"])
#                 })
#             except:
#                 pass

#         if not parsed:
#             return ["Not enough data to generate insights."]

#         # 1. Average active minutes
#         avg = mean([p["active"] for p in parsed])
#         insights.append(f"Your average active time per day is {avg:.1f} minutes.")

#         # 2. Best productivity day
#         by_day = {}
#         for p in parsed:
#             day = p["date"].strftime("%A")
#             by_day.setdefault(day, []).append(p["active"])

#         best_day = max(by_day, key=lambda d: mean(by_day[d]))
#         insights.append(f"Your most productive day is typically **{best_day}**.")

#         # 3. Evening productivity drop
#         evening = [p for p in parsed if p["date"].hour >= 21]
#         if evening:
#             avg_evening = mean([p["active"] for p in evening])
#             if avg_evening < avg * 0.5:
#                 insights.append("Your productivity drops significantly after 9 PM.")

#         # 4. Weekend pattern
#         weekend = [p for p in parsed if p["date"].weekday() >= 5]
#         if weekend:
#             avg_weekend = mean([p["active"] for p in weekend])
#             if avg_weekend < avg * 0.7:
#                 insights.append("You tend to be less active on weekends.")

#         # 5. Consistency score
#         daily_totals = {}
#         for p in parsed:
#             d = p["date"].date()
#             daily_totals.setdefault(d, 0)
#             daily_totals[d] += p["active"]

#         if len(daily_totals) >= 5:
#             diffs = []
#             days = sorted(daily_totals.keys())
#             for i in range(1, len(days)):
#                 diffs.append(abs(daily_totals[days[i]] - daily_totals[days[i-1]]))

#             consistency = max(0, 100 - mean(diffs))
#             insights.append(f"Your break consistency score is {consistency:.0f}/100.")

#         return insights















# 5 new design

import csv
from datetime import datetime
from collections import Counter, defaultdict
from statistics import mean

from PySide6.QtWidgets import QWidget, QVBoxLayout, QLabel, QFrame
from PySide6.QtCore import Qt


class AIInsightsPage(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("AIInsightsPage")

        layout = QVBoxLayout(self)
        layout.setContentsMargins(20, 20, 20, 20)
        layout.setSpacing(20)

        title = QLabel("AI Insights")
        title.setObjectName("PageTitle")
        layout.addWidget(title)

        self.insight_container = QVBoxLayout()
        layout.addLayout(self.insight_container)

        self.generate_insights()

    # -------------------------
    # CARD FACTORY
    # -------------------------
    def make_card(self, text: str) -> QFrame:
        frame = QFrame()
        frame.setObjectName("InsightCard")

        v = QVBoxLayout(frame)
        v.setContentsMargins(16, 16, 16, 16)

        label = QLabel(text)
        label.setWordWrap(True)
        label.setObjectName("InsightText")

        v.addWidget(label)
        return frame

    # -------------------------
    # MAIN ENTRY
    # -------------------------
    def generate_insights(self):
        insights = []

        data = self.load_usage()
        if not data:
            insights.append("Insights will appear here after you’ve used the assistant for a little while.")
        else:
            insights.extend(self.analyze_usage(data))

        # Clear old cards
        while self.insight_container.count():
            item = self.insight_container.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        # Add new cards
        for text in insights:
            self.insight_container.addWidget(self.make_card(text))

    # -------------------------
    # LOAD CSV
    # -------------------------
    def load_usage(self):
        try:
            with open("usage_log.csv", "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                rows = []
                for r in reader:
                    try:
                        ts = datetime.fromisoformat(r.get("timestamp") or r.get("date"))
                        behavior = (r.get("behavior") or "Activity").strip()
                        fatigue = float(r.get("fatigue_score") or 0.0)
                        brk = str(r.get("break_triggered") or "0").lower() in ["1", "true", "yes"]
                        reason = (r.get("break_reason") or "").strip()
                        rows.append({
                            "timestamp": ts,
                            "behavior": behavior,
                            "fatigue": fatigue,
                            "break_triggered": brk,
                            "break_reason": reason,
                        })
                    except Exception:
                        continue
                return rows
        except FileNotFoundError:
            return []

    # -------------------------
    # HYBRID INSIGHTS
    # -------------------------
    def analyze_usage(self, rows):
        insights = []

        if not rows:
            return ["Not enough data to generate insights yet."]

        # Behavior stats
        behavior_counts = Counter(r["behavior"] for r in rows)
        most_common_behavior, most_common_count = behavior_counts.most_common(1)[0]

        # Time-of-day buckets
        by_hour = defaultdict(list)
        for r in rows:
            by_hour[r["timestamp"].hour].append(r)

        # Break stats
        breaks = [r for r in rows if r["break_triggered"]]
        break_reasons = Counter(r["break_reason"] for r in breaks if r["break_reason"])

        # Fatigue stats
        fatigue_values = [r["fatigue"] for r in rows if r["fatigue"] > 0]
        avg_fatigue = mean(fatigue_values) if fatigue_values else 0
        max_fatigue = max(fatigue_values) if fatigue_values else 0

        # Behavior → fatigue mapping
        fatigue_by_behavior = defaultdict(list)
        for r in rows:
            if r["fatigue"] > 0:
                fatigue_by_behavior[r["behavior"]].append(r["fatigue"])

        # -------------------------
        # 1) Most common behavior
        # -------------------------
        insights.append(
            f"You spend most of your focused time in {most_common_behavior.lower()}."
        )

        # -------------------------
        # 2) Time-of-day pattern
        # -------------------------
        if by_hour:
            # Morning: 6–12, Afternoon: 12–18, Evening: 18–24
            morning = sum(len(by_hour[h]) for h in range(6, 12))
            afternoon = sum(len(by_hour[h]) for h in range(12, 18))
            evening = sum(len(by_hour[h]) for h in range(18, 24))

            segment_counts = {
                "morning": morning,
                "afternoon": afternoon,
                "evening": evening,
            }
            best_segment = max(segment_counts, key=segment_counts.get)
            if segment_counts[best_segment] > 0:
                insights.append(
                    f"Your activity is strongest in the {best_segment}."
                )

        # -------------------------
        # 3) Break reasons
        # -------------------------
        if breaks:
            total_breaks = len(breaks)
            insights.append(
                f"You have taken {total_breaks} breaks during your recent sessions."
            )

            if break_reasons:
                top_reason, _ = break_reasons.most_common(1)[0]
                if top_reason:
                    insights.append(
                        f"Most of your breaks are triggered when the system notices {top_reason.lower()}."
                    )

        # -------------------------
        # 4) Fatigue levels
        # -------------------------
        if fatigue_values:
            insights.append(
                f"On average, your fatigue level before a break is around {avg_fatigue:.0f} out of 100."
            )
            insights.append(
                f"Your highest recorded fatigue recently reached about {max_fatigue:.0f} out of 100."
            )

        # -------------------------
        # 5) Behavior that drives fatigue
        # -------------------------
        if fatigue_by_behavior:
            avg_by_behavior = {
                b: mean(vals) for b, vals in fatigue_by_behavior.items() if vals
            }
            if avg_by_behavior:
                top_fatigue_behavior = max(avg_by_behavior, key=avg_by_behavior.get)
                insights.append(
                    f"Your fatigue tends to rise the most during {top_fatigue_behavior.lower()} sessions."
                )

        # Fallback if somehow we generated nothing
        if not insights:
            insights.append("Insights will appear here as you spend more time using the assistant.")

        return insights
