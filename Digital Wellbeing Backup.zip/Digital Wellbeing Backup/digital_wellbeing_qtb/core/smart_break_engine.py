# smart_break_engine.py
# This file decides when to show a break.
# It uses:
# - real time (clock time)
# - active time (when user is actually working)
# - how "hard" the user is working (strain)
# - small pauses and away time

# import time
# from dataclasses import dataclass

# @dataclass
# class SmartConfig:
#     # base times before we adjust them
#     base_real_time: float = 20 * 60.0      # 20 mins real time
#     base_active_time: float = 12 * 60.0    # 12 mins active time

#     # idle rules
#     micro_pause: float = 5.0               # small pause (5 seconds)
#     away_threshold: float = 60.0           # user is away after 60 seconds

#     # how much we can stretch or shrink the break time
#     min_factor: float = 0.6                # shortest allowed interval
#     max_factor: float = 1.4                # longest allowed interval


# class SmartBreakEngine:
#     def __init__(self, config: SmartConfig):
#         self.config = config

#         # timers for this session
#         self.session_start = time.time()
#         self.real_time = 0.0
#         self.active_time = 0.0

#         # last time the user touched mouse/keyboard
#         self.last_input = time.time()

#         # flags
#         self.user_is_away = False
#         self.user_is_engaged = False

#         # these change based on strain
#         self.real_factor = 1.0
#         self.active_factor = 1.0

#     # called whenever user presses a key or moves mouse
#     def register_input(self):
#         self.last_input = time.time()

#     # score how "active" the user is
#     def compute_engagement_score(self, signals: dict) -> float:
#         """
#         signals example:
#         {
#             "keypress_rate": 4,
#             "mouse_rate": 120,
#             "scroll_rate": 10,
#             "window_switches": 1,
#             "fullscreen": False,
#             "audio_playing": False
#         }
#         """

#         score = 0.0

#         # typing fast usually means working
#         score += min(signals["keypress_rate"] / 8.0, 1.0) * 0.35

#         # mouse movement also means activity
#         score += min(signals["mouse_rate"] / 300.0, 1.0) * 0.25

#         # scrolling means reading or browsing
#         score += min(signals["scroll_rate"] / 50.0, 1.0) * 0.20

#         # switching windows means thinking or multitasking
#         score += min(signals["window_switches"] / 5.0, 1.0) * 0.15

#         # fullscreen video usually means low strain
#         if signals["fullscreen"] and signals["audio_playing"]:
#             score *= 0.5

#         return min(score, 1.0)

#     # score how much strain the user is under
#     def compute_strain_score(self, engagement: float, idle_time: float) -> float:
#         # start with engagement as the base strain
#         strain = engagement

#         # if user pauses a lot, strain is lower
#         if idle_time > self.config.micro_pause:
#             strain *= 0.5

#         return min(max(strain, 0.0), 1.0)

#     # adjust break intervals based on strain
#     def update_adaptive_factors(self, strain: float):
#         # if strain is high → shorter break interval
#         # if strain is low → longer break interval
#         self.real_factor = (
#             self.config.min_factor +
#             (self.config.max_factor - self.config.min_factor) * (1 - strain)
#         )

#         self.active_factor = (
#             self.config.min_factor +
#             (self.config.max_factor - self.config.min_factor) * (1 - strain)
#         )

#     # main update loop
#     def update(self, signals: dict, poll_interval: float) -> bool:
#         now = time.time()
#         idle_time = now - self.last_input

#         # user is away if idle too long
#         self.user_is_away = idle_time >= self.config.away_threshold

#         # check how active the user is
#         engagement = self.compute_engagement_score(signals)
#         self.user_is_engaged = engagement > 0.1

#         # compute strain
#         strain = self.compute_strain_score(engagement, idle_time)

#         # update adaptive factors
#         self.update_adaptive_factors(strain)

#         # update real time
#         self.real_time = now - self.session_start

#         # update active time
#         if not self.user_is_away and self.user_is_engaged and idle_time < self.config.micro_pause:
#             # user is actually working
#             self.active_time += poll_interval
#         else:
#             # small pause resets active time
#             if idle_time >= self.config.micro_pause:
#                 self.active_time = 0.0

#         # compute the actual thresholds after adaptation
#         real_threshold = self.config.base_real_time * self.real_factor
#         active_threshold = self.config.base_active_time * self.active_factor

#         # hybrid rule:
#         # break if either timer hits its limit AND user is not away
#         if not self.user_is_away:
#             if self.real_time >= real_threshold or self.active_time >= active_threshold:
#                 return True

#         return False

#     # reset timers after a break
#     def reset_after_break(self):
#         now = time.time()
#         self.session_start = now
#         self.real_time = 0.0
#         self.active_time = 0.0
#         self.last_input = now
#         self.user_is_away = False
#         self.user_is_engaged = False
#         self.real_factor = 1.0
#         self.active_factor = 1.0













# import time
# from dataclasses import dataclass

# @dataclass
# class SmartConfig:
#     base_real_time: float = 20 * 60.0      # 20 mins real time
#     base_active_time: float = 12 * 60.0    # 12 mins active time

#     micro_pause: float = 5.0               # small pause (5 seconds)
#     away_threshold: float = 60.0           # user is away after 60 seconds

#     min_factor: float = 0.6                # shortest allowed interval
#     max_factor: float = 1.4                # longest allowed interval


# class SmartBreakEngine:
#     def __init__(self, config: SmartConfig):
#         self.config = config

#         # timers
#         self.session_start = time.time()
#         self.real_time = 0.0
#         self.active_time = 0.0
#         self.last_input = time.time()

#         # state flags
#         self.user_is_away = False
#         self.user_is_engaged = False

#         # adaptive factors
#         self.real_factor = 1.0
#         self.active_factor = 1.0

#         # debugging
#         self.debug = False
#         self.suppression_reason = None

#     # simple debug print
#     def _debug(self, msg):
#         if self.debug:
#             print("[ENGINE DEBUG]", msg)

#     # called when keyboard/mouse input happens
#     def register_input(self):
#         self.last_input = time.time()

#     # engagement score from signals
#     def compute_engagement_score(self, signals: dict) -> float:
#         score = 0.0

#         score += min(signals["keypress_rate"] / 8.0, 1.0) * 0.35
#         score += min(signals["mouse_rate"] / 300.0, 1.0) * 0.25
#         score += min(signals["scroll_rate"] / 50.0, 1.0) * 0.20
#         score += min(signals["window_switches"] / 5.0, 1.0) * 0.15

#         # fullscreen video → lower strain
#         if signals["fullscreen"] and signals["audio_playing"]:
#             score *= 0.5

#         return min(score, 1.0)

#     # strain score
#     def compute_strain_score(self, engagement: float, idle_time: float) -> float:
#         strain = engagement

#         # long pauses reduce strain
#         if idle_time > self.config.micro_pause:
#             strain *= 0.5

#         return min(max(strain, 0.0), 1.0)

#     # update adaptive factors
#     def update_adaptive_factors(self, strain: float):
#         # higher strain → shorter intervals
#         self.real_factor = (
#             self.config.min_factor +
#             (self.config.max_factor - self.config.min_factor) * (1 - strain)
#         )

#         self.active_factor = (
#             self.config.min_factor +
#             (self.config.max_factor - self.config.min_factor) * (1 - strain)
#         )

#     # MAIN ENGINE UPDATE
#     def update(self, signals: dict, poll_interval: float) -> bool:
#         now = time.time()
#         idle_time = now - self.last_input

#         # reset suppression reason
#         self.suppression_reason = None

#         # ⭐ ALWAYS update real_time FIRST
#         self.real_time = now - self.session_start

#         # debug info
#         self._debug(f"real_time={self.real_time:.2f}, active_time={self.active_time:.2f}")
#         self._debug(f"idle_time={idle_time:.2f}")
#         self._debug(f"signals={signals}")

#         # detect if user is away
#         self.user_is_away = idle_time >= self.config.away_threshold

#         if self.user_is_away:
#             # user is away → no break, but timers still run
#             self.suppression_reason = "User away"
#             self._debug("SUPPRESS: user away")

#             # away means no active work
#             self.active_time = 0.0
#             return False

#         # engagement score
#         engagement = self.compute_engagement_score(signals)
#         self.user_is_engaged = engagement > 0.1
#         self._debug(f"engagement={engagement:.2f}, engaged={self.user_is_engaged}")

#         # strain score
#         strain = self.compute_strain_score(engagement, idle_time)
#         self._debug(f"strain={strain:.2f}")

#         # update adaptive factors
#         self.update_adaptive_factors(strain)
#         self._debug(f"real_factor={self.real_factor:.2f}, active_factor={self.active_factor:.2f}")

#         # update active_time
#         if self.user_is_engaged and idle_time < self.config.micro_pause:
#             self.active_time += poll_interval
#         else:
#             # idle resets active time
#             if idle_time >= self.config.micro_pause:
#                 self.active_time = 0.0

#         # compute thresholds
#         real_threshold = self.config.base_real_time * self.real_factor
#         active_threshold = self.config.base_active_time * self.active_factor

#         real_remaining = real_threshold - self.real_time
#         active_remaining = active_threshold - self.active_time

#         self._debug(f"real_remaining={real_remaining:.2f}, active_remaining={active_remaining:.2f}")

#         # hybrid break rule
#         if real_remaining <= 0 or active_remaining <= 0:
#             if not self.user_is_engaged:
#                 self.suppression_reason = "Not engaged"
#                 self._debug("SUPPRESS: user not engaged")
#                 return False

#             self._debug("BREAK TRIGGERED")
#             return True

#         self.suppression_reason = "Threshold not reached"
#         return False

#     # reset after break
#     def reset_after_break(self):
#         now = time.time()
#         self.session_start = now
#         self.real_time = 0.0
#         self.active_time = 0.0
#         self.last_input = now
#         self.user_is_away = False
#         self.user_is_engaged = False
#         self.real_factor = 1.0
#         self.active_factor = 1.0
#         self.suppression_reason = None

#     def get_suppression_reason(self):
#         return self.suppression_reason




# import time
# from dataclasses import dataclass

# @dataclass
# class SmartConfig:
#     base_real_time: float = 20 * 60.0      # 20 mins real time
#     base_active_time: float = 12 * 60.0    # 12 mins active time

#     micro_pause: float = 5.0               # small pause (5 seconds)
#     away_threshold: float = 60.0           # user is away after 60 seconds

#     min_factor: float = 0.6                # shortest allowed interval
#     max_factor: float = 1.4                # longest allowed interval


# class SmartBreakEngine:
#     def __init__(self, config: SmartConfig):
#         self.config = config

#         # timers
#         self.session_start = time.time()
#         self.real_time = 0.0
#         self.active_time = 0.0
#         self.last_input = time.time()

#         # state flags
#         self.user_is_away = False
#         self.user_is_engaged = False

#         # adaptive factors
#         self.real_factor = 1.0
#         self.active_factor = 1.0

#         # debugging
#         self.debug = True
#         self.suppression_reason = None

#     # simple debug print
#     def _debug(self, msg):
#         if self.debug:
#             print("[ENGINE DEBUG]", msg)

#     # called when keyboard/mouse input happens
#     def register_input(self):
#         self.last_input = time.time()

#     # engagement score from signals
#     def compute_engagement_score(self, signals: dict) -> float:
#         score = 0.0

#         score += min(signals["keypress_rate"] / 8.0, 1.0) * 0.35
#         score += min(signals["mouse_rate"] / 300.0, 1.0) * 0.25
#         score += min(signals["scroll_rate"] / 50.0, 1.0) * 0.20
#         score += min(signals["window_switches"] / 5.0, 1.0) * 0.15

#         # fullscreen video → lower strain
#         if signals["fullscreen"] and signals["audio_playing"]:
#             score *= 0.5

#         return min(score, 1.0)

#     # strain score
#     def compute_strain_score(self, engagement: float, idle_time: float) -> float:
#         strain = engagement

#         # long pauses reduce strain
#         if idle_time > self.config.micro_pause:
#             strain *= 0.5

#         return min(max(strain, 0.0), 1.0)

#     # update adaptive factors
#     def update_adaptive_factors(self, strain: float):
#         # higher strain → shorter intervals
#         self.real_factor = (
#             self.config.min_factor +
#             (self.config.max_factor - self.config.min_factor) * (1 - strain)
#         )

#         self.active_factor = (
#             self.config.min_factor +
#             (self.config.max_factor - self.config.min_factor) * (1 - strain)
#         )

#     # MAIN ENGINE UPDATE
#     def update(self, signals: dict, poll_interval: float) -> bool:
#         now = time.time()
#         idle_time = now - self.last_input

#         # reset suppression reason
#         self.suppression_reason = None

#         # ⭐ ALWAYS update real_time FIRST
#         self.real_time = now - self.session_start

#         # debug info
#         self._debug(f"real_time={self.real_time:.2f}, active_time={self.active_time:.2f}")
#         self._debug(f"idle_time={idle_time:.2f}")
#         self._debug(f"signals={signals}")

#         # ⭐⭐⭐ WEBCAM SUPPRESSION (Option A — Meeting Mode)
#         if signals.get("webcam_active"):
#             self.suppression_reason = "Webcam active (meeting mode)"
#             self._debug("SUPPRESS: webcam active → meeting mode")
#             return False
        
#         # ⭐ Microphone suppression (meeting mode)
#         if signals.get("microphone_active"):
#             self.suppression_reason = "Microphone active (meeting mode)"
#             self._debug("SUPPRESS: microphone active → meeting mode")
#             return False


#         # detect if user is away
#         self.user_is_away = idle_time >= self.config.away_threshold

#         if self.user_is_away:
#             self.suppression_reason = "User away"
#             self._debug("SUPPRESS: user away")

#             # away means no active work
#             self.active_time = 0.0
#             return False

#         # engagement score
#         engagement = self.compute_engagement_score(signals)
#         self.user_is_engaged = engagement > 0.1
#         self._debug(f"engagement={engagement:.2f}, engaged={self.user_is_engaged}")

#         # strain score
#         strain = self.compute_strain_score(engagement, idle_time)
#         self._debug(f"strain={strain:.2f}")

#         # update adaptive factors
#         self.update_adaptive_factors(strain)
#         self._debug(f"real_factor={self.real_factor:.2f}, active_factor={self.active_factor:.2f}")

#         # update active_time
#         if self.user_is_engaged and idle_time < self.config.micro_pause:
#             self.active_time += poll_interval
#         else:
#             if idle_time >= self.config.micro_pause:
#                 self.active_time = 0.0

#         # compute thresholds
#         real_threshold = self.config.base_real_time * self.real_factor
#         active_threshold = self.config.base_active_time * self.active_factor

#         real_remaining = real_threshold - self.real_time
#         active_remaining = active_threshold - self.active_time

#         self._debug(f"real_remaining={real_remaining:.2f}, active_remaining={active_remaining:.2f}")

#         # hybrid break rule
#         if real_remaining <= 0 or active_remaining <= 0:
#             if not self.user_is_engaged:
#                 self.suppression_reason = "Not engaged"
#                 self._debug("SUPPRESS: user not engaged")
#                 return False

#             self._debug("BREAK TRIGGERED")
#             return True

#         self.suppression_reason = "Threshold not reached"
#         return False

#     # reset after break
#     def reset_after_break(self):
#         now = time.time()
#         self.session_start = now
#         self.real_time = 0.0
#         self.active_time = 0.0
#         self.last_input = now
#         self.user_is_away = False
#         self.user_is_engaged = False
#         self.real_factor = 1.0
#         self.active_factor = 1.0
#         self.suppression_reason = None

#     def get_suppression_reason(self):
#         return self.suppression_reason














# #Fixed Idle time
# import time
# from dataclasses import dataclass

# @dataclass
# class SmartConfig:
#     base_real_time: float = 20 * 60.0      # 20 mins real time
#     base_active_time: float = 12 * 60.0    # 12 mins active time

#     micro_pause: float = 5.0               # small pause (5 seconds)
#     away_threshold: float = 60.0           # user is away after 60 seconds

#     min_factor: float = 0.6                # shortest allowed interval
#     max_factor: float = 1.4                # longest allowed interval


# class SmartBreakEngine:
#     def __init__(self, config: SmartConfig):
#         self.config = config

#         # timers
#         self.session_start = time.time()
#         self.real_time = 0.0
#         self.active_time = 0.0
#         self.last_input = time.time()   # legacy internal timer (now synced to signals)

#         # state flags
#         self.user_is_away = False
#         self.user_is_engaged = False

#         # adaptive factors
#         self.real_factor = 1.0
#         self.active_factor = 1.0

#         # debugging
#         self.debug = True
#         self.suppression_reason = None

#     def _debug(self, msg):
#         if self.debug:
#             print("[ENGINE DEBUG]", msg)

#     def register_input(self):
#         self.last_input = time.time()

#     def compute_engagement_score(self, signals: dict) -> float:
#         score = 0.0

#         score += min(signals["keypress_rate"] / 8.0, 1.0) * 0.35
#         score += min(signals["mouse_rate"] / 300.0, 1.0) * 0.25
#         score += min(signals["scroll_rate"] / 50.0, 1.0) * 0.20
#         score += min(signals["window_switches"] / 5.0, 1.0) * 0.15

#         if signals["fullscreen"] and signals["audio_playing"]:
#             score *= 0.5

#         return min(score, 1.0)

#     def compute_strain_score(self, engagement: float, idle_time: float) -> float:
#         strain = engagement

#         if idle_time > self.config.micro_pause:
#             strain *= 0.5

#         return min(max(strain, 0.0), 1.0)

#     def update_adaptive_factors(self, strain: float):
#         self.real_factor = (
#             self.config.min_factor +
#             (self.config.max_factor - self.config.min_factor) * (1 - strain)
#         )

#         self.active_factor = (
#             self.config.min_factor +
#             (self.config.max_factor - self.config.min_factor) * (1 - strain)
#         )

#     # ⭐⭐⭐ MAIN ENGINE UPDATE (corrected)
#     def update(self, signals: dict, poll_interval: float) -> bool:
#         now = time.time()

#         # ⭐ Use SignalCollector's idle_seconds instead of stale last_input
#         idle_time = signals.get("idle_seconds", now - self.last_input)

#         # ⭐ Keep internal timer in sync with collector
#         if idle_time < self.config.away_threshold:
#             self.last_input = now - idle_time

#         # reset suppression reason
#         self.suppression_reason = None

#         # ALWAYS update real_time first
#         self.real_time = now - self.session_start

#         # debug
#         self._debug(f"real_time={self.real_time:.2f}, active_time={self.active_time:.2f}")
#         self._debug(f"idle_time={idle_time:.2f}")
#         self._debug(f"signals={signals}")

#         # Meeting suppression
#         if signals.get("webcam_active"):
#             self.suppression_reason = "Webcam active (meeting mode)"
#             self._debug("SUPPRESS: webcam active → meeting mode")
#             return False
        
#         if signals.get("microphone_active"):
#             self.suppression_reason = "Microphone active (meeting mode)"
#             self._debug("SUPPRESS: microphone active → meeting mode")
#             return False

#         # Away detection (now correct)
#         self.user_is_away = idle_time >= self.config.away_threshold

#         if self.user_is_away:
#             self.suppression_reason = "User away"
#             self._debug("SUPPRESS: user away")
#             self.active_time = 0.0
#             return False

#         # Engagement
#         engagement = self.compute_engagement_score(signals)
#         self.user_is_engaged = engagement > 0.1
#         self._debug(f"engagement={engagement:.2f}, engaged={self.user_is_engaged}")

#         # Strain
#         strain = self.compute_strain_score(engagement, idle_time)
#         self._debug(f"strain={strain:.2f}")

#         # Adaptive factors
#         self.update_adaptive_factors(strain)
#         self._debug(f"real_factor={self.real_factor:.2f}, active_factor={self.active_factor:.2f}")

#         # Active time logic (now works correctly)
#         if self.user_is_engaged and idle_time < self.config.micro_pause:
#             self.active_time += poll_interval
#         else:
#             if idle_time >= self.config.micro_pause:
#                 self.active_time = 0.0

#         # Thresholds
#         real_threshold = self.config.base_real_time * self.real_factor
#         active_threshold = self.config.base_active_time * self.active_factor

#         real_remaining = real_threshold - self.real_time
#         active_remaining = active_threshold - self.active_time

#         self._debug(f"real_remaining={real_remaining:.2f}, active_remaining={active_remaining:.2f}")

#         # Hybrid break rule
#         if real_remaining <= 0 or active_remaining <= 0:
#             if not self.user_is_engaged:
#                 self.suppression_reason = "Not engaged"
#                 self._debug("SUPPRESS: user not engaged")
#                 return False

#             self._debug("BREAK TRIGGERED")
#             return True

#         self.suppression_reason = "Threshold not reached"
#         return False

#     def reset_after_break(self):
#         now = time.time()
#         self.session_start = now
#         self.real_time = 0.0
#         self.active_time = 0.0
#         self.last_input = now
#         self.user_is_away = False
#         self.user_is_engaged = False
#         self.real_factor = 1.0
#         self.active_factor = 1.0
#         self.suppression_reason = None

#     def get_suppression_reason(self):
#         return self.suppression_reason
























# # smart_break_engine.py
# import time
# from dataclasses import dataclass

# @dataclass
# class SmartConfig:
#     base_real_time: float = 20 * 60.0      # 20 mins real time
#     base_active_time: float = 12 * 60.0    # 12 mins active time

#     micro_pause: float = 5.0               # small pause (5 seconds)
#     away_threshold: float = 60.0           # user is away after 60 seconds

#     min_factor: float = 0.6                # shortest allowed interval
#     max_factor: float = 1.4                # longest allowed interval


# class SmartBreakEngine:
#     def __init__(self, config: SmartConfig):
#         self.config = config

#         # timers
#         self.session_start = time.time()
#         self.real_time = 0.0
#         self.active_time = 0.0
#         self.last_input = time.time()

#         # state flags
#         self.user_is_away = False
#         self.user_is_engaged = False

#         # adaptive factors
#         self.real_factor = 1.0
#         self.active_factor = 1.0

#         # debugging
#         self.debug = True
#         self.suppression_reason = None

#     def _debug(self, msg):
#         if self.debug:
#             print("[ENGINE DEBUG]", msg)

#     def register_input(self):
#         self.last_input = time.time()

#     def compute_engagement_score(self, signals: dict) -> float:
#         score = 0.0

#         score += min(signals["keypress_rate"] / 8.0, 1.0) * 0.35
#         score += min(signals["mouse_rate"] / 300.0, 1.0) * 0.25
#         score += min(signals["scroll_rate"] / 50.0, 1.0) * 0.20
#         score += min(signals["window_switches"] / 5.0, 1.0) * 0.15

#         if signals["fullscreen"] and signals["audio_playing"]:
#             score *= 0.5

#         return min(score, 1.0)

#     def compute_strain_score(self, engagement: float, idle_time: float) -> float:
#         strain = engagement

#         if idle_time > self.config.micro_pause:
#             strain *= 0.5

#         return min(max(strain, 0.0), 1.0)

#     def update_adaptive_factors(self, strain: float):
#         self.real_factor = (
#             self.config.min_factor +
#             (self.config.max_factor - self.config.min_factor) * (1 - strain)
#         )

#         self.active_factor = (
#             self.config.min_factor +
#             (self.config.max_factor - self.config.min_factor) * (1 - strain)
#         )

#     # ⭐⭐⭐ MAIN ENGINE UPDATE (corrected)
#     def update(self, signals: dict, poll_interval: float) -> bool:
#         now = time.time()

#         # Use SignalCollector's idle_seconds
#         idle_time = signals.get("idle_seconds", now - self.last_input)

#         # Sync internal last_input
#         if idle_time < self.config.away_threshold:
#             self.last_input = now - idle_time

#         # reset suppression reason
#         self.suppression_reason = None

#         # ALWAYS update real_time
#         self.real_time = now - self.session_start

#         # debug
#         self._debug(f"real_time={self.real_time:.2f}, active_time={self.active_time:.2f}")
#         self._debug(f"idle_time={idle_time:.2f}")
#         self._debug(f"signals={signals}")

#         # Meeting suppression
#         if signals.get("webcam_active"):
#             self.suppression_reason = "Webcam active (meeting mode)"
#             self._debug("SUPPRESS: webcam active → meeting mode")
#             return False
        
#         if signals.get("microphone_active"):
#             self.suppression_reason = "Microphone active (meeting mode)"
#             self._debug("SUPPRESS: microphone active → meeting mode")
#             return False

#         # Away detection
#         self.user_is_away = idle_time >= self.config.away_threshold

#         if self.user_is_away:
#             self.suppression_reason = "User away"
#             self._debug("SUPPRESS: user away")
#             self.active_time = 0.0
#             return False

#         # Engagement
#         engagement = self.compute_engagement_score(signals)
#         self.user_is_engaged = engagement > 0.1
#         self._debug(f"engagement={engagement:.2f}, engaged={self.user_is_engaged}")

#         # Strain
#         strain = self.compute_strain_score(engagement, idle_time)
#         self._debug(f"strain={strain:.2f}")

#         # Adaptive factors
#         self.update_adaptive_factors(strain)
#         self._debug(f"real_factor={self.real_factor:.2f}, active_factor={self.active_factor:.2f}")

#         # Active time logic
#         if self.user_is_engaged and idle_time < self.config.micro_pause:
#             self.active_time += poll_interval
#         else:
#             if idle_time >= self.config.micro_pause:
#                 self.active_time = 0.0

#         # Thresholds
#         real_threshold = self.config.base_real_time * self.real_factor
#         active_threshold = self.config.base_active_time * self.active_factor

#         real_remaining = real_threshold - self.real_time
#         active_remaining = active_threshold - self.active_time

#         self._debug(f"real_remaining={real_remaining:.2f}, active_remaining={active_remaining:.2f}")

#         # Hybrid break rule
#         if real_remaining <= 0 or active_remaining <= 0:
#             if not self.user_is_engaged:
#                 self.suppression_reason = "Not engaged"
#                 self._debug("SUPPRESS: user not engaged")
#                 return False

#             self._debug("BREAK TRIGGERED")
#             return True

#         self.suppression_reason = "Threshold not reached"
#         return False

#     def reset_after_break(self):
#         now = time.time()
#         self.session_start = now
#         self.real_time = 0.0
#         self.active_time = 0.0
#         self.last_input = now
#         self.user_is_away = False
#         self.user_is_engaged = False
#         self.real_factor = 1.0
#         self.active_factor = 1.0
#         self.suppression_reason = None

#     def get_suppression_reason(self):
#         return self.suppression_reason













# I needed to clean the writings so it doesn't have unerscores in UI



# # smart_break_engine.py
# import time
# from dataclasses import dataclass

# @dataclass
# class SmartConfig:
#     base_real_time: float = 20 * 60.0      # 20 mins real time
#     base_active_time: float = 12 * 60.0    # 12 mins active time

#     micro_pause: float = 5.0               # small pause (5 seconds)
#     away_threshold: float = 60.0           # user is away after 60 seconds

#     min_factor: float = 0.6                # shortest allowed interval
#     max_factor: float = 1.4                # longest allowed interval


# class SmartBreakEngine:
#     def __init__(self, config: SmartConfig):
#         self.config = config

#         # timers
#         self.session_start = time.time()
#         self.real_time = 0.0
#         self.active_time = 0.0
#         self.last_input = time.time()

#         # state flags
#         self.user_is_away = False
#         self.user_is_engaged = False

#         # adaptive factors
#         self.real_factor = 1.0
#         self.active_factor = 1.0

#         # debugging
#         self.debug = True
#         self.suppression_reason = None

#     # ---------------------------------------------------------
#     # UI LABEL FORMATTER (NEW)
#     # ---------------------------------------------------------
#     @staticmethod
#     def format_ui_label(text: str) -> str:
#         """Convert internal identifiers into clean UI labels."""
#         words = text.replace("_", " ").split()
#         formatted = []

#         for w in words:
#             if w.isupper():  # preserve acronyms
#                 formatted.append(w)
#             else:
#                 formatted.append(w.capitalize())

#         return " ".join(formatted)

#     # ---------------------------------------------------------

#     def _debug(self, msg):
#         if self.debug:
#             print("[ENGINE DEBUG]", msg)

#     def register_input(self):
#         self.last_input = time.time()

#     def compute_engagement_score(self, signals: dict) -> float:
#         score = 0.0

#         score += min(signals["keypress_rate"] / 8.0, 1.0) * 0.35
#         score += min(signals["mouse_rate"] / 300.0, 1.0) * 0.25
#         score += min(signals["scroll_rate"] / 50.0, 1.0) * 0.20
#         score += min(signals["window_switches"] / 5.0, 1.0) * 0.15

#         if signals["fullscreen"] and signals["audio_playing"]:
#             score *= 0.5

#         return min(score, 1.0)

#     def compute_strain_score(self, engagement: float, idle_time: float) -> float:
#         strain = engagement

#         if idle_time > self.config.micro_pause:
#             strain *= 0.5

#         return min(max(strain, 0.0), 1.0)

#     def update_adaptive_factors(self, strain: float):
#         self.real_factor = (
#             self.config.min_factor +
#             (self.config.max_factor - self.config.min_factor) * (1 - strain)
#         )

#         self.active_factor = (
#             self.config.min_factor +
#             (self.config.max_factor - self.config.min_factor) * (1 - strain)
#         )

#     # ⭐⭐⭐ MAIN ENGINE UPDATE
#     def update(self, signals: dict, poll_interval: float) -> bool:
#         now = time.time()

#         idle_time = signals.get("idle_seconds", now - self.last_input)

#         if idle_time < self.config.away_threshold:
#             self.last_input = now - idle_time

#         self.suppression_reason = None
#         self.real_time = now - self.session_start

#         self._debug(f"real_time={self.real_time:.2f}, active_time={self.active_time:.2f}")
#         self._debug(f"idle_time={idle_time:.2f}")
#         self._debug(f"signals={signals}")

#         # Meeting suppression
#         if signals.get("webcam_active"):
#             self.suppression_reason = "Webcam active (meeting mode)"
#             self._debug("SUPPRESS: webcam active → meeting mode")
#             return False
        
#         if signals.get("microphone_active"):
#             self.suppression_reason = "Microphone active (meeting mode)"
#             self._debug("SUPPRESS: microphone active → meeting mode")
#             return False

#         # Away detection
#         self.user_is_away = idle_time >= self.config.away_threshold

#         if self.user_is_away:
#             self.suppression_reason = "User away"
#             self._debug("SUPPRESS: user away")
#             self.active_time = 0.0
#             return False

#         # Engagement
#         engagement = self.compute_engagement_score(signals)
#         self.user_is_engaged = engagement > 0.1
#         self._debug(f"engagement={engagement:.2f}, engaged={self.user_is_engaged}")

#         # Strain
#         strain = self.compute_strain_score(engagement, idle_time)
#         self._debug(f"strain={strain:.2f}")

#         # Adaptive factors
#         self.update_adaptive_factors(strain)
#         self._debug(f"real_factor={self.real_factor:.2f}, active_factor={self.active_factor:.2f}")

#         # Active time logic
#         if self.user_is_engaged and idle_time < self.config.micro_pause:
#             self.active_time += poll_interval
#         else:
#             if idle_time >= self.config.micro_pause:
#                 self.active_time = 0.0

#         # Thresholds
#         real_threshold = self.config.base_real_time * self.real_factor
#         active_threshold = self.config.base_active_time * self.active_factor

#         real_remaining = real_threshold - self.real_time
#         active_remaining = active_threshold - self.active_time

#         self._debug(f"real_remaining={real_remaining:.2f}, active_remaining={active_remaining:.2f}")

#         # Hybrid break rule
#         if real_remaining <= 0 or active_remaining <= 0:
#             if not self.user_is_engaged:
#                 self.suppression_reason = "Not engaged"
#                 self._debug("SUPPRESS: user not engaged")
#                 return False

#             self._debug("BREAK TRIGGERED")
#             return True

#         self.suppression_reason = "Threshold not reached"
#         return False

#     def reset_after_break(self):
#         now = time.time()
#         self.session_start = now
#         self.real_time = 0.0
#         self.active_time = 0.0
#         self.last_input = now
#         self.user_is_away = False
#         self.user_is_engaged = False
#         self.real_factor = 1.0
#         self.active_factor = 1.0
#         self.suppression_reason = None

#     # ---------------------------------------------------------
#     # CLEANED UI OUTPUT (UPDATED)
#     # ---------------------------------------------------------
#     def get_suppression_reason(self):
#         if self.suppression_reason:
#             return self.format_ui_label(self.suppression_reason)
#         return None
























# 2
# # smart_break_engine.py
# import time
# from dataclasses import dataclass

# @dataclass
# class SmartConfig:
#     base_real_time: float = 20 * 60.0      # 20 mins real time
#     base_active_time: float = 12 * 60.0    # 12 mins active time

#     micro_pause: float = 5.0               # small pause (5 seconds)
#     away_threshold: float = 120.0          # user is away after 120 seconds (matches SignalCollector)

#     min_factor: float = 0.6                # shortest allowed interval
#     max_factor: float = 1.4                # longest allowed interval


# class SmartBreakEngine:
#     def __init__(self, config: SmartConfig):
#         self.config = config

#         # timers
#         self.session_start = time.time()
#         self.real_time = 0.0
#         self.active_time = 0.0
#         self.last_input = time.time()

#         # state flags
#         self.user_is_away = False
#         self.user_is_engaged = False

#         # adaptive factors
#         self.real_factor = 1.0
#         self.active_factor = 1.0

#         # debugging
#         self.debug = True
#         self.suppression_reason = None

#     # ---------------------------------------------------------
#     # UI LABEL FORMATTER
#     # ---------------------------------------------------------
#     @staticmethod
#     def format_ui_label(text: str) -> str:
#         """Convert internal identifiers into clean UI labels."""
#         words = text.replace("_", " ").split()
#         formatted = []
#         for w in words:
#             if w.isupper():  # preserve acronyms
#                 formatted.append(w)
#             else:
#                 formatted.append(w.capitalize())
#         return " ".join(formatted)

#     # ---------------------------------------------------------
#     def _debug(self, msg):
#         if self.debug:
#             print("[SMART ENGINE]", msg)

#     def register_input(self):
#         self.last_input = time.time()

#     # ---------------------------------------------------------
#     # ENGAGEMENT & STRAIN
#     # ---------------------------------------------------------
#     def compute_engagement_score(self, signals: dict) -> float:
#         """Score 0–1 based on keyboard, mouse, scroll, window switching"""
#         score = 0.0
#         score += min(signals.get("keypress_rate", 0) / 8.0, 1.0) * 0.35
#         score += min(signals.get("mouse_rate", 0) / 300.0, 1.0) * 0.25
#         score += min(signals.get("scroll_rate", 0) / 50.0, 1.0) * 0.20
#         score += min(signals.get("window_switches", 0) / 5.0, 1.0) * 0.15

#         if signals.get("fullscreen") and signals.get("audio_playing"):
#             score *= 0.5

#         return min(score, 1.0)

#     def compute_strain_score(self, engagement: float, idle_time: float) -> float:
#         """Lower strain if user idle"""
#         strain = engagement
#         if idle_time > self.config.micro_pause:
#             strain *= 0.5
#         return min(max(strain, 0.0), 1.0)

#     def update_adaptive_factors(self, strain: float):
#         self.real_factor = self.config.min_factor + (self.config.max_factor - self.config.min_factor) * (1 - strain)
#         self.active_factor = self.config.min_factor + (self.config.max_factor - self.config.min_factor) * (1 - strain)

#     # ---------------------------------------------------------
#     # MAIN ENGINE UPDATE
#     # ---------------------------------------------------------
#     def update(self, signals: dict, poll_interval: float) -> bool:
#         now = time.time()
#         idle_time = signals.get("idle_seconds", now - self.last_input)

#         if idle_time < self.config.away_threshold:
#             self.last_input = now - idle_time

#         self.suppression_reason = None
#         self.real_time = now - self.session_start

#         self._debug(f"real_time={self.real_time:.2f}, active_time={self.active_time:.2f}")
#         self._debug(f"idle_time={idle_time:.2f}, signals={signals}")

#         # -----------------------------------------------------
#         # Meeting suppression
#         # -----------------------------------------------------
#         if signals.get("webcam_active"):
#             self.suppression_reason = "Webcam active (meeting mode)"
#             self._debug("SUPPRESS: webcam active")
#             return False
#         if signals.get("microphone_active"):
#             self.suppression_reason = "Microphone active (meeting mode)"
#             self._debug("SUPPRESS: microphone active")
#             return False

#         # -----------------------------------------------------
#         # Away detection
#         # -----------------------------------------------------
#         self.user_is_away = idle_time >= self.config.away_threshold or signals.get("screen_locked", False)
#         if self.user_is_away:
#             self.suppression_reason = "User away"
#             self._debug("SUPPRESS: user away")
#             self.active_time = 0.0
#             return False

#         # -----------------------------------------------------
#         # Engagement
#         # -----------------------------------------------------
#         engagement = self.compute_engagement_score(signals)
#         self.user_is_engaged = engagement > 0.1
#         self._debug(f"engagement={engagement:.2f}, engaged={self.user_is_engaged}")

#         # -----------------------------------------------------
#         # Strain
#         # -----------------------------------------------------
#         strain = self.compute_strain_score(engagement, idle_time)
#         self._debug(f"strain={strain:.2f}")

#         # -----------------------------------------------------
#         # Adaptive factors
#         # -----------------------------------------------------
#         self.update_adaptive_factors(strain)
#         self._debug(f"real_factor={self.real_factor:.2f}, active_factor={self.active_factor:.2f}")

#         # -----------------------------------------------------
#         # Active time logic
#         # -----------------------------------------------------
#         if self.user_is_engaged and idle_time < self.config.micro_pause:
#             self.active_time += poll_interval
#         else:
#             if idle_time >= self.config.micro_pause:
#                 self.active_time = 0.0

#         # -----------------------------------------------------
#         # Threshold check
#         # -----------------------------------------------------
#         real_threshold = self.config.base_real_time * self.real_factor
#         active_threshold = self.config.base_active_time * self.active_factor

#         real_remaining = real_threshold - self.real_time
#         active_remaining = active_threshold - self.active_time

#         self._debug(f"real_remaining={real_remaining:.2f}, active_remaining={active_remaining:.2f}")

#         if real_remaining <= 0 or active_remaining <= 0:
#             if not self.user_is_engaged:
#                 self.suppression_reason = "Not engaged"
#                 self._debug("SUPPRESS: not engaged")
#                 return False
#             self._debug("BREAK TRIGGERED")
#             return True

#         self.suppression_reason = "Threshold not reached"
#         return False

#     # ---------------------------------------------------------
#     # RESET
#     # ---------------------------------------------------------
#     def reset_after_break(self):
#         now = time.time()
#         self.session_start = now
#         self.real_time = 0.0
#         self.active_time = 0.0
#         self.last_input = now
#         self.user_is_away = False
#         self.user_is_engaged = False
#         self.real_factor = 1.0
#         self.active_factor = 1.0
#         self.suppression_reason = None

#     # ---------------------------------------------------------
#     # CLEAN UI OUTPUT
#     # ---------------------------------------------------------
#     def get_suppression_reason(self):
#         if self.suppression_reason:
#             return self.format_ui_label(self.suppression_reason)
#         return None
























# 5 this is a whole new thing
# Upgraded to m=be like AI mode

# # smart_break_engine.py

# import time
# from dataclasses import dataclass
# from core.behavior_classifier import BehaviorClassifier
# from core.meeting_mode import MeetingMode
# from core.fatigue_model import FatiguePredictionModel


# @dataclass
# class SmartConfig:
#     base_interval: float = 20 * 60.0      # 20 minutes
#     min_interval: float = 8 * 60.0        # 8 minutes
#     max_interval: float = 45 * 60.0       # 45 minutes
#     away_threshold: float = 120.0         # 2 minutes away


# class SmartBreakEngine:
#     """
#     Premium Smart Mode:
#     - Behavior-aware
#     - Meeting-aware
#     - Entertainment-aware
#     - Fatigue-aware
#     - Posture/Eye-strain aware
#     - Warm, human-friendly messages
#     - Predictable and simple timing
#     """

#     def __init__(self, config: SmartConfig):
#         self.config = config

#         self.session_start = time.time()
#         self.last_break_time = time.time()
#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0

#         self.behavior_classifier = BehaviorClassifier()
#         self.meeting_mode = MeetingMode()
#         self.fatigue_model = FatiguePredictionModel()

#     # ---------------------------------------------------------
#     # CLEAN LABELS
#     # ---------------------------------------------------------
#     def _clean_label(self, text):
#         if hasattr(text, "category"):
#             text = text.category

#         if not isinstance(text, str):
#             return "Activity"

#         cleaned = text.replace("_", " ").title()
#         if cleaned.lower() in ["unknown", ""]:
#             return "Activity"
#         return cleaned

#     def _behavior_key(self, text):
#         if hasattr(text, "category"):
#             text = text.category
#         if not isinstance(text, str):
#             return "activity"
#         return text.strip().lower().replace(" ", "_")

#     # ---------------------------------------------------------
#     # SMART MODE MESSAGES (warm tone)
#     # ---------------------------------------------------------
#     SMART_MESSAGES = {
#         "meeting_suppressed": "You’re in a call. Breaks will resume afterward.",
#         "watching_suppressed": "Enjoy your video. Breaks are paused while you’re watching.",
#         "gaming_suppressed": "You’re in the middle of a game. Breaks will wait for you.",
#         "away_reset": "Welcome back. Take a moment to settle in.",
#         "strain_risk": "Your eyes have been working hard. A short pause could help.",
#         "fatigue_early": "You’ve been focused for a while. A brief stretch may feel good.",
#         "interval_reached": "You’ve been going for a bit. This is a good moment to pause.",
#         "recent_break": "You just took a break recently.",
#         "not_due": "You’re good to continue.",
#     }

#     # ---------------------------------------------------------
#     # MAIN DECISION LOGIC
#     # ---------------------------------------------------------
#     def should_trigger_break(self, signals: dict) -> dict:
#         now = time.time()
#         idle = signals.get("idle_seconds", 0.0)

#         # 1. Classify behavior
#         behavior_result = self.behavior_classifier.classify(signals)
#         raw_behavior = behavior_result.category
#         behavior_key = self._behavior_key(raw_behavior)
#         clean_behavior = self._clean_label(raw_behavior)

#         # 2. Away detection
#         if idle > self.config.away_threshold or signals.get("screen_locked", False):
#             self.session_start = now
#             self.last_behavior = "Away"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "behavior": "Away",
#                 "reason": "Away Reset",
#                 "message": self.SMART_MESSAGES["away_reset"],
#                 "fatigue_score": 0.0,
#                 "interval_used": self.config.base_interval
#             }

#         # 3. Meeting suppression
#         if self.meeting_mode.should_suppress_breaks(signals, behavior_key):
#             self.last_behavior = "Meeting"
#             self.last_fatigue = 0.0
#             return {
#                 "trigger": False,
#                 "behavior": "Meeting",
#                 "reason": "Meeting Suppressed",
#                 "message": self.SMART_MESSAGES["meeting_suppressed"],
#                 "fatigue_score": 0.0,
#                 "interval_used": self.config.base_interval
#             }

#         # 4. Entertainment suppression (watching/gaming)
#         if behavior_key in ["watching", "video"]:
#             return {
#                 "trigger": False,
#                 "behavior": "Watching",
#                 "reason": "Watching Suppressed",
#                 "message": self.SMART_MESSAGES["watching_suppressed"],
#                 "fatigue_score": 0.0,
#                 "interval_used": self.config.base_interval
#             }

#         if behavior_key == "gaming":
#             return {
#                 "trigger": False,
#                 "behavior": "Gaming",
#                 "reason": "Gaming Suppressed",
#                 "message": self.SMART_MESSAGES["gaming_suppressed"],
#                 "fatigue_score": 0.0,
#                 "interval_used": self.config.base_interval
#             }

#         # 5. Compute fatigue
#         fatigue_score = self.fatigue_model.compute_fatigue(signals, behavior_key)
#         self.last_behavior = clean_behavior
#         self.last_fatigue = fatigue_score

#         # 6. Dynamic interval (simple version)
#         interval = self.config.base_interval
#         if fatigue_score > 70:
#             interval *= 0.7
#         elif fatigue_score > 50:
#             interval *= 0.85
#         elif fatigue_score < 20:
#             interval *= 1.15

#         interval = max(self.config.min_interval, min(self.config.max_interval, interval))

#         # 7. Minimum spacing
#         elapsed = now - self.last_break_time
#         if elapsed < self.config.min_interval:
#             return {
#                 "trigger": False,
#                 "behavior": clean_behavior,
#                 "reason": "Recent Break",
#                 "message": self.SMART_MESSAGES["recent_break"],
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 8. Hard interval reached
#         if now - self.session_start >= interval:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "behavior": clean_behavior,
#                 "reason": "Interval Reached",
#                 "message": self.SMART_MESSAGES["interval_reached"],
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 9. Fatigue early break
#         if fatigue_score >= 75:
#             self.last_break_time = now
#             return {
#                 "trigger": True,
#                 "behavior": clean_behavior,
#                 "reason": "Fatigue Early",
#                 "message": self.SMART_MESSAGES["fatigue_early"],
#                 "fatigue_score": fatigue_score,
#                 "interval_used": interval
#             }

#         # 10. Strain risk (but not during watching/gaming)
#         if clean_behavior in ["Eye Strain Risk", "Posture Risk"]:
#             if fatigue_score >= 55:
#                 self.last_break_time = now
#                 return {
#                     "trigger": True,
#                     "behavior": clean_behavior,
#                     "reason": "Strain Risk",
#                     "message": self.SMART_MESSAGES["strain_risk"],
#                     "fatigue_score": fatigue_score,
#                     "interval_used": interval
#                 }

#         # 11. No break
#         return {
#             "trigger": False,
#             "behavior": clean_behavior,
#             "reason": "Not Due",
#             "message": self.SMART_MESSAGES["not_due"],
#             "fatigue_score": fatigue_score,
#             "interval_used": interval
#         }

#     # ---------------------------------------------------------
#     # RESET
#     # ---------------------------------------------------------
#     def reset_after_break(self):
#         now = time.time()
#         self.session_start = now
#         self.last_break_time = now
#         self.last_behavior = "Idle"
#         self.last_fatigue = 0.0


















# core/smart_break_engine.py

import time
from dataclasses import dataclass
from core.behavior_classifier import BehaviorClassifier
from core.meeting_mode import MeetingMode
from core.fatigue_model import FatiguePredictionModel


@dataclass
class SmartConfig:
    base_interval: float = 20 * 60.0      # 20 minutes
    min_interval: float = 8 * 60.0        # 8 minutes
    max_interval: float = 45 * 60.0       # 45 minutes
    away_threshold: float = 120.0         # 2 minutes away


class SmartBreakEngine:
    """
    Premium Smart Mode:
    - Behavior-aware
    - Meeting-aware
    - Entertainment-aware
    - Fatigue-aware
    - Posture/Eye-strain aware
    - Warm, human-friendly messages
    - Predictable and simple timing
    """

    def __init__(self, config: SmartConfig):
        self.config = config

        # REQUIRED for MainWindow compatibility
        self.base_interval = config.base_interval

        self.session_start = time.time()
        self.last_break_time = time.time()
        self.last_behavior = "Idle"
        self.last_fatigue = 0.0

        self.behavior_classifier = BehaviorClassifier()
        self.meeting_mode = MeetingMode()
        self.fatigue_model = FatiguePredictionModel()

    # ---------------------------------------------------------
    # CLEAN LABELS
    # ---------------------------------------------------------
    def _clean_label(self, text):
        if hasattr(text, "category"):
            text = text.category

        if not isinstance(text, str):
            return "Activity"

        cleaned = text.replace("_", " ").title()
        if cleaned.lower() in ["unknown", ""]:
            return "Activity"
        return cleaned

    def _behavior_key(self, text):
        if hasattr(text, "category"):
            text = text.category
        if not isinstance(text, str):
            return "activity"
        return text.strip().lower().replace(" ", "_")

    # ---------------------------------------------------------
    # SMART MODE MESSAGES (warm tone)
    # ---------------------------------------------------------
    SMART_MESSAGES = {
        "meeting_suppressed": "You’re in a call. Breaks will resume afterward.",
        "watching_suppressed": "Enjoy your video. Breaks are paused while you’re watching.",
        "gaming_suppressed": "You’re in the middle of a game. Breaks will wait for you.",
        "away_reset": "Welcome back. Take a moment to settle in.",
        "strain_risk": "Your eyes have been working hard. A short pause could help.",
        "fatigue_early": "You’ve been focused for a while. A brief stretch may feel good.",
        "interval_reached": "You’ve been going for a bit. This is a good moment to pause.",
        "recent_break": "You just took a break recently.",
        "not_due": "You’re good to continue.",
    }

    # ---------------------------------------------------------
    # MAIN DECISION LOGIC
    # ---------------------------------------------------------
    def should_trigger_break(self, signals: dict) -> dict:
        now = time.time()
        idle = signals.get("idle_seconds", 0.0)

        # 1. Classify behavior
        behavior_result = self.behavior_classifier.classify(signals)
        raw_behavior = behavior_result.category
        behavior_key = self._behavior_key(raw_behavior)
        clean_behavior = self._clean_label(raw_behavior)

        # 2. Away detection
        if idle > self.config.away_threshold or signals.get("screen_locked", False):
            self.session_start = now
            self.last_behavior = "Away"
            self.last_fatigue = 0.0
            return {
                "trigger": False,
                "behavior": "Away",
                "reason": "Away Reset",
                "message": self.SMART_MESSAGES["away_reset"],
                "fatigue_score": 0.0,
                "interval_used": self.config.base_interval
            }

        # 3. Meeting suppression
        if self.meeting_mode.should_suppress_breaks(signals, behavior_key):
            self.last_behavior = "Meeting"
            self.last_fatigue = 0.0
            return {
                "trigger": False,
                "behavior": "Meeting",
                "reason": "Meeting Suppressed",
                "message": self.SMART_MESSAGES["meeting_suppressed"],
                "fatigue_score": 0.0,
                "interval_used": self.config.base_interval
            }

        # 4. Entertainment suppression
        if behavior_key in ["watching", "video"]:
            return {
                "trigger": False,
                "behavior": "Watching",
                "reason": "Watching Suppressed",
                "message": self.SMART_MESSAGES["watching_suppressed"],
                "fatigue_score": 0.0,
                "interval_used": self.config.base_interval
            }

        if behavior_key == "gaming":
            return {
                "trigger": False,
                "behavior": "Gaming",
                "reason": "Gaming Suppressed",
                "message": self.SMART_MESSAGES["gaming_suppressed"],
                "fatigue_score": 0.0,
                "interval_used": self.config.base_interval
            }

        # 5. Compute fatigue
        fatigue_score = self.fatigue_model.compute_fatigue(signals, behavior_key)
        self.last_behavior = clean_behavior
        self.last_fatigue = fatigue_score

        # 6. Dynamic interval
        interval = self.config.base_interval
        if fatigue_score > 70:
            interval *= 0.7
        elif fatigue_score > 50:
            interval *= 0.85
        elif fatigue_score < 20:
            interval *= 1.15

        interval = max(self.config.min_interval, min(self.config.max_interval, interval))

        # 7. Minimum spacing
        elapsed = now - self.last_break_time
        if elapsed < self.config.min_interval:
            return {
                "trigger": False,
                "behavior": clean_behavior,
                "reason": "Recent Break",
                "message": self.SMART_MESSAGES["recent_break"],
                "fatigue_score": fatigue_score,
                "interval_used": interval
            }

        # 8. Hard interval reached
        if now - self.session_start >= interval:
            self.last_break_time = now
            return {
                "trigger": True,
                "behavior": clean_behavior,
                "reason": "Interval Reached",
                "message": self.SMART_MESSAGES["interval_reached"],
                "fatigue_score": fatigue_score,
                "interval_used": interval
            }

        # 9. Fatigue early break
        if fatigue_score >= 75:
            self.last_break_time = now
            return {
                "trigger": True,
                "behavior": clean_behavior,
                "reason": "Fatigue Early",
                "message": self.SMART_MESSAGES["fatigue_early"],
                "fatigue_score": fatigue_score,
                "interval_used": interval
            }

        # 10. Strain risk
        if clean_behavior in ["Eye Strain Risk", "Posture Risk"]:
            if fatigue_score >= 55:
                self.last_break_time = now
                return {
                    "trigger": True,
                    "behavior": clean_behavior,
                    "reason": "Strain Risk",
                    "message": self.SMART_MESSAGES["strain_risk"],
                    "fatigue_score": fatigue_score,
                    "interval_used": interval
                }

        # 11. No break
        return {
            "trigger": False,
            "behavior": clean_behavior,
            "reason": "Not Due",
            "message": self.SMART_MESSAGES["not_due"],
            "fatigue_score": fatigue_score,
            "interval_used": interval
        }

    # ---------------------------------------------------------
    # UPDATE WRAPPER (required by MainWindow)
    # ---------------------------------------------------------
    def update(self, signals, dt):
        return self.should_trigger_break(signals)

    # ---------------------------------------------------------
    # RESET
    # ---------------------------------------------------------
    def reset_after_break(self):
        now = time.time()
        self.session_start = now
        self.last_break_time = now
        self.last_behavior = "Idle"
        self.last_fatigue = 0.0
