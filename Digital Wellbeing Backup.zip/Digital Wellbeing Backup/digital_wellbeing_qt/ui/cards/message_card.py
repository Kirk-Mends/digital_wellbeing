from PySide6.QtWidgets import QWidget
from PySide6.QtCore import QSize
from ui.pages.shared.fluent_card import FluentCard
from ui.core.card_registry import CardRegistry

DEFAULT_CARD_WIDTH = 320
LAPTOP_FULL_WIDTH = 680


class MessageCard(FluentCard):
    def __init__(self, height: int | None = None, fullWidthOnLaptop: bool = False, parent: QWidget | None = None):
        super().__init__(
            title="AI message",
            accent_color="#0FB5A9",
            has_spark=False,
        )

        # ✅ FIXED: register instead of unregister
        CardRegistry.register(self)

        self.fullWidthOnLaptop = fullWidthOnLaptop

        if height is not None:
            self.setMinimumHeight(height)

        self.setFixedWidth(DEFAULT_CARD_WIDTH)
        self.setParent(parent)
        self.setProperty("fullWidthOnLaptop", fullWidthOnLaptop)

        self.update_value(
            "Context‑aware guidance, nudges, and reflections will appear here as short, human‑sounding messages."
        )

        self.last_message = None

    def sizeHint(self) -> QSize:
        if self.fullWidthOnLaptop:
            return QSize(LAPTOP_FULL_WIDTH, self.minimumHeight())
        return QSize(DEFAULT_CARD_WIDTH, self.minimumHeight())

    def closeEvent(self, event):
        CardRegistry.unregister(self)
        super().closeEvent(event)

    def update_from_engine(self, behavior, fatigue, reason, trigger, next_break_seconds, session_start, monitoring):
        if trigger and reason:
            if reason != self.last_message:
                self.update_value(reason)
                self.last_message = reason
