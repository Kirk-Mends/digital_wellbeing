# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QLabel, QTabWidget, QFrame, QHBoxLayout
# )
# from PySide6.QtCore import Qt
# import pyqtgraph as pg

# from core.analytics_engine import AnalyticsEngine


# class AnalyticsSuitePage(QWidget):
#     def __init__(self):
#         super().__init__()
#         self.setObjectName("AnalyticsSuitePage")

#         self.engine = AnalyticsEngine()

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         title = QLabel("Analytics")
#         title.setObjectName("PageTitle")
#         layout.addWidget(title)

#         # ⭐ CREATE THE TAB WIDGET BEFORE ADDING ANY TABS
#         self.tabs = QTabWidget()
#         self.tabs.setObjectName("AnalyticsTabs")
#         layout.addWidget(self.tabs)

#         # ⭐ NOW ADD ALL TABS IN THIS ORDER
#         self._init_weekly_tab()
#         self._init_monthly_tab()
#         self._init_insights_tab()
#         self._init_reports_tab()
#         self._init_heatmap_tab()
#         self._init_break_score_tab()   # <-- this must come LAST

#         # Refresh everything
#         self.refresh_all()

#         # REFRECH LOGIC
#     def _refresh_break_score(self):
#         score = self.engine.break_quality_score()
#         if not score:
#             self.break_score_label.setText("Not enough data to compute break quality.")
#             return

#         s = score["score"]
#         freq = score["frequency"]
#         cons = score["consistency"]
#         timing = score["timing"]

#         recommendation = (
#             "Great consistency — keep it up."
#             if s >= 80 else
#             "Your break timing is good, but consistency can improve."
#             if cons < 70 else
#             "Try taking shorter, more frequent breaks to improve recovery."
#         )

#         self.break_score_label.setText(
#             f"Break Quality Score: {s}/100\n\n"
#             f"• Frequency score: {freq}/100\n"
#             f"• Consistency score: {cons}/100\n"
#             f"• Timing score: {timing}/100\n\n"
#             f"{recommendation}"
#         )

#         self._refresh_break_score()

#         # ---------- BREAK SCORE TAB ----------
#     def _init_break_score_tab(self):
#         w = QWidget()
#         v = QVBoxLayout(w)
#         v.setContentsMargins(10, 10, 10, 10)
#         v.setSpacing(10)

#         self.break_score_label = QLabel()
#         self.break_score_label.setObjectName("AnalyticsText")
#         self.break_score_label.setWordWrap(True)
#         v.addWidget(self.break_score_label)

#         self.tabs.addTab(w, "Break Score")

#     # ---------- WEEKLY TAB ----------

#     def _init_weekly_tab(self):
#         w = QWidget()
#         v = QVBoxLayout(w)
#         v.setContentsMargins(10, 10, 10, 10)
#         v.setSpacing(10)

#         self.weekly_summary_label = QLabel()
#         self.weekly_summary_label.setObjectName("AnalyticsText")
#         self.weekly_summary_label.setWordWrap(True)
#         v.addWidget(self.weekly_summary_label)

#         self.weekly_chart = pg.PlotWidget()
#         self.weekly_chart.setBackground(None)
#         self.weekly_chart.showGrid(x=False, y=True, alpha=0.2)
#         self.weekly_chart.getAxis("left").setVisible(False)
#         self.weekly_chart.getAxis("bottom").setVisible(False)
#         self.weekly_bar = pg.BarGraphItem(x=[], height=[], width=0.6, brush="#0078D7")
#         self.weekly_chart.addItem(self.weekly_bar)
#         v.addWidget(self.weekly_chart)

#         self.tabs.addTab(w, "Weekly")

#     # ---------- MONTHLY TAB ----------

#     def _init_monthly_tab(self):
#         w = QWidget()
#         v = QVBoxLayout(w)
#         v.setContentsMargins(10, 10, 10, 10)
#         v.setSpacing(10)

#         self.monthly_summary_label = QLabel()
#         self.monthly_summary_label.setObjectName("AnalyticsText")
#         self.monthly_summary_label.setWordWrap(True)
#         v.addWidget(self.monthly_summary_label)

#         self.tabs.addTab(w, "Monthly")

#     # ---------- INSIGHTS TAB ----------

#     def _init_insights_tab(self):
#         w = QWidget()
#         v = QVBoxLayout(w)
#         v.setContentsMargins(10, 10, 10, 10)
#         v.setSpacing(10)

#         self.insights_container = QVBoxLayout()
#         v.addLayout(self.insights_container)

#         self.tabs.addTab(w, "AI Insights")

#     # ---------- REPORTS TAB ----------

#     def _init_reports_tab(self):
#         w = QWidget()
#         v = QVBoxLayout(w)
#         v.setContentsMargins(10, 10, 10, 10)
#         v.setSpacing(10)

#         self.report_label = QLabel()
#         self.report_label.setObjectName("AnalyticsText")
#         self.report_label.setWordWrap(True)
#         v.addWidget(self.report_label)

#         self.tabs.addTab(w, "Reports")

#     # ---------- HEATMAP TAB ----------

#     def _init_heatmap_tab(self):
#         w = QWidget()
#         v = QVBoxLayout(w)
#         v.setContentsMargins(10, 10, 10, 10)
#         v.setSpacing(10)

#         self.heatmap_chart = pg.PlotWidget()
#         self.heatmap_chart.setBackground(None)
#         self.heatmap_chart.showGrid(x=False, y=True, alpha=0.2)
#         self.heatmap_chart.getAxis("left").setVisible(False)
#         self.heatmap_chart.getAxis("bottom").setVisible(True)
#         self.heatmap_chart.getAxis("bottom").setTicks([[
#             (0, "Mon"), (1, "Tue"), (2, "Wed"),
#             (3, "Thu"), (4, "Fri"), (5, "Sat"), (6, "Sun")
#         ]])

#         self.heatmap_bar = pg.BarGraphItem(x=[], height=[], width=0.6, brush="#00B294")
#         self.heatmap_chart.addItem(self.heatmap_bar)
#         v.addWidget(self.heatmap_chart)

#         self.tabs.addTab(w, "Heatmap")

#     # ---------- REFRESH ----------

#     def refresh_all(self):
#         self._refresh_weekly()
#         self._refresh_monthly()
#         self._refresh_insights()
#         self._refresh_reports()
#         self._refresh_heatmap()

#     def _refresh_weekly(self):
#         summary = self.engine.weekly_summary()
#         if not summary:
#             self.weekly_summary_label.setText("No weekly data available.")
#             self.weekly_bar.setOpts(x=[], height=[])
#             return

#         self.weekly_summary_label.setText(
#             f"Total: {summary['total']:.0f} min • "
#             f"Avg: {summary['avg']:.1f} min/day • "
#             f"Best: {summary['best_day']} • "
#             f"Worst: {summary['worst_day']} • "
#             f"Trend: {'↑' if summary['trend']=='up' else '↓'}"
#         )

#         days = sorted(summary["daily"].keys())
#         vals = [summary["daily"][d] for d in days]
#         x = list(range(len(days)))
#         self.weekly_bar.setOpts(x=x, height=vals)

#     def _refresh_monthly(self):
#         summary = self.engine.monthly_summary()
#         if not summary:
#             self.monthly_summary_label.setText("No monthly data available.")
#             return

#         self.monthly_summary_label.setText(
#             f"Total: {summary['total']:.0f} min • "
#             f"Avg: {summary['avg']:.1f} min/day • "
#             f"Best day: {summary['best_day']} • "
#             f"Worst day: {summary['worst_day']}\n"
#             f"Best week: {summary['best_week']:.0f} min • "
#             f"Worst week: {summary['worst_week']:.0f} min • "
#             f"Consistency: {summary['consistency']:.0f}/100 • "
#             f"Trend: {'↑' if summary['trend']=='up' else '↓'}"
#         )

#     def _refresh_insights(self):
#         insights = self.engine.ai_insights()

#         # clear
#         while self.insights_container.count():
#             item = self.insights_container.takeAt(0)
#             if item.widget():
#                 item.widget().deleteLater()

#         for text in insights:
#             card = QFrame()
#             card.setObjectName("InsightCard")
#             v = QVBoxLayout(card)
#             v.setContentsMargins(12, 12, 12, 12)
#             lbl = QLabel(text)
#             lbl.setObjectName("InsightText")
#             lbl.setWordWrap(True)
#             v.addWidget(lbl)
#             self.insights_container.addWidget(card)

#     def _refresh_reports(self):
#         weekly = self.engine.weekly_summary()
#         monthly = self.engine.monthly_summary()

#         if not weekly and not monthly:
#             self.report_label.setText("No data available for reports yet.")
#             return

#         parts = []

#         if weekly:
#             parts.append(
#                 f"Weekly:\n"
#                 f"- Total: {weekly['total']:.0f} min\n"
#                 f"- Avg: {weekly['avg']:.1f} min/day\n"
#                 f"- Best: {weekly['best_day']}\n"
#                 f"- Worst: {weekly['worst_day']}\n"
#                 f"- Trend: {'improving' if weekly['trend']=='up' else 'declining'}\n"
#             )

#         if monthly:
#             parts.append(
#                 f"Monthly:\n"
#                 f"- Total: {monthly['total']:.0f} min\n"
#                 f"- Avg: {monthly['avg']:.1f} min/day\n"
#                 f"- Best day: {monthly['best_day']}\n"
#                 f"- Worst day: {monthly['worst_day']}\n"
#                 f"- Best week: {monthly['best_week']:.0f} min\n"
#                 f"- Worst week: {monthly['worst_week']:.0f} min\n"
#                 f"- Consistency: {monthly['consistency']:.0f}/100\n"
#                 f"- Trend: {'improving' if monthly['trend']=='up' else 'declining'}\n"
#             )

#         self.report_label.setText("\n\n".join(parts))

#     def _refresh_heatmap(self):
#         data = self.engine.heatmap_data()
#         if not data:
#             self.heatmap_bar.setOpts(x=[], height=[])
#             return

#         x = list(data.keys())
#         vals = [data[i] for i in x]
#         self.heatmap_bar.setOpts(x=x, height=vals)














# # Cleaned for UI no dashes

# from PySide6.QtWidgets import (
#     QWidget, QVBoxLayout, QLabel, QTabWidget, QFrame
# )
# from PySide6.QtCore import Qt
# import pyqtgraph as pg

# from core.analytics_engine import AnalyticsEngine


# class AnalyticsSuitePage(QWidget):
#     def __init__(self):
#         super().__init__()
#         self.setObjectName("AnalyticsSuitePage")

#         self.engine = AnalyticsEngine()

#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(20, 20, 20, 20)
#         layout.setSpacing(20)

#         title = QLabel("Analytics")
#         title.setObjectName("PageTitle")
#         layout.addWidget(title)

#         # Tab widget
#         self.tabs = QTabWidget()
#         self.tabs.setObjectName("AnalyticsTabs")
#         layout.addWidget(self.tabs)

#         # Tabs
#         self._init_weekly_tab()
#         self._init_monthly_tab()
#         self._init_insights_tab()
#         self._init_reports_tab()
#         self._init_heatmap_tab()
#         self._init_break_score_tab()  # must remain last

#         # Initial refresh
#         self.refresh_all()

#     # ---------------------------------------------------------
#     # BREAK SCORE TAB
#     # ---------------------------------------------------------
#     def _init_break_score_tab(self):
#         w = QWidget()
#         v = QVBoxLayout(w)
#         v.setContentsMargins(10, 10, 10, 10)
#         v.setSpacing(10)

#         self.break_score_label = QLabel()
#         self.break_score_label.setObjectName("AnalyticsText")
#         self.break_score_label.setWordWrap(True)
#         v.addWidget(self.break_score_label)

#         self.tabs.addTab(w, "Break Score")

#     def _refresh_break_score(self):
#         score = self.engine.break_quality_score()

#         if not score:
#             self.break_score_label.setText("Not enough data to compute break quality.")
#             return

#         s = score["score"]
#         freq = score["frequency"]
#         cons = score["consistency"]
#         timing = score["timing"]

#         # Clean, readable recommendation text
#         if s >= 80:
#             recommendation = "Great consistency — keep it up."
#         elif cons < 70:
#             recommendation = "Your break timing is good, but consistency can improve."
#         else:
#             recommendation = "Try taking shorter, more frequent breaks to improve recovery."

#         self.break_score_label.setText(
#             f"Break Quality Score: {s}/100\n\n"
#             f"• Frequency Score: {freq}/100\n"
#             f"• Consistency Score: {cons}/100\n"
#             f"• Timing Score: {timing}/100\n\n"
#             f"{recommendation}"
#         )

#     # ---------------------------------------------------------
#     # WEEKLY TAB
#     # ---------------------------------------------------------
#     def _init_weekly_tab(self):
#         w = QWidget()
#         v = QVBoxLayout(w)
#         v.setContentsMargins(10, 10, 10, 10)
#         v.setSpacing(10)

#         self.weekly_summary_label = QLabel()
#         self.weekly_summary_label.setObjectName("AnalyticsText")
#         self.weekly_summary_label.setWordWrap(True)
#         v.addWidget(self.weekly_summary_label)

#         self.weekly_chart = pg.PlotWidget()
#         self.weekly_chart.setBackground(None)
#         self.weekly_chart.showGrid(x=False, y=True, alpha=0.2)
#         self.weekly_chart.getAxis("left").setVisible(False)
#         self.weekly_chart.getAxis("bottom").setVisible(False)

#         self.weekly_bar = pg.BarGraphItem(x=[], height=[], width=0.6, brush="#0078D7")
#         self.weekly_chart.addItem(self.weekly_bar)
#         v.addWidget(self.weekly_chart)

#         self.tabs.addTab(w, "Weekly")

#     def _refresh_weekly(self):
#         summary = self.engine.weekly_summary()

#         if not summary:
#             self.weekly_summary_label.setText("No weekly data available.")
#             self.weekly_bar.setOpts(x=[], height=[])
#             return

#         trend_arrow = "↑" if summary["trend"] == "up" else "↓"

#         self.weekly_summary_label.setText(
#             f"Total: {summary['total']:.0f} min • "
#             f"Avg: {summary['avg']:.1f} min/day • "
#             f"Best: {summary['best_day']} • "
#             f"Worst: {summary['worst_day']} • "
#             f"Trend: {trend_arrow}"
#         )

#         days = sorted(summary["daily"].keys())
#         vals = [summary["daily"][d] for d in days]
#         x = list(range(len(days)))

#         self.weekly_bar.setOpts(x=x, height=vals)

#     # ---------------------------------------------------------
#     # MONTHLY TAB
#     # ---------------------------------------------------------
#     def _init_monthly_tab(self):
#         w = QWidget()
#         v = QVBoxLayout(w)
#         v.setContentsMargins(10, 10, 10, 10)
#         v.setSpacing(10)

#         self.monthly_summary_label = QLabel()
#         self.monthly_summary_label.setObjectName("AnalyticsText")
#         self.monthly_summary_label.setWordWrap(True)
#         v.addWidget(self.monthly_summary_label)

#         self.tabs.addTab(w, "Monthly")

#     def _refresh_monthly(self):
#         summary = self.engine.monthly_summary()

#         if not summary:
#             self.monthly_summary_label.setText("No monthly data available.")
#             return

#         trend_arrow = "↑" if summary["trend"] == "up" else "↓"

#         self.monthly_summary_label.setText(
#             f"Total: {summary['total']:.0f} min • "
#             f"Avg: {summary['avg']:.1f} min/day • "
#             f"Best Day: {summary['best_day']} • "
#             f"Worst Day: {summary['worst_day']}\n"
#             f"Best Week: {summary['best_week']:.0f} min • "
#             f"Worst Week: {summary['worst_week']:.0f} min • "
#             f"Consistency: {summary['consistency']:.0f}/100 • "
#             f"Trend: {trend_arrow}"
#         )

#     # ---------------------------------------------------------
#     # INSIGHTS TAB
#     # ---------------------------------------------------------
#     def _init_insights_tab(self):
#         w = QWidget()
#         v = QVBoxLayout(w)
#         v.setContentsMargins(10, 10, 10, 10)
#         v.setSpacing(10)

#         self.insights_container = QVBoxLayout()
#         v.addLayout(self.insights_container)

#         self.tabs.addTab(w, "AI Insights")

#     def _refresh_insights(self):
#         insights = self.engine.ai_insights()

#         # Clear old cards
#         while self.insights_container.count():
#             item = self.insights_container.takeAt(0)
#             if item.widget():
#                 item.widget().deleteLater()

#         # Add new cards
#         for text in insights:
#             card = QFrame()
#             card.setObjectName("InsightCard")
#             v = QVBoxLayout(card)
#             v.setContentsMargins(12, 12, 12, 12)

#             lbl = QLabel(text)
#             lbl.setObjectName("InsightText")
#             lbl.setWordWrap(True)
#             v.addWidget(lbl)

#             self.insights_container.addWidget(card)

#     # ---------------------------------------------------------
#     # REPORTS TAB
#     # ---------------------------------------------------------
#     def _init_reports_tab(self):
#         w = QWidget()
#         v = QVBoxLayout(w)
#         v.setContentsMargins(10, 10, 10, 10)
#         v.setSpacing(10)

#         self.report_label = QLabel()
#         self.report_label.setObjectName("AnalyticsText")
#         self.report_label.setWordWrap(True)
#         v.addWidget(self.report_label)

#         self.tabs.addTab(w, "Reports")

#     def _refresh_reports(self):
#         weekly = self.engine.weekly_summary()
#         monthly = self.engine.monthly_summary()

#         if not weekly and not monthly:
#             self.report_label.setText("No data available for reports yet.")
#             return

#         parts = []

#         if weekly:
#             parts.append(
#                 f"Weekly:\n"
#                 f"- Total: {weekly['total']:.0f} min\n"
#                 f"- Avg: {weekly['avg']:.1f} min/day\n"
#                 f"- Best: {weekly['best_day']}\n"
#                 f"- Worst: {weekly['worst_day']}\n"
#                 f"- Trend: {'Improving' if weekly['trend']=='up' else 'Declining'}\n"
#             )

#         if monthly:
#             parts.append(
#                 f"Monthly:\n"
#                 f"- Total: {monthly['total']:.0f} min\n"
#                 f"- Avg: {monthly['avg']:.1f} min/day\n"
#                 f"- Best Day: {monthly['best_day']}\n"
#                 f"- Worst Day: {monthly['worst_day']}\n"
#                 f"- Best Week: {monthly['best_week']:.0f} min\n"
#                 f"- Worst Week: {monthly['worst_week']:.0f} min\n"
#                 f"- Consistency: {monthly['consistency']:.0f}/100\n"
#                 f"- Trend: {'Improving' if monthly['trend']=='up' else 'Declining'}\n"
#             )

#         self.report_label.setText("\n\n".join(parts))

#     # ---------------------------------------------------------
#     # HEATMAP TAB
#     # ---------------------------------------------------------
#     def _init_heatmap_tab(self):
#         w = QWidget()
#         v = QVBoxLayout(w)
#         v.setContentsMargins(10, 10, 10, 10)
#         v.setSpacing(10)

#         self.heatmap_chart = pg.PlotWidget()
#         self.heatmap_chart.setBackground(None)
#         self.heatmap_chart.showGrid(x=False, y=True, alpha=0.2)
#         self.heatmap_chart.getAxis("left").setVisible(False)
#         self.heatmap_chart.getAxis("bottom").setVisible(True)

#         self.heatmap_chart.getAxis("bottom").setTicks([[
#             (0, "Mon"), (1, "Tue"), (2, "Wed"),
#             (3, "Thu"), (4, "Fri"), (5, "Sat"), (6, "Sun")
#         ]])

#         self.heatmap_bar = pg.BarGraphItem(x=[], height=[], width=0.6, brush="#00B294")
#         self.heatmap_chart.addItem(self.heatmap_bar)
#         v.addWidget(self.heatmap_chart)

#         self.tabs.addTab(w, "Heatmap")

#     def _refresh_heatmap(self):
#         data = self.engine.heatmap_data()

#         if not data:
#             self.heatmap_bar.setOpts(x=[], height=[])
#             return

#         x = list(data.keys())
#         vals = [data[i] for i in x]

#         self.heatmap_bar.setOpts(x=x, height=vals)

#     # ---------------------------------------------------------
#     # GLOBAL REFRESH
#     # ---------------------------------------------------------
#     def refresh_all(self):
#         self._refresh_weekly()
#         self._refresh_monthly()
#         self._refresh_insights()
#         self._refresh_reports()
#         self._refresh_heatmap()
#         self._refresh_break_score()














# 5
# Upgrade design

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QTabWidget, QFrame, QSizePolicy, QScrollArea
)
from PySide6.QtCore import Qt
import pyqtgraph as pg

from core.analytics_engine import AnalyticsEngine


# -----------------------------
# Color palette (Apple-style vibrant)
# -----------------------------
class AnalyticsColors:
    BEHAVIOR = "#0A84FF"   # blue
    FATIGUE = "#FF9F0A"    # orange
    BREAK = "#30D158"      # green
    SUPPRESSION = "#FF453A"  # red
    INSIGHT = "#BF5AF2"    # purple
    GRID = (255, 255, 255, 40)


CARD_HEIGHT = 320  # fixed height for chart cards


# -----------------------------
# Generic card container
# -----------------------------
class AnalyticsCard(QFrame):
    """
    Simple Fluent-style card with a title and content area.
    Used for both charts and text.
    """
    def __init__(self, title: str):
        super().__init__()
        self.setObjectName("AnalyticsCard")
        self.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
        self.setMinimumHeight(CARD_HEIGHT)

        layout = QVBoxLayout(self)
        layout.setContentsMargins(14, 14, 14, 14)
        layout.setSpacing(8)

        self.title_label = QLabel(title)
        self.title_label.setObjectName("AnalyticsCardTitle")
        layout.addWidget(self.title_label)

        self.body_layout = QVBoxLayout()
        self.body_layout.setContentsMargins(0, 0, 0, 0)
        self.body_layout.setSpacing(4)
        layout.addLayout(self.body_layout)


# -----------------------------
# Chart card wrapper
# -----------------------------
class ChartCard(AnalyticsCard):
    """
    Card that hosts a PyQtGraph PlotWidget with consistent styling.
    """
    def __init__(self, title: str, color: str):
        super().__init__(title)
        self.color = color

        self.plot = pg.PlotWidget()
        self.plot.setBackground(None)
        self.plot.showGrid(x=False, y=True, alpha=0.15)
        self.plot.getAxis("left").setVisible(False)
        self.plot.getAxis("bottom").setVisible(False)
        self.plot.setMenuEnabled(False)
        self.plot.setMouseEnabled(x=False, y=False)
        self.plot.setClipToView(True)
        self.plot.setDownsampling(mode="peak")
        self.plot.setAntialiasing(True)

        # Light grid color
        self.plot.getPlotItem().getViewBox().setBorder(None)

        self.body_layout.addWidget(self.plot)

    def clear(self):
        self.plot.clear()


# -----------------------------
# Two-column layout helper
# -----------------------------
class TwoColumnLayout(QVBoxLayout):
    """
    Simple helper to place cards in two columns with vertical flow.
    """
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setContentsMargins(10, 10, 10, 10)
        self.setSpacing(10)

        self.row_layout = None
        self._items_in_row = 0

    def add_card(self, card: QWidget):
        if self.row_layout is None or self._items_in_row >= 2:
            self.row_layout = QHBoxLayout()
            self.row_layout.setSpacing(10)
            self.addLayout(self.row_layout)
            self._items_in_row = 0

        self.row_layout.addWidget(card)
        self._items_in_row += 1


# -----------------------------
# Main Analytics Suite Page
# -----------------------------
class AnalyticsSuitePage(QWidget):
    def __init__(self):
        super().__init__()
        self.setObjectName("AnalyticsSuitePage")

        self.engine = AnalyticsEngine()

        root_layout = QVBoxLayout(self)
        root_layout.setContentsMargins(20, 20, 20, 20)
        root_layout.setSpacing(20)

        title = QLabel("Analytics")
        title.setObjectName("PageTitle")
        root_layout.addWidget(title)

        # Tab widget
        self.tabs = QTabWidget()
        self.tabs.setObjectName("AnalyticsTabs")
        root_layout.addWidget(self.tabs)

        # Tabs
        self._init_behavior_tab()
        self._init_fatigue_tab()
        self._init_break_tab()
        self._init_suppression_tab()
        self._init_time_of_day_tab()
        self._init_weekly_tab()
        self._init_monthly_tab()
        self._init_insights_tab()

        # Initial refresh
        self.refresh_all()

    # -------------------------
    # Tab helpers
    # -------------------------
    def _create_scrollable_tab(self):
        """
        Creates a scrollable area with a two-column layout inside.
        Returns (container_widget, two_column_layout).
        """
        container = QWidget()
        outer_layout = QVBoxLayout(container)
        outer_layout.setContentsMargins(0, 0, 0, 0)
        outer_layout.setSpacing(0)

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)

        inner = QWidget()
        two_col = TwoColumnLayout(inner)
        scroll.setWidget(inner)

        outer_layout.addWidget(scroll)
        return container, two_col

    # -------------------------
    # BEHAVIOR TAB
    # -------------------------
    def _init_behavior_tab(self):
        w, layout = self._create_scrollable_tab()
        self.behavior_layout = layout

        # Behavior distribution
        self.card_behavior_dist = ChartCard("Behavior Distribution", AnalyticsColors.BEHAVIOR)
        self.behavior_layout.add_card(self.card_behavior_dist)

        # Behavior timeline
        self.card_behavior_timeline = ChartCard("Behavior Timeline", AnalyticsColors.BEHAVIOR)
        self.behavior_layout.add_card(self.card_behavior_timeline)

        # Behavior by time of day
        self.card_behavior_by_hour = ChartCard("Behavior by Time of Day", AnalyticsColors.BEHAVIOR)
        self.behavior_layout.add_card(self.card_behavior_by_hour)

        # Longest streak (text card)
        self.card_behavior_streak = AnalyticsCard("Longest Focus Streak")
        self.behavior_streak_label = QLabel("No data yet.")
        self.behavior_streak_label.setObjectName("AnalyticsText")
        self.behavior_streak_label.setWordWrap(True)
        self.card_behavior_streak.body_layout.addWidget(self.behavior_streak_label)
        self.behavior_layout.add_card(self.card_behavior_streak)

        self.tabs.addTab(w, "Behavior")

    def _refresh_behavior_tab(self):
        # Distribution
        dist = self.engine.behavior_distribution()
        self.card_behavior_dist.clear()
        if dist:
            behaviors = list(dist.keys())
            values = list(dist.values())
            x = range(len(behaviors))
            bg = pg.BarGraphItem(
                x=list(x),
                height=values,
                width=0.6,
                brush=AnalyticsColors.BEHAVIOR
            )
            self.card_behavior_dist.plot.addItem(bg)
            ax = self.card_behavior_dist.plot.getAxis("bottom")
            ax.setTicks([list(zip(x, behaviors))])
            ax.setVisible(True)

        # Timeline (simple line by index for now)
        timeline = self.engine.behavior_timeline()
        self.card_behavior_timeline.clear()
        times = timeline.get("times", [])
        behaviors = timeline.get("behaviors", [])
        if times and behaviors:
            # Map behaviors to numeric categories for a simple stepped line
            unique_behaviors = list(dict.fromkeys(behaviors))
            mapping = {b: i for i, b in enumerate(unique_behaviors)}
            y = [mapping[b] for b in behaviors]
            curve = self.card_behavior_timeline.plot.plot(
                list(range(len(times))), y,
                pen=pg.mkPen(AnalyticsColors.BEHAVIOR, width=2)
            )
            self.card_behavior_timeline.plot.getAxis("bottom").setVisible(False)

        # Behavior by hour (simple bar)
        by_hour = self.engine.behavior_by_hour()
        self.card_behavior_by_hour.clear()
        if by_hour:
            hours = sorted(by_hour.keys())
            vals = [sum(by_hour[h].values()) for h in hours]
            x = list(range(len(hours)))
            bg = pg.BarGraphItem(
                x=x,
                height=vals,
                width=0.6,
                brush=AnalyticsColors.BEHAVIOR
            )
            self.card_behavior_by_hour.plot.addItem(bg)
            labels = [f"{h:02d}:00" for h in hours]
            ax = self.card_behavior_by_hour.plot.getAxis("bottom")
            ax.setTicks([list(zip(x, labels))])
            ax.setVisible(True)

        # Longest streak
        streak = self.engine.longest_behavior_streak()
        if streak:
            self.behavior_streak_label.setText(
                f"Longest streak: {streak['behavior']} for {streak['minutes']:.0f} minutes."
            )
        else:
            self.behavior_streak_label.setText("No behavior streak data available yet.")

    # -------------------------
    # FATIGUE TAB
    # -------------------------
    def _init_fatigue_tab(self):
        w, layout = self._create_scrollable_tab()
        self.fatigue_layout = layout

        self.card_fatigue_trend = ChartCard("Fatigue Trend", AnalyticsColors.FATIGUE)
        self.fatigue_layout.add_card(self.card_fatigue_trend)

        self.card_fatigue_by_behavior = ChartCard("Fatigue by Behavior", AnalyticsColors.FATIGUE)
        self.fatigue_layout.add_card(self.card_fatigue_by_behavior)

        self.card_fatigue_recovery = ChartCard("Fatigue Recovery After Breaks", AnalyticsColors.FATIGUE)
        self.fatigue_layout.add_card(self.card_fatigue_recovery)

        self.card_fatigue_peak = AnalyticsCard("Highest Fatigue Moment")
        self.fatigue_peak_label = QLabel("No data yet.")
        self.fatigue_peak_label.setObjectName("AnalyticsText")
        self.fatigue_peak_label.setWordWrap(True)
        self.card_fatigue_peak.body_layout.addWidget(self.fatigue_peak_label)
        self.fatigue_layout.add_card(self.card_fatigue_peak)

        self.tabs.addTab(w, "Fatigue")

    def _refresh_fatigue_tab(self):
        # Trend
        trend = self.engine.fatigue_trend()
        self.card_fatigue_trend.clear()
        times = trend.get("times", [])
        vals = trend.get("fatigue", [])
        if times and vals:
            self.card_fatigue_trend.plot.plot(
                list(range(len(times))), vals,
                pen=pg.mkPen(AnalyticsColors.FATIGUE, width=2)
            )
            self.card_fatigue_trend.plot.setYRange(0, 100)

        # By behavior
        by_behavior = self.engine.fatigue_by_behavior()
        self.card_fatigue_by_behavior.clear()
        if by_behavior:
            behaviors = list(by_behavior.keys())
            vals = list(by_behavior.values())
            x = list(range(len(behaviors)))
            bg = pg.BarGraphItem(
                x=x,
                height=vals,
                width=0.6,
                brush=AnalyticsColors.FATIGUE
            )
            self.card_fatigue_by_behavior.plot.addItem(bg)
            ax = self.card_fatigue_by_behavior.plot.getAxis("bottom")
            ax.setTicks([list(zip(x, behaviors))])
            ax.setVisible(True)
            self.card_fatigue_by_behavior.plot.setYRange(0, 100)

        # Recovery
        rec = self.engine.fatigue_recovery_after_breaks()
        self.card_fatigue_recovery.clear()
        rt = rec.get("times", [])
        rv = rec.get("fatigue", [])
        if rt and rv:
            self.card_fatigue_recovery.plot.plot(
                list(range(len(rt))), rv,
                pen=pg.mkPen(AnalyticsColors.FATIGUE, width=2)
            )
            self.card_fatigue_recovery.plot.setYRange(0, 100)

        # Peak
        peak = self.engine.highest_fatigue_moment()
        if peak:
            self.fatigue_peak_label.setText(
                f"Highest fatigue: {peak['fatigue']:.0f}/100 at {peak['time']}."
            )
        else:
            self.fatigue_peak_label.setText("No fatigue peak data available yet.")

    # -------------------------
    # BREAK TAB
    # -------------------------
    def _init_break_tab(self):
        w, layout = self._create_scrollable_tab()
        self.break_layout = layout

        self.card_break_reasons = ChartCard("Break Reasons", AnalyticsColors.BREAK)
        self.break_layout.add_card(self.card_break_reasons)

        self.card_break_timing = ChartCard("Break Timing Quality", AnalyticsColors.BREAK)
        self.break_layout.add_card(self.card_break_timing)

        self.card_break_timeline = ChartCard("Break Events Timeline", AnalyticsColors.BREAK)
        self.break_layout.add_card(self.card_break_timeline)

        self.card_break_suppression = ChartCard("Break Suppression", AnalyticsColors.BREAK)
        self.break_layout.add_card(self.card_break_suppression)

        self.tabs.addTab(w, "Breaks")

    def _refresh_break_tab(self):
        # Reasons
        reasons = self.engine.break_reasons()
        self.card_break_reasons.clear()
        if reasons:
            labels = list(reasons.keys())
            vals = list(reasons.values())
            x = list(range(len(labels)))
            bg = pg.BarGraphItem(
                x=x,
                height=vals,
                width=0.6,
                brush=AnalyticsColors.BREAK
            )
            self.card_break_reasons.plot.addItem(bg)
            ax = self.card_break_reasons.plot.getAxis("bottom")
            ax.setTicks([list(zip(x, labels))])
            ax.setVisible(True)

        # Timing quality
        timing = self.engine.break_timing_quality()
        self.card_break_timing.clear()
        if timing:
            labels = ["Early", "On Time", "Late"]
            vals = [
                timing.get("early", 0),
                timing.get("on_time", 0),
                timing.get("late", 0),
            ]
            x = list(range(len(labels)))
            bg = pg.BarGraphItem(
                x=x,
                height=vals,
                width=0.6,
                brush=AnalyticsColors.BREAK
            )
            self.card_break_timing.plot.addItem(bg)
            ax = self.card_break_timing.plot.getAxis("bottom")
            ax.setTicks([list(zip(x, labels))])
            ax.setVisible(True)

        # Timeline
        timeline = self.engine.break_events_timeline()
        self.card_break_timeline.clear()
        times = timeline.get("times", [])
        if times:
            x = list(range(len(times)))
            y = [1] * len(times)
            self.card_break_timeline.plot.plot(
                x, y,
                pen=None,
                symbol="o",
                symbolSize=6,
                symbolBrush=AnalyticsColors.BREAK
            )
            self.card_break_timeline.plot.getAxis("bottom").setVisible(False)
            self.card_break_timeline.plot.getAxis("left").setVisible(False)

        # Suppression
        supp = self.engine.break_suppression_stats()
        self.card_break_suppression.clear()
        if supp:
            labels = list(supp.keys())
            vals = list(supp.values())
            x = list(range(len(labels)))
            bg = pg.BarGraphItem(
                x=x,
                height=vals,
                width=0.6,
                brush=AnalyticsColors.BREAK
            )
            self.card_break_suppression.plot.addItem(bg)
            ax = self.card_break_suppression.plot.getAxis("bottom")
            ax.setTicks([list(zip(x, labels))])
            ax.setVisible(True)

    # -------------------------
    # SUPPRESSION TAB
    # -------------------------
    def _init_suppression_tab(self):
        w, layout = self._create_scrollable_tab()
        self.supp_layout = layout

        self.card_supp_counts = ChartCard("Suppression Counts", AnalyticsColors.SUPPRESSION)
        self.supp_layout.add_card(self.card_supp_counts)

        self.card_away_resets = AnalyticsCard("Away Resets")
        self.away_resets_label = QLabel("No data yet.")
        self.away_resets_label.setObjectName("AnalyticsText")
        self.away_resets_label.setWordWrap(True)
        self.card_away_resets.body_layout.addWidget(self.away_resets_label)
        self.supp_layout.add_card(self.card_away_resets)

        self.tabs.addTab(w, "Suppression")

    def _refresh_suppression_tab(self):
        counts = self.engine.suppression_counts()
        self.card_supp_counts.clear()
        if counts:
            labels = list(counts.keys())
            vals = list(counts.values())
            x = list(range(len(labels)))
            bg = pg.BarGraphItem(
                x=x,
                height=vals,
                width=0.6,
                brush=AnalyticsColors.SUPPRESSION
            )
            self.card_supp_counts.plot.addItem(bg)
            ax = self.card_supp_counts.plot.getAxis("bottom")
            ax.setTicks([list(zip(x, labels))])
            ax.setVisible(True)

        away = self.engine.away_resets_count()
        self.away_resets_label.setText(
            f"Away-based resets: {away}."
        )

    # -------------------------
    # TIME OF DAY TAB
    # -------------------------
    def _init_time_of_day_tab(self):
        w, layout = self._create_scrollable_tab()
        self.tod_layout = layout

        self.card_behavior_heatmap = ChartCard("Behavior Heatmap", AnalyticsColors.BEHAVIOR)
        self.tod_layout.add_card(self.card_behavior_heatmap)

        self.card_fatigue_heatmap = ChartCard("Fatigue Heatmap", AnalyticsColors.FATIGUE)
        self.tod_layout.add_card(self.card_fatigue_heatmap)

        self.card_break_heatmap = ChartCard("Break Heatmap", AnalyticsColors.BREAK)
        self.tod_layout.add_card(self.card_break_heatmap)

        self.card_supp_heatmap = ChartCard("Suppression Heatmap", AnalyticsColors.SUPPRESSION)
        self.tod_layout.add_card(self.card_supp_heatmap)

        self.tabs.addTab(w, "Time of Day")

    def _plot_simple_heatmap(self, card: ChartCard, data: dict, color: str):
        """
        Simple 1D heatmap: hour -> value, rendered as colored bars.
        """
        card.clear()
        if not data:
            return

        hours = sorted(data.keys())
        vals = [data[h] for h in hours]
        x = list(range(len(hours)))
        bg = pg.BarGraphItem(
            x=x,
            height=vals,
            width=0.8,
            brush=color
        )
        card.plot.addItem(bg)
        labels = [f"{h:02d}:00" for h in hours]
        ax = card.plot.getAxis("bottom")
        ax.setTicks([list(zip(x, labels))])
        ax.setVisible(True)

    def _refresh_time_of_day_tab(self):
        beh = self.engine.behavior_heatmap()
        self._plot_simple_heatmap(self.card_behavior_heatmap, beh, AnalyticsColors.BEHAVIOR)

        fat = self.engine.fatigue_heatmap()
        self._plot_simple_heatmap(self.card_fatigue_heatmap, fat, AnalyticsColors.FATIGUE)

        br = self.engine.break_heatmap()
        self._plot_simple_heatmap(self.card_break_heatmap, br, AnalyticsColors.BREAK)

        supp = self.engine.suppression_heatmap()
        self._plot_simple_heatmap(self.card_supp_heatmap, supp, AnalyticsColors.SUPPRESSION)

    # -------------------------
    # WEEKLY TAB
    # -------------------------
    def _init_weekly_tab(self):
        w, layout = self._create_scrollable_tab()
        self.weekly_layout = layout

        self.card_weekly_behavior = ChartCard("Weekly Behavior Distribution", AnalyticsColors.BEHAVIOR)
        self.weekly_layout.add_card(self.card_weekly_behavior)

        self.card_weekly_fatigue = ChartCard("Weekly Fatigue Trend", AnalyticsColors.FATIGUE)
        self.weekly_layout.add_card(self.card_weekly_fatigue)

        self.card_weekly_break_consistency = AnalyticsCard("Weekly Break Consistency")
        self.weekly_break_label = QLabel("No data yet.")
        self.weekly_break_label.setObjectName("AnalyticsText")
        self.weekly_break_label.setWordWrap(True)
        self.card_weekly_break_consistency.body_layout.addWidget(self.weekly_break_label)
        self.weekly_layout.add_card(self.card_weekly_break_consistency)

        self.card_weekly_suppression = ChartCard("Weekly Suppression", AnalyticsColors.SUPPRESSION)
        self.weekly_layout.add_card(self.card_weekly_suppression)

        self.tabs.addTab(w, "Weekly")

    def _refresh_weekly_tab(self):
        summary = self.engine.weekly_behavior_summary()
        self.card_weekly_behavior.clear()
        self.card_weekly_fatigue.clear()
        self.card_weekly_suppression.clear()

        if not summary:
            self.weekly_break_label.setText("No weekly data available yet.")
            return

        # Behavior distribution
        dist = summary.get("distribution", {})
        if dist:
            behaviors = list(dist.keys())
            vals = list(dist.values())
            x = list(range(len(behaviors)))
            bg = pg.BarGraphItem(
                x=x,
                height=vals,
                width=0.6,
                brush=AnalyticsColors.BEHAVIOR
            )
            self.card_weekly_behavior.plot.addItem(bg)
            ax = self.card_weekly_behavior.plot.getAxis("bottom")
            ax.setTicks([list(zip(x, behaviors))])
            ax.setVisible(True)

        # Fatigue trend
        ft = summary.get("fatigue_trend", {})
        days = ft.get("days", [])
        fv = ft.get("fatigue", [])
        if days and fv:
            self.card_weekly_fatigue.plot.plot(
                list(range(len(days))), fv,
                pen=pg.mkPen(AnalyticsColors.FATIGUE, width=2)
            )
            self.card_weekly_fatigue.plot.setYRange(0, 100)

        # Break consistency
        cons = summary.get("break_consistency", None)
        if cons is not None:
            self.weekly_break_label.setText(
                f"Break consistency this week: {cons:.0f}/100."
            )
        else:
            self.weekly_break_label.setText("No break consistency data for this week.")

        # Suppression
        supp = summary.get("suppression_counts", {})
        if supp:
            labels = list(supp.keys())
            vals = list(supp.values())
            x = list(range(len(labels)))
            bg = pg.BarGraphItem(
                x=x,
                height=vals,
                width=0.6,
                brush=AnalyticsColors.SUPPRESSION
            )
            self.card_weekly_suppression.plot.addItem(bg)
            ax = self.card_weekly_suppression.plot.getAxis("bottom")
            ax.setTicks([list(zip(x, labels))])
            ax.setVisible(True)

    # -------------------------
    # MONTHLY TAB
    # -------------------------
    def _init_monthly_tab(self):
        w, layout = self._create_scrollable_tab()
        self.monthly_layout = layout

        self.card_monthly_behavior = ChartCard("Monthly Behavior Distribution", AnalyticsColors.BEHAVIOR)
        self.monthly_layout.add_card(self.card_monthly_behavior)

        self.card_monthly_fatigue = ChartCard("Monthly Fatigue Trend", AnalyticsColors.FATIGUE)
        self.monthly_layout.add_card(self.card_monthly_fatigue)

        self.card_monthly_break_consistency = AnalyticsCard("Monthly Break Consistency")
        self.monthly_break_label = QLabel("No data yet.")
        self.monthly_break_label.setObjectName("AnalyticsText")
        self.monthly_break_label.setWordWrap(True)
        self.card_monthly_break_consistency.body_layout.addWidget(self.monthly_break_label)
        self.monthly_layout.add_card(self.card_monthly_break_consistency)

        self.card_monthly_suppression = ChartCard("Monthly Suppression", AnalyticsColors.SUPPRESSION)
        self.monthly_layout.add_card(self.card_monthly_suppression)

        self.tabs.addTab(w, "Monthly")

    def _refresh_monthly_tab(self):
        summary = self.engine.monthly_behavior_summary()
        self.card_monthly_behavior.clear()
        self.card_monthly_fatigue.clear()
        self.card_monthly_suppression.clear()

        if not summary:
            self.monthly_break_label.setText("No monthly data available yet.")
            return

        # Behavior distribution
        dist = summary.get("distribution", {})
        if dist:
            behaviors = list(dist.keys())
            vals = list(dist.values())
            x = list(range(len(behaviors)))
            bg = pg.BarGraphItem(
                x=x,
                height=vals,
                width=0.6,
                brush=AnalyticsColors.BEHAVIOR
            )
            self.card_monthly_behavior.plot.addItem(bg)
            ax = self.card_monthly_behavior.plot.getAxis("bottom")
            ax.setTicks([list(zip(x, behaviors))])
            ax.setVisible(True)

        # Fatigue trend
        ft = summary.get("fatigue_trend", {})
        days = ft.get("days", [])
        fv = ft.get("fatigue", [])
        if days and fv:
            self.card_monthly_fatigue.plot.plot(
                list(range(len(days))), fv,
                pen=pg.mkPen(AnalyticsColors.FATIGUE, width=2)
            )
            self.card_monthly_fatigue.plot.setYRange(0, 100)

        # Break consistency
        cons = summary.get("break_consistency", None)
        if cons is not None:
            self.monthly_break_label.setText(
                f"Break consistency this month: {cons:.0f}/100."
            )
        else:
            self.monthly_break_label.setText("No break consistency data for this month.")

        # Suppression
        supp = summary.get("suppression_counts", {})
        if supp:
            labels = list(supp.keys())
            vals = list(supp.values())
            x = list(range(len(labels)))
            bg = pg.BarGraphItem(
                x=x,
                height=vals,
                width=0.6,
                brush=AnalyticsColors.SUPPRESSION
            )
            self.card_monthly_suppression.plot.addItem(bg)
            ax = self.card_monthly_suppression.plot.getAxis("bottom")
            ax.setTicks([list(zip(x, labels))])
            ax.setVisible(True)

    # -------------------------
    # INSIGHTS TAB
    # -------------------------
    def _init_insights_tab(self):
        w = QWidget()
        v = QVBoxLayout(w)
        v.setContentsMargins(10, 10, 10, 10)
        v.setSpacing(10)

        self.insights_container = QVBoxLayout()
        v.addLayout(self.insights_container)
        v.addStretch()

        self.tabs.addTab(w, "AI Insights")

    def _refresh_insights_tab(self):
        insights = self.engine.ai_insights()

        # Clear old cards
        while self.insights_container.count():
            item = self.insights_container.takeAt(0)
            if item.widget():
                item.widget().deleteLater()

        # Add new cards
        for text in insights:
            card = QFrame()
            card.setObjectName("InsightCard")
            v = QVBoxLayout(card)
            v.setContentsMargins(12, 12, 12, 12)

            lbl = QLabel(text)
            lbl.setObjectName("InsightText")
            lbl.setWordWrap(True)
            v.addWidget(lbl)

            self.insights_container.addWidget(card)

    # -------------------------
    # GLOBAL REFRESH
    # -------------------------
    def refresh_all(self):
        self._refresh_behavior_tab()
        self._refresh_fatigue_tab()
        self._refresh_break_tab()
        self._refresh_suppression_tab()
        self._refresh_time_of_day_tab()
        self._refresh_weekly_tab()
        self._refresh_monthly_tab()
        self._refresh_insights_tab()








