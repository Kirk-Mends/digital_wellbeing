class WeeklyReportGenerator:
    def generate(self, summary):
        if summary is None:
            return "No activity data available for this week."

        avg = summary["avg"]
        total = summary["total"]
        best = summary["best_day"]
        worst = summary["worst_day"]
        trend = summary["trend"]

        trend_text = (
            "Your activity improved toward the end of the week."
            if trend == "up"
            else "Your activity dipped slightly toward the end of the week."
        )

        return (
            f"Here’s your weekly wellbeing summary:\n\n"
            f"• You were active for a total of **{total:.0f} minutes** this week.\n"
            f"• Your average daily active time was **{avg:.1f} minutes**.\n"
            f"• Your most productive day was **{best}**, while **{worst}** was your lightest day.\n"
            f"• {trend_text}\n\n"
            f"Keep building healthy habits — small improvements add up."
        )
