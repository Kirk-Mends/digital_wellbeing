

# from PySide6.QtCore import Qt, QSize, QPropertyAnimation, QEasingCurve
# from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton
# from PySide6.QtGui import QIcon


# class Sidebar(QWidget):
#     def __init__(self, main_window):
#         super().__init__()
#         self.main = main_window

#         # Sidebar state
#         self.expanded_width = 200
#         self.collapsed_width = 56
#         self.is_expanded = True

#         self.setMinimumWidth(self.expanded_width)
#         self.setObjectName("Sidebar")

#         # -------------------------
#         # MAIN LAYOUT (must be first!)
#         # -------------------------
#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(0, 0, 0, 0)
#         layout.setSpacing(0)

#         # -------------------------
#         # HAMBURGER BUTTON
#         # -------------------------
#         self.btn_toggle = QPushButton()
#         self.btn_toggle.setIcon(QIcon("assets/icons/hamburger.svg"))
#         self.btn_toggle.setIconSize(QSize(20, 20))
#         self.btn_toggle.setObjectName("HamburgerButton")
#         self.btn_toggle.clicked.connect(self.toggle_sidebar)
#         self.btn_toggle.setCursor(Qt.PointingHandCursor)

#         layout.addWidget(self.btn_toggle)

#         # -------------------------
#         # NAVIGATION BUTTONS
#         # -------------------------
#         self.btn_dashboard = self.make_button(
#             "Dashboard", "assets/icons/dashboard.svg", self.main.show_dashboard
#         )
#         self.btn_smart = self.make_button(
#             "Smart Mode", "assets/icons/smart_mode.svg", self.main.show_smart
#         )
#         self.btn_ai = self.make_button(
#             "AI Mode", "assets/icons/ai_mode.svg", self.main.show_ai
#         )

#         layout.addWidget(self.btn_dashboard)
#         layout.addWidget(self.btn_smart)
#         layout.addWidget(self.btn_ai)

#         # -------------------------
#         # ANALYTICS SECTION
#         # -------------------------
#         self.btn_analytics = self.make_button(
#             "Analytics", "assets/icons/analytics.svg", self.main.show_analytics
#         )
#         self.btn_weekly = self.make_button(
#             "Weekly Analytics", "assets/icons/weekly_report.svg", self.main.show_weekly
#         )
#         self.btn_insights = self.make_button(
#             "AI Insights", "assets/icons/ai_mode.svg", self.main.show_insights
#         )
#         self.btn_weekly_report = self.make_button(
#             "Weekly Report", "assets/icons/weekly_report.svg", self.main.show_weekly_report
#         )
#         self.btn_monthly_report = self.make_button(
#             "Monthly Report", "assets/icons/monthly_report.svg", self.main.show_monthly_report
#         )

#         layout.addWidget(self.btn_analytics)
#         layout.addWidget(self.btn_weekly)
#         layout.addWidget(self.btn_insights)
#         layout.addWidget(self.btn_weekly_report)
#         layout.addWidget(self.btn_monthly_report)

#         layout.addStretch()

#         # -------------------------
#         # SETTINGS BUTTON (BOTTOM)
#         # -------------------------
#         self.btn_settings = self.make_button(
#             "Settings", "assets/icons/settings.svg", self.main.show_settings
#         )
#         layout.addWidget(self.btn_settings)

#         # -------------------------
#         # STORE BUTTONS FOR ACTIVE/HOVER LOGIC
#         # -------------------------
#         self.buttons = [
#             self.btn_dashboard,
#             self.btn_smart,
#             self.btn_ai,
#             self.btn_analytics,
#             self.btn_weekly,
#             self.btn_insights,
#             self.btn_weekly_report,
#             self.btn_monthly_report,
#             self.btn_settings
#         ]

#         # Store full text for collapse mode
#         for btn in self.buttons:
#             btn.setProperty("full_text", btn.text())

#     # -------------------------------------------------------
#     # CREATE A NAVIGATION BUTTON
#     # -------------------------------------------------------
#     def make_button(self, text, icon_path, callback):
#         btn = QPushButton(text)
#         btn.setIcon(QIcon(icon_path))
#         btn.setIconSize(QSize(20, 20))
#         btn.setCursor(Qt.PointingHandCursor)
#         btn.setObjectName("SidebarButton")

#         # Hover reveal
#         btn.setProperty("hover", False)
#         btn.enterEvent = lambda e, b=btn: self.on_hover(b, True)
#         btn.leaveEvent = lambda e, b=btn: self.on_hover(b, False)

#         # Selection highlight
#         btn.clicked.connect(lambda: self.set_active(btn, callback))

#         return btn

#     # -------------------------------------------------------
#     # HOVER EFFECT
#     # -------------------------------------------------------
#     def on_hover(self, btn, state):
#         btn.setProperty("hover", state)
#         btn.style().unpolish(btn)
#         btn.style().polish(btn)

#     # -------------------------------------------------------
#     # SET ACTIVE BUTTON (ACCENT BAR)
#     # -------------------------------------------------------
#     def set_active(self, btn, callback):
#         for b in self.buttons:
#             b.setProperty("active", False)
#             b.style().unpolish(b)
#             b.style().polish(b)

#         btn.setProperty("active", True)
#         btn.style().unpolish(btn)
#         btn.style().polish(btn)

#         callback()

#     # -------------------------------------------------------
#     # ANIMATE SIDEBAR WIDTH
#     # -------------------------------------------------------
#     def animate_width(self, start, end, duration=250):
#         self.anim = QPropertyAnimation(self, b"minimumWidth")
#         self.anim.setDuration(duration)
#         self.anim.setStartValue(start)
#         self.anim.setEndValue(end)
#         self.anim.setEasingCurve(QEasingCurve.InOutCubic)
#         self.anim.start()

#     # -------------------------------------------------------
#     # COLLAPSE / EXPAND SIDEBAR
#     # -------------------------------------------------------
#     def toggle_sidebar(self):
#         target_width = self.collapsed_width if self.is_expanded else self.expanded_width
#         self.is_expanded = not self.is_expanded

#         # Animate width
#         self.animate_width(self.width(), target_width)

#         # Hide/show text on buttons
#         for btn in self.buttons:
#             full_text = btn.property("full_text")
#             btn.setText(full_text if self.is_expanded else "")

#     # -------------------------------------------------------
#     # MEETING MODE HIGHLIGHT
#     # -------------------------------------------------------
#     def set_meeting_mode(self, active: bool):
#         self.btn_smart.setProperty("meeting", active)
#         self.btn_ai.setProperty("meeting", active)

#         for btn in (self.btn_smart, self.btn_ai):
#             btn.style().unpolish(btn)
#             btn.style().polish(btn)














# new architectural version

from PySide6.QtCore import Qt, QSize, QPropertyAnimation, QEasingCurve
from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton
from PySide6.QtGui import QIcon


class Sidebar(QWidget):
    def __init__(self, main_window):
        super().__init__()
        self.main = main_window

        # Sidebar state
        self.expanded_width = 200
        self.collapsed_width = 56
        self.is_expanded = True

        self.setMinimumWidth(self.expanded_width)
        self.setObjectName("Sidebar")

        # -------------------------
        # MAIN LAYOUT
        # -------------------------
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # -------------------------
        # HAMBURGER BUTTON
        # -------------------------
        self.btn_toggle = QPushButton()
        self.btn_toggle.setIcon(QIcon("assets/icons/hamburger.svg"))
        self.btn_toggle.setIconSize(QSize(20, 20))
        self.btn_toggle.setObjectName("HamburgerButton")
        self.btn_toggle.clicked.connect(self.toggle_sidebar)
        self.btn_toggle.setCursor(Qt.PointingHandCursor)
        layout.addWidget(self.btn_toggle)

        # -------------------------
        # NAVIGATION BUTTONS
        # -------------------------
        self.btn_dashboard = self.make_button(
            "Dashboard", "assets/icons/dashboard.svg", self.main.show_dashboard
        )
        self.btn_smart = self.make_button(
            "Smart Mode", "assets/icons/smart_mode.svg", self.main.show_smart
        )
        self.btn_ai = self.make_button(
            "AI Mode", "assets/icons/ai_mode.svg", self.main.show_ai
        )

        layout.addWidget(self.btn_dashboard)
        layout.addWidget(self.btn_smart)
        layout.addWidget(self.btn_ai)

        # -------------------------
        # ANALYTICS SECTION
        # -------------------------
        self.btn_analytics = self.make_button(
            "Analytics", "assets/icons/analytics.svg", self.main.show_analytics
        )
        self.btn_weekly = self.make_button(
            "Weekly Analytics", "assets/icons/weekly_report.svg", self.main.show_weekly
        )
        self.btn_insights = self.make_button(
            "AI Insights", "assets/icons/ai_mode.svg", self.main.show_insights
        )
        self.btn_weekly_report = self.make_button(
            "Weekly Report", "assets/icons/weekly_report.svg", self.main.show_weekly_report
        )
        self.btn_monthly_report = self.make_button(
            "Monthly Report", "assets/icons/monthly_report.svg", self.main.show_monthly_report
        )

        layout.addWidget(self.btn_analytics)
        layout.addWidget(self.btn_weekly)
        layout.addWidget(self.btn_insights)
        layout.addWidget(self.btn_weekly_report)
        layout.addWidget(self.btn_monthly_report)

        layout.addStretch()

        # -------------------------
        # SETTINGS BUTTON
        # -------------------------
        self.btn_settings = self.make_button(
            "Settings", "assets/icons/settings.svg", self.main.show_settings
        )
        layout.addWidget(self.btn_settings)

        # -------------------------
        # STORE BUTTONS FOR ACTIVE/HOVER LOGIC
        # -------------------------
        self.buttons = [
            self.btn_dashboard,
            self.btn_smart,
            self.btn_ai,
            self.btn_analytics,
            self.btn_weekly,
            self.btn_insights,
            self.btn_weekly_report,
            self.btn_monthly_report,
            self.btn_settings
        ]

        # Store full text for collapse mode
        for btn in self.buttons:
            btn.setProperty("full_text", btn.text())

    # -------------------------------------------------------
    # CREATE A NAVIGATION BUTTON
    # -------------------------------------------------------
    def make_button(self, text, icon_path, callback):
        btn = QPushButton(text)
        btn.setIcon(QIcon(icon_path))
        btn.setIconSize(QSize(20, 20))
        btn.setCursor(Qt.PointingHandCursor)
        btn.setObjectName("SidebarButton")

        # Hover glow
        btn.setProperty("hover", False)
        btn.enterEvent = lambda e, b=btn: self.on_hover(b, True)
        btn.leaveEvent = lambda e, b=btn: self.on_hover(b, False)

        # Active highlight
        btn.clicked.connect(lambda: self.set_active(btn, callback))

        return btn

    # -------------------------------------------------------
    # HOVER EFFECT
    # -------------------------------------------------------
    def on_hover(self, btn, state):
        btn.setProperty("hover", state)
        btn.style().unpolish(btn)
        btn.style().polish(btn)

    # -------------------------------------------------------
    # SET ACTIVE BUTTON (ACCENT BAR)
    # -------------------------------------------------------
    def set_active(self, btn, callback):
        for b in self.buttons:
            b.setProperty("active", False)
            b.style().unpolish(b)
            b.style().polish(b)

        btn.setProperty("active", True)
        btn.style().unpolish(btn)
        btn.style().polish(btn)

        callback()

    # -------------------------------------------------------
    # ANIMATE SIDEBAR WIDTH
    # -------------------------------------------------------
    def animate_width(self, start, end, duration=250):
        self.anim = QPropertyAnimation(self, b"minimumWidth")
        self.anim.setDuration(duration)
        self.anim.setStartValue(start)
        self.anim.setEndValue(end)
        self.anim.setEasingCurve(QEasingCurve.InOutCubic)
        self.anim.start()

    # -------------------------------------------------------
    # COLLAPSE / EXPAND SIDEBAR
    # -------------------------------------------------------
    def toggle_sidebar(self):
        target_width = self.collapsed_width if self.is_expanded else self.expanded_width
        self.is_expanded = not self.is_expanded

        # Animate width
        self.animate_width(self.width(), target_width)

        # Hide/show text on buttons
        for btn in self.buttons:
            full_text = btn.property("full_text")
            btn.setText(full_text if self.is_expanded else "")

    # -------------------------------------------------------
    # MEETING MODE HIGHLIGHT
    # -------------------------------------------------------
    def set_meeting_mode(self, active: bool):
        # Highlight Smart Mode + AI Mode buttons during meetings
        self.btn_smart.setProperty("meeting", active)
        self.btn_ai.setProperty("meeting", active)

        for btn in (self.btn_smart, self.btn_ai):
            btn.style().unpolish(btn)
            btn.style().polish(btn)














# 2

# # sidebar.py

# from PySide6.QtCore import Qt, QSize, QPropertyAnimation, QEasingCurve
# from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton
# from PySide6.QtGui import QIcon


# class Sidebar(QWidget):
#     def __init__(self, main_window):
#         super().__init__()
#         self.main = main_window

#         # Sidebar state
#         self.expanded_width = 200
#         self.collapsed_width = 56
#         self.is_expanded = True

#         self.setMinimumWidth(self.expanded_width)
#         self.setObjectName("Sidebar")

#         # -------------------------
#         # MAIN LAYOUT
#         # -------------------------
#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(0, 0, 0, 0)
#         layout.setSpacing(0)

#         # -------------------------
#         # HAMBURGER BUTTON
#         # -------------------------
#         self.btn_toggle = QPushButton()
#         self.btn_toggle.setIcon(QIcon("assets/icons/hamburger.svg"))
#         self.btn_toggle.setIconSize(QSize(20, 20))
#         self.btn_toggle.setObjectName("HamburgerButton")
#         self.btn_toggle.clicked.connect(self.toggle_sidebar)
#         self.btn_toggle.setCursor(Qt.PointingHandCursor)
#         layout.addWidget(self.btn_toggle)

#         # -------------------------
#         # NAVIGATION BUTTONS
#         # -------------------------
#         self.btn_dashboard = self.make_button(
#             "Dashboard", "assets/icons/dashboard.svg", self.main.show_dashboard
#         )
#         self.btn_smart = self.make_button(
#             "Smart Mode", "assets/icons/smart_mode.svg", self.main.show_smart
#         )
#         self.btn_ai = self.make_button(
#             "AI Mode", "assets/icons/ai_mode.svg", self.main.show_ai
#         )

#         layout.addWidget(self.btn_dashboard)
#         layout.addWidget(self.btn_smart)
#         layout.addWidget(self.btn_ai)

#         # -------------------------
#         # ANALYTICS SECTION
#         # -------------------------
#         self.btn_weekly = self.make_button(
#             "Weekly Analytics", "assets/icons/weekly_report.svg", self.main.show_weekly
#         )
#         self.btn_monthly = self.make_button(
#             "Monthly Report", "assets/icons/monthly_report.svg", self.main.show_monthly
#         )
#         self.btn_insights = self.make_button(
#             "AI Insights", "assets/icons/ai_mode.svg", self.main.show_insights
#         )
#         self.btn_reports = self.make_button(
#             "Reports", "assets/icons/weekly_report.svg", self.main.show_reports
#         )
#         self.btn_heatmap = self.make_button(
#             "Heatmap", "assets/icons/heatmap.svg", self.main.show_heatmap
#         )
#         self.btn_break_score = self.make_button(
#             "Break Score", "assets/icons/break_score.svg", self.main.show_break_score
#         )

#         layout.addWidget(self.btn_weekly)
#         layout.addWidget(self.btn_monthly)
#         layout.addWidget(self.btn_insights)
#         layout.addWidget(self.btn_reports)
#         layout.addWidget(self.btn_heatmap)
#         layout.addWidget(self.btn_break_score)

#         layout.addStretch()

#         # -------------------------
#         # SETTINGS BUTTON
#         # -------------------------
#         self.btn_settings = self.make_button(
#             "Settings", "assets/icons/settings.svg", self.main.show_settings
#         )
#         layout.addWidget(self.btn_settings)

#         # Store buttons for hover/active logic
#         self.buttons = [
#             self.btn_dashboard,
#             self.btn_smart,
#             self.btn_ai,
#             self.btn_weekly,
#             self.btn_monthly,
#             self.btn_insights,
#             self.btn_reports,
#             self.btn_heatmap,
#             self.btn_break_score,
#             self.btn_settings
#         ]
#         for btn in self.buttons:
#             btn.setProperty("full_text", btn.text())

#     # -------------------------
#     # CREATE NAV BUTTON
#     # -------------------------
#     def make_button(self, text, icon_path, callback):
#         btn = QPushButton(text)
#         btn.setIcon(QIcon(icon_path))
#         btn.setIconSize(QSize(20, 20))
#         btn.setCursor(Qt.PointingHandCursor)
#         btn.setObjectName("SidebarButton")

#         btn.setProperty("hover", False)
#         btn.enterEvent = lambda e, b=btn: self.on_hover(b, True)
#         btn.leaveEvent = lambda e, b=btn: self.on_hover(b, False)

#         btn.clicked.connect(lambda: self.set_active(btn, callback))
#         return btn

#     # -------------------------
#     # HOVER EFFECT
#     # -------------------------
#     def on_hover(self, btn, state):
#         btn.setProperty("hover", state)
#         btn.style().unpolish(btn)
#         btn.style().polish(btn)

#     # -------------------------
#     # ACTIVE BUTTON
#     # -------------------------
#     def set_active(self, btn, callback):
#         for b in self.buttons:
#             b.setProperty("active", False)
#             b.style().unpolish(b)
#             b.style().polish(b)

#         btn.setProperty("active", True)
#         btn.style().unpolish(btn)
#         btn.style().polish(btn)

#         callback()

#     # -------------------------
#     # SIDEBAR ANIMATION
#     # -------------------------
#     def animate_width(self, start, end, duration=250):
#         self.anim = QPropertyAnimation(self, b"minimumWidth")
#         self.anim.setDuration(duration)
#         self.anim.setStartValue(start)
#         self.anim.setEndValue(end)
#         self.anim.setEasingCurve(QEasingCurve.InOutCubic)
#         self.anim.start()

#     def toggle_sidebar(self):
#         target_width = self.collapsed_width if self.is_expanded else self.expanded_width
#         self.is_expanded = not self.is_expanded
#         self.animate_width(self.width(), target_width)
#         for btn in self.buttons:
#             full_text = btn.property("full_text")
#             btn.setText(full_text if self.is_expanded else "")















# I have outgrown this version already so don't use 
# THIS GIVE SIDEBAR WITH LABELS LIKE MODES, ANALYTICS, SYSTEM which i really didn't like.

# from PySide6.QtCore import Qt, QSize, QPropertyAnimation, QEasingCurve
# from PySide6.QtWidgets import QWidget, QVBoxLayout, QPushButton, QLabel
# from PySide6.QtGui import QIcon


# class Sidebar(QWidget):
#     def __init__(self, main_window):
#         super().__init__()
#         self.main = main_window

#         # Sidebar state
#         self.expanded_width = 200
#         self.collapsed_width = 56
#         self.is_expanded = True

#         self.setMinimumWidth(self.expanded_width)
#         self.setObjectName("Sidebar")

#         # -------------------------
#         # MAIN LAYOUT
#         # -------------------------
#         layout = QVBoxLayout(self)
#         layout.setContentsMargins(0, 12, 0, 12)
#         layout.setSpacing(4)

#         # -------------------------
#         # HAMBURGER BUTTON
#         # -------------------------
#         self.btn_toggle = QPushButton()
#         self.btn_toggle.setIcon(QIcon("assets/icons/hamburger.svg"))
#         self.btn_toggle.setIconSize(QSize(20, 20))
#         self.btn_toggle.setObjectName("HamburgerButton")
#         self.btn_toggle.clicked.connect(self.toggle_sidebar)
#         self.btn_toggle.setCursor(Qt.PointingHandCursor)
#         layout.addWidget(self.btn_toggle)

#         # -------------------------
#         # SECTION: MODES
#         # -------------------------
#         self.add_section_label(layout, "MODES")

#         self.btn_dashboard = self.make_button("Dashboard", "assets/icons/dashboard.svg", self.main.show_dashboard)
#         self.btn_smart = self.make_button("Smart Mode", "assets/icons/smart_mode.svg", self.main.show_smart)
#         self.btn_ai = self.make_button("AI Mode", "assets/icons/ai_mode.svg", self.main.show_ai)

#         layout.addWidget(self.btn_dashboard)
#         layout.addWidget(self.btn_smart)
#         layout.addWidget(self.btn_ai)

#         # -------------------------
#         # SECTION: ANALYTICS
#         # -------------------------
#         self.add_section_label(layout, "ANALYTICS")

#         self.btn_analytics = self.make_button("Analytics Suite", "assets/icons/analytics.svg", self.main.show_analytics)
#         self.btn_weekly = self.make_button("Weekly Analytics", "assets/icons/weekly_report.svg", self.main.show_weekly)
#         self.btn_insights = self.make_button("AI Insights", "assets/icons/insights.svg", self.main.show_insights)
#         self.btn_weekly_report = self.make_button("Weekly Report", "assets/icons/weekly_report.svg", self.main.show_weekly_report)
#         self.btn_monthly_report = self.make_button("Monthly Report", "assets/icons/monthly_report.svg", self.main.show_monthly_report)

#         layout.addWidget(self.btn_analytics)
#         layout.addWidget(self.btn_weekly)
#         layout.addWidget(self.btn_insights)
#         layout.addWidget(self.btn_weekly_report)
#         layout.addWidget(self.btn_monthly_report)

#         layout.addStretch()

#         # -------------------------
#         # SECTION: SYSTEM
#         # -------------------------
#         self.add_section_label(layout, "SYSTEM")

#         self.btn_settings = self.make_button("Settings", "assets/icons/settings.svg", self.main.show_settings)
#         layout.addWidget(self.btn_settings)

#         # -------------------------
#         # STORE BUTTONS
#         # -------------------------
#         self.buttons = [
#             self.btn_dashboard,
#             self.btn_smart,
#             self.btn_ai,
#             self.btn_analytics,
#             self.btn_weekly,
#             self.btn_insights,
#             self.btn_weekly_report,
#             self.btn_monthly_report,
#             self.btn_settings
#         ]

#         for btn in self.buttons:
#             btn.setProperty("full_text", btn.text())

#     # -------------------------------------------------------
#     # SECTION LABEL
#     # -------------------------------------------------------
#     def add_section_label(self, layout, text):
#         label = QLabel(text)
#         label.setObjectName("SidebarSection")
#         layout.addWidget(label)

#     # -------------------------------------------------------
#     # CREATE A NAVIGATION BUTTON
#     # -------------------------------------------------------
#     def make_button(self, text, icon_path, callback):
#         btn = QPushButton(text)
#         btn.setIcon(QIcon(icon_path))
#         btn.setIconSize(QSize(20, 20))
#         btn.setCursor(Qt.PointingHandCursor)
#         btn.setObjectName("SidebarButton")

#         btn.clicked.connect(lambda: self.set_active(btn, callback))
#         return btn

#     # -------------------------------------------------------
#     # SET ACTIVE BUTTON (ACCENT BAR)
#     # -------------------------------------------------------
#     def set_active(self, btn, callback):
#         for b in self.buttons:
#             b.setProperty("active", False)
#             b.style().unpolish(b)
#             b.style().polish(b)

#         btn.setProperty("active", True)
#         btn.style().unpolish(btn)
#         btn.style().polish(btn)

#         callback()

#     # -------------------------------------------------------
#     # ANIMATE SIDEBAR WIDTH
#     # -------------------------------------------------------
#     def animate_width(self, start, end, duration=250):
#         self.anim = QPropertyAnimation(self, b"minimumWidth")
#         self.anim.setDuration(duration)
#         self.anim.setStartValue(start)
#         self.anim.setEndValue(end)
#         self.anim.setEasingCurve(QEasingCurve.InOutCubic)
#         self.anim.start()

#     # -------------------------------------------------------
#     # COLLAPSE / EXPAND SIDEBAR
#     # -------------------------------------------------------
#     def toggle_sidebar(self):
#         target_width = self.collapsed_width if self.is_expanded else self.expanded_width
#         self.is_expanded = not self.is_expanded

#         self.animate_width(self.width(), target_width)

#         for btn in self.buttons:
#             full_text = btn.property("full_text")
#             btn.setText(full_text if self.is_expanded else "")

#     # -------------------------------------------------------
#     # MEETING MODE HIGHLIGHT
#     # -------------------------------------------------------
#     def set_meeting_mode(self, active: bool):
#         self.btn_smart.setProperty("meeting", active)
#         self.btn_ai.setProperty("meeting", active)

#         for btn in (self.btn_smart, self.btn_ai):
#             btn.style().unpolish(btn)
#             btn.style().polish(btn)
